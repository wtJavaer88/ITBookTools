import org.jsoup.nodes.Document;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wnc.string.PatternUtil;
import com.wnc.tools.SoupUtil;
import com.wnc.tools.UrlPicDownloader;

public class Taobao_SearchList {
	public static void main(String[] args) throws Exception {
		Document doc = SoupUtil.getDoc(
				"https://s.taobao.com/search?q=%E6%AC%A7%E8%B4%9D%E5%98%89&s_from=newHeader&ssid=s5-e&search_type=item&sourceId=tb.item");
		// System.out.println(doc);
		System.out.println(doc.toString().contains("g_page_config"));
		String firstPattern = PatternUtil.getFirstPatternGroup(doc.toString(), "g_page_config = (.*+)").replaceAll(";$",
				"");
		System.out.println(firstPattern);
		JSONObject parseObject = JSONObject.parseObject(firstPattern);

		JSONArray jsonArray = parseObject.getJSONObject("mods").getJSONObject("itemlist").getJSONObject("data")
				.getJSONArray("auctions");
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject object = jsonArray.getJSONObject(i);
			String string = object.getString("pic_url");
			System.out.println(string);
			if (string.startsWith("//"))
				string = "http:" + string;
			UrlPicDownloader.download(string, getUrlFileName(string));

		}

	}

	private static String getUrlFileName(String attr) {
		return PatternUtil.getLastPattern(attr, "[^/]+$");
	}
}
