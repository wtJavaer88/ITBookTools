import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.wnc.string.PatternUtil;
import com.wnc.tools.SoupUtil;
import com.wnc.tools.UrlPicDownloader;

public class Taobao {
	public static void main(String[] args) throws Exception {
		Document doc = SoupUtil.getDoc(
				"https://item.taobao.com/item.htm?spm=a230r.1.14.1.f8863f2bHjzFxJ&id=539153992482&ns=1&abbucket=6#detail");
		downloadThumb(doc);
		// downDescription(doc);
	}

	private static void downloadThumb(Document doc) throws Exception {
		System.out.println(doc.select("#J_UlThumb"));
		Elements select = doc.select("#J_UlThumb li img");
		for (Element element : select) {
			String attr = element.attr("data-src");
			attr = PatternUtil.getFirstPatternGroup(attr, ".*?\\.jpg");
			if (attr.startsWith("//"))
				attr = "http:" + attr;
			System.out.println(attr);
			UrlPicDownloader.download(attr, getUrlFileName(attr));
		}
	}

	private static void downDescription(Document doc) throws Exception {
		String firstPattern = "http://" + PatternUtil.getFirstPatternGroup(doc.toString(), "(dsc.taobaocdn.com.*?)'");

		System.out.println(firstPattern);
		Document doc2 = SoupUtil.getDoc(firstPattern);
		System.out.println(doc2);
		Elements select = doc2.select("img");
		for (Element element : select) {
			String attr = element.attr("src");
			UrlPicDownloader.download(attr, getUrlFileName(attr));
		}
	}

	private static String getUrlFileName(String attr) {
		return PatternUtil.getLastPattern(attr, "[^/]+$");
	}
}
