app.register.controller('SysOptionCtrl', function($scope, $http, $rootScope,
		$route, AppUtil, $q, $routeParams) {
	// 获取本地存储中的页码页数
	$scope.pagination = {
		currentPage : 1,
		itemsPerPage : 10
	};
	$rootScope.$watch('projects', function() {
		$scope.projects=[];
		
		if ($rootScope.projects == undefined)
			return;
		for(var i=0,j=$rootScope.projects.length;i<j;i++){
			$scope.projects.push($rootScope.projects[i]);
		}
		if ($scope.projects.length > 0) {
			$scope.project_no = $scope.projects[0].project_no;
		}
		if (!$scope.user.employee) {
			var pro = {
				project_no : "",
				project_name : "系统操作"
			};
			$scope.projects.splice(0, 0, pro);
			$scope.project_no = "";
		}
		$scope.$watch('pagination.refresh', function() {
			if ($scope.project_no != undefined)
				LoadList();
		});
	});

	$scope.SearchData = function() {
		$scope.postData = {};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		$scope.postData = AppUtil.Params(".form_params");
		// 表单查询参数
		LoadList();
	};

	// 加载数据方法
	var LoadList = function() {
		$scope.checked = false;
		if ($scope.postData == undefined)
			$scope.postData = {};
		var page = $scope.pagination.currentPage;
		$scope.postData.start = (page - 1 < 0 ? 0 : page - 1)
				* $scope.pagination.itemsPerPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		AppUtil.Post("/syslog/optionList", $scope.postData, function(response) {
			$scope.datas = response.data;
			$scope.pagination.totalItems = response.total;
		});
	}

	$scope.showDetail = function(c) {
		AppUtil.Post("/syslog/option/" + c.id, {}, function(response) {
			if (response.code = 1) {
				$scope.option = response.data;
				$("#viewModal").modal("show");
			}
		});
	};

});
