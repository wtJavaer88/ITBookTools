app.register.controller('RaisecreateCtrl', function($scope, $rootScope,
		RaisecreateSer, AppUtil, $http, $q,$location,$routeParams) {
	// 获取本地存储中的页码页数 tableID+page or size
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};

	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		
		// 加载数据
		RaisecreateSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	};
	
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	

	$http.get("raiseOrder/dicts").success(function(data){
		$scope.roStatus=data.data.roStatus;
		$scope.payMode=data.data.payMode;
		$scope.hasProve=data.data.hasProve;
		$scope.cashier=data.data.cashier;
		$scope.cashierName=data.data.cashierName;
		$scope.created=data.data.created;
		$scope.salesList=data.data.salesList;
		$scope.cwsalesList=data.data.cwsalesList;
	});
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//获取审核流水
	var getCheckList=function(raisedNo){
		$http.get('raiseOrder/getRaiseCheckList?raisedNo='+raisedNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	//提交审核
	$scope.submitCheck = function() {
		
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.roStatus!=CON_ROSTATUS.WTJ){
			alertMsg("提示", "只能选择未提交的数据.");
			return;
		}
		showconfirm("单据确定提交审核？",
				function(){
			$http.get('raiseOrder/submitCheck?raisedNo='+data.raisedNo).success(function(response) {
				alertMsg("提示", "已成功提交审核");
				LoadList();
			}).error(function(msg) {
				console.log(msg);
				alertMsg("提示", msg.message);
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});	
	};
	
	
	//审核流水
	$scope.showchecklist = function() {
		
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.roStatus==CON_ROSTATUS.WTJ){
			return;
		}
		var data = $scope.data;
		getCheckList(data.raisedNo);
	};
	
	
	//打印
	$scope.printRaiseOrder = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.roStatus==CON_ROSTATUS.WTJ||data.roStatus==CON_ROSTATUS.DSH||data.roStatus==CON_ROSTATUS.SHTG){
			$scope.PrintData(data.raisedNo,'/print/raise.html');
		}else{
			alertMsg("提示", "只有未提交、审核中、审核通过的认筹单才能打印");
		}
	};
	
	
	
    //加载新增页面
    $scope.showAddWin = function() {
    	$("#addraise_modal").modal("show");
    	$("#addraise_modal .new_customer:gt(0)").remove();
    	$("#addraise_modal .ng-binding").removeAttr("readonly");
		// 加载数据方法
    	$http.get('raiseOrder/getSeqNo').success(function(response) {
    		$("#addraise_modal input[name='raisedNo']").val(response.raisedNo);
    		$("#addraise_modal input[name='receiptNumber']").val(response.receiptNo);
    	}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
    	
    	$("#addraise_form")[0].reset();
    };
    
    //新增页面保存按钮操作
    $("#saveRaiseOrder").off().click(function(){
		var entity = AppUtil.Params("#addraise_modal .ng-binding",true);
		var config={
    			sel:".ng-binding,.ng-binding-p",
    			msgDiv:"#add_raise_reg_tip_box",
    			id:"#addraise_form"
    			};
		var flag  = ValidF.valid(config);
		
		//共同客户信息
		var pubCusName= new Array;
		$("#addraise_form .new_customer_list .ng-binding-p[name='customerName']").each(function(index,item){
			pubCusName[index]=$(item).val();
		});
		var pubCusId= new Array;
		$("#addraise_form .new_customer_list .ng-binding-p[name='customerIdcard']").each(function(index,item){
			pubCusId[index]=$(item).val();
		});
		var pubCusPhone= new Array;
		$("#addraise_form .new_customer_list .ng-binding-p[name='customerPhone']").each(function(index,item){
			pubCusPhone[index]=$(item).val();
		});
		var jsonItemArr=new Array;
		$.each(pubCusName,function(i,o){
				var json={};
				json.customerName=pubCusName[i];
				json.customerIdcard=pubCusId[i];
				json.customerPhone=pubCusPhone[i];
				json.billNo=entity.raisedNo;
				json.sourceType='1001';
				json.createBy=$rootScope.user.userId;
				jsonItemArr.push(json);
		});
		entity.publicCustomerList=jsonItemArr;
		if(flag){
			$http.post('raiseOrder/createRaiseOrder', entity).success(function(response) {
				LoadList();
				$("#addraise_modal").modal("hide");
				alertMsg("提示", "新增成功");
			}).error(function(msg) {
				alertMsg("提示", msg.message);
			});
		}
	});
    
    
    
    //作废
    $scope.nullifyOrder = function() {
    	
    	if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.roStatus!=CON_ROSTATUS.WTJ&&data.roStatus!=CON_ROSTATUS.SHBTG){
			alertMsg("提示", "只有未提交或审核不通过的单据才能作废");
			return;
		}
		showconfirm("单据确定作废？",
				function(){
			$http.get('raiseOrder/nullifyOrder?raisedNo='+data.raisedNo).success(function(response) {
				if(response.code=='1'){
					alertMsg("提示", "已成功作废");
					LoadList();
				}else{
					alertMsg("提示", response.data);
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});
		
			
    };
    
    
    
    //双击跳转明细页面
	$scope.showDetail = function(entity) {
		if($scope.changeElem){
			$($scope.changeElem).removeAttr("disabled");
		}
		$("#raiseDetailForm")[0].reset();
		$scope.detailEntity=entity;
		$http.get('publicCustomer/list?billNo='+entity.raisedNo).success(function(response) {
			$scope.publicCustomerList=response;
			if(entity.roStatus==CON_ROSTATUS.WTJ){
				$http.post("/common/printCount?",{sourceNo:entity.raisedNo,sourceType:'1001'}).success(function(response){
					$scope.detailEntity.printCount=response;
					if($rootScope.user.loginRole!='SY'||response!=1){
						var elem=$("#raiseDetailForm").find("input,select,textarea,.add_new_customer,.remove_new_customer").attr("disabled","disabled");
						$scope.changeElem=elem;
					}
				});
			}else{
				setTimeout(function(){
					var elem=$("#raiseDetailForm input[disabled!='disabled'][readonly!='readonly']," +
							"   #raiseDetailForm textarea[disabled!='disabled'][readonly!='readonly']," +
							"   #raiseDetailForm select[disabled!='disabled'][readonly!='readonly'],"+
		                    "   #raiseDetailForm .add_new_customer,.remove_new_customer").attr("disabled","disabled");
					$scope.changeElem=elem;
				},100)
				
			}
		});
		//显示并加载数据
		$("#myModal_detail").modal("show");
		if(entity["raisedAmount"]){
			$("#raisedAmountDxEdit").val(digitUppercase(entity["raisedAmount"]));
		};
		
		
		//设置按钮显示或隐藏
		$("#button_row button").show();
		//编辑
		$("#editRaiseOrder").off().click(function(){
    		var entity = AppUtil.Params("#raiseDetailForm .ng-binding",true);
    		//共同客户信息
    		var pubCusName= new Array;
    		$("#raiseDetailForm .new_customer_list .ng-binding-p[name='customerName']").each(function(index,item){
    			pubCusName[index]=$(item).val();
    		});
    		var pubCusId= new Array;
    		$("#raiseDetailForm .new_customer_list .ng-binding-p[name='customerIdcard']").each(function(index,item){
    			pubCusId[index]=$(item).val();
    		});
    		var pubCusPhone= new Array;
    		$("#raiseDetailForm .new_customer_list .ng-binding-p[name='customerPhone']").each(function(index,item){
    			pubCusPhone[index]=$(item).val();
    		});
    		var jsonItemArr=new Array;
    		$.each(pubCusName,function(i,o){
    				var json={};
    				json.customerName=pubCusName[i];
    				json.customerIdcard=pubCusId[i];
    				json.customerPhone=pubCusPhone[i];
    				json.billNo=$("#raiseDetailForm input[name='raisedNo']").val();
    				json.sourceType='1001';
    				json.createBy=$rootScope.user.userId;
    				jsonItemArr.push(json);
    		});
    		entity.publicCustomerList=jsonItemArr;
    		var config={
	    			sel:".ng-binding,.ng-binding-p",
	    			msgDiv:"#reg_tip_box",
	    			id:"#raiseDetailForm"
	    			};
    		var flag  = ValidF.valid(config);
    		if(flag){
	    		$http.post('raiseOrder/editEntity', entity).success(function(response) {
	    			LoadList();
	    			$("#myModal_detail").modal("hide");
	    			alertMsg("提示", "修改成功");
	    		}).error(function(msg) {
					alertMsg("提示", msg.message);
				});
    		}
    	});
		
		
		
		//详情页里的打印
		$("#printRaiseOrder").off().click(function(){
			var data = $scope.data;
			//判断状态
			if(data.roStatus!='00'&&data.roStatus!='10'&&data.roStatus!='20'){
				return;
			}
			var raiseNo=$("#raiseDetailForm input[name='raisedNo']").val();
			$scope.PrintData(raiseNo,'/print/raise.html');
		});
		
		
		//转定
		$("#changeToEarnest").off().click(function(){
			//判断状态
			if($scope.data.roStatus!='20')
				return;
			$("#myModal_detail").modal("hide");
			$("#raiseEarnestCreate_detail").modal("show");
			var raiseNo=$("#raiseDetailForm input[name='raisedNo']").val();
			//清空表单
			$("#createForm")[0].reset(); 
			$("#raiseEarnestCreate_detail input[name='customerName']").attr("readonly","readonly");
			$("#raiseEarnestCreate_detail input[name='customerIdcard']").attr("readonly","readonly");
			$("#raiseEarnestCreate_detail input[name='customerPhone']").attr("readonly","readonly");
			// 获取初始化数据
	    	$http.get('reservation/createInit').success(function(response) {
	    		$("#raiseEarnestCreate_detail input[name='depositNo']").val(response.data.depositNo.replace(/\"/g,""));
	    		$("#raiseEarnestCreate_detail input[name='created']").val(response.data.created.replace(/\"/g,""));
	    		$("#raiseEarnestCreate_detail input[name='createBy']").val(response.data.createBy.replace(/\"/g,""));
	    		$("#raiseEarnestCreate_detail input[name='receiptNumber']").val(response.data.receiptNumber.replace(/\"/g,""));
	    		
	    		$("#raiseEarnestCreate_detail input[name='customerName']").val(entity["customerName"]);
	    		$("#raiseEarnestCreate_detail input[name='customerIdcard']").val(entity["customerIdcard"]);
	    		$("#raiseEarnestCreate_detail input[name='customerPhone']").val(entity["customerPhone"]);
	    		
	    		
	    		
	    		$scope.rvPayModes=response.data.rvPayModes;
	    		$scope.rvDepositPayModes=response.data.rvDepositPayModes;
	    		$scope.rvStatus=response.data.rvStatus;
	    		$scope.rvBuildings=response.data.rvBuildings;
	    		$scope.zygwEmployee=response.data.zygwEmployee;
	    		$scope.cwgwEmployee=response.data.cwgwEmployee;
	    		$scope.disList=response.data.disList;
	    		$scope.propertyCons = entity['propertyCons'];
	    		$scope.externalCons = entity['externalCons']; 
	    		
	    		$scope.calculatePrice = function(){
	        		$scope.totalHoursPrice = $("#raiseEarnestCreate_detail input[name='subscribedPrice']").val() * $("#raiseEarnestCreate_detail input[name='subscribedArea']").val();
	        	}
	    		//加载认购面积
	    		$("#raiseEarnestCreate_detail input[name='subscribedRoomNo']").off().change(function(){
	    			var recNo = $("#raiseEarnestCreate_detail input[name='subscribedRoomNo']").val();
	    			$http.get('common/loadRoomInfo?roomNo='+recNo).success(function(response) {
	    				var room = response.data;
	    				if(room){
	    					$("#raiseEarnestCreate_detail input[name='subscribedArea']").val(room["basicArea"]);	
	    				}else{
	    					$("#raiseEarnestCreate_detail input[name='subscribedArea']").val("");
	    				}
	    				$("#raiseEarnestCreate_detail input[name='subscribedArea']").change();
	    			}).error(function() {
	    				alertMsg("提示", "系统出错,请稍后重试.");
	    			});
	    		});
	    		
	    		//加载推荐人信息
	    		$("#raiseEarnestCreate_detail input[name='referenceRoomNumer']").off().change(function(){
	    			var recNo = $("#raiseEarnestCreate_detail input[name='referenceRoomNumer']").val();
	    			$http.get('common/loadCusInfo?roomNo='+recNo+"&type="+CON_BILL_TYPE.QYD).success(function(response) {
	    				var customer = response.data;
	    				if(customer){
	    					$("#raiseEarnestCreate_detail input[name='referenceName']").val(customer["recName"]);	
	    				}else{
	    					$("#raiseEarnestCreate_detail input[name='referenceName']").val("");
	    				}
	    			}).error(function() {
	    				alertMsg("提示", "系统出错,请稍后重试.");
	    			});
	    		});
	    	}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
	    	
	    	//新增保存按钮事件
	    	$("#saveReservation").off().click(function(){
	    		var flag  = ValidF.valid({id:"#createForm",sel:".ng-binding",msgDiv:"#add_reg_tip_box"});
	    		if(flag){
		    		var entity = AppUtil.Params("#raiseEarnestCreate_detail .ng-binding",true);
		    		entity.raisedNo=raiseNo;
		    		$http.post('reservation/createReservation', entity).success(function(response) {
		    			alertMsg("提示", "新增成功",function(){
							LoadList();
							$("#raiseEarnestCreate_detail").modal("hide");
						});
		    		}).error(function() {
		    			alertMsg("提示", "系统出错,请稍后重试.");
		    		});
	    		}
	    	});
		});
		
    	
    	
		
		
		//详情里面查看审核流水
    	$("#showDetailCheckList").off().click(function(){
    		
    		getCheckList($scope.data.raisedNo);
    		
    	});
		
		//退筹单创建
		$("#createRaiseCancel").off().click(function(){
			
			$("#myModal_detail").modal("hide");
			$("#raisebackcreate_detail").modal("show");
			
			
			$("#raiseBackCreate_form")[0].reset();
			$("#raisebackcreate_detail input[name='applicantName']").attr("readonly","readonly");
			//加载唯一编码
			$http.get('raiseCancel/getRaiseCancelNo').success(function(response) {
	    		$("#raisebackcreate_detail input[name='cancelNo']").val(response.replace(/\"/g,""));
	    	}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
			
			
			for(key in $scope.detailEntity){
				if(key&&key.indexOf('$')==-1){
					$("#raiseBackCreate_form input[name="+key+"]").val($scope.detailEntity[key]);
					$("#raiseBackCreate_form select[name="+key+"]").val($scope.detailEntity[key]);
				}
			};
			if($scope.detailEntity["raisedAmount"]){
				$("#refundAmountCreateDx").val(digitUppercase($scope.detailEntity["raisedAmount"]));
			};
		});
		
		
		//保存退筹单
		$("#saveRaiseBackOrder").off().click(function(){
			if($scope.data.roStatus!='20')
				return;
			var entity = AppUtil.Params("#raiseBackCreate_form .ng-binding",true);
			var text = $("input:checkbox[name='basicDocument']:checked").map(function(index,elem) {
		            return $(elem).val();
		        }).get().join(',');
			if(text){
				entity['basicDocument']=text;
			};
			
			var config={
	    			sel:".ng-binding",
	    			msgDiv:"#back_reg_tip_box",
	    			id:"#raiseBackCreate_form"
	    			};
    		var flag  = ValidF.valid(config);
    		if(flag){
			    if(!text){
	             	$("#back_reg_tip_box span[class='msg']").html("请选择基本资料");
	 				$("#back_reg_tip_box").show();
	 				setTimeout(function(){$('#back_reg_tip_box').fadeOut()},3000);
	 				return false;
	 			}
				$http.post('raiseCancel/createRaiseCancelOrder', entity).success(function(response) {
	    			LoadList();
	    			$("#raisebackcreate_detail").modal("hide");
	    			alertMsg("提示", "新增成功");
	    		}).error(function() {
	    			alertMsg("提示", "系统出错,请稍后重试.");
	    		});
    		}
		});
		
		
		//转下期
		$("#changeToNext").off().click(function(){
			if($scope.data.roStatus!='20')
				return;
			var entity = AppUtil.Params("#raiseDetailForm .ng-binding",true);
			$("#addraise_modal").modal("show");
			$("#addraise_modal .new_customer:gt(0)").remove();
			$("#myModal_detail").modal("hide");
			$("#addraise_modal input[name='customerName']").attr("readonly","readonly");
			$("#addraise_modal input[name='customerIdcard']").attr("readonly","readonly");
			$("#addraise_modal input[name='customerPhone']").attr("readonly","readonly");
			$http.get('publicCustomer/list?billNo='+$scope.data.raisedNo).success(function(response) {
				$scope.publicCustomerList=response;
			})
			
			// 加载数据方法
	    	$http.get('raiseOrder/getSeqNo').success(function(response) {
	    		$("#addraise_modal input[name='raisedNo']").val(response.raisedNo.replace(/\"/g,""));
	    	}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
	    	for(key in entity){
				if(key&&key.indexOf('$')==-1){
					$("#addraise_form input[name="+key+"]").val(entity[key]);
					$("#addraise_form select[name="+key+"]").val(entity[key]);
				}
			};
			$("#addraise_form input[name='orderNum']").val('');
			//将当前raisedNo设定到隐藏域
			$("#addraise_form input[name='zfxRaisedNo']").val(entity["raisedNo"]);
			
			if(entity["raisedAmount"]){
				$("#raisedAmountDxAdd").val(digitUppercase(entity["raisedAmount"]));
			};
		});
    };
    
    
    // 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
    
});



app.register.service('RaisecreateSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('raiseOrder/listOrder', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});


//新增时触发大写金额
function changeNum(e,changeid){
	$("#"+changeid).val(digitUppercase($(e).val()));
}
