app.register.controller('RaisebackCtrl', function($scope, $rootScope,
		RaisebackSer, AppUtil, $http, $q,$location,$routeParams) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};

	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	
	$http.get("raiseCancel/dicts").success(function(data){
		$scope.cancelStatus=data.data.cancelStatus;
	});
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		RaisebackSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
			setTimeout(check_table_tr,500);
		});
	};
	
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	
	//获取审核流水
	var getCheckList=function(cancelNo){
		
		$http.get('raiseCancel/getRaiseCancelListCheck?cancelNo='+cancelNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	//审核流水
	$scope.showchecklist = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		getCheckList(data.cancelNo);
	};

	
	// 双击跳转明细页面
	$scope.showDetail = function(entity) {
		$scope.c=entity;
		//显示并加载数据
		$("#myModal_detail").modal("show");
		//填充表单
		for(key in entity){
			if(key&&key.indexOf('$')==-1&&key!='basicDocument'){
				$("#raisebacklistdetail_form input[name="+key+"]").val(entity[key]);
			}
		};
		$("#raisebacklistdetail_form textarea[name='remark']").val(entity["remark"]);
		
		
		//大写金额的写入
		if(entity["refundAmount"]){
			$("#refundAmountDetailDx").val(digitUppercase(entity["refundAmount"]));
		};
		
		
		$("input:checkbox").attr("checked", false);
		//加载复选框
		if(entity["basicDocument"]){
			var valueArr=entity["basicDocument"].split(",");
			for (var i=0; i<valueArr.length; i++){
			  $("input:checkbox[value="+valueArr[i]+"]").attr('checked','true');
			}
		}
		//textarea值得写入
		$("#raisebacklistdetail_form textarea[name='raiseOrderRemark']").val(entity["raiseOrderRemark"]);
		
		
		
		 //审核操作
		$("#operate_check").off().click(function(){
			var cancelNo=$("#raisebacklistdetail_form input[name='cancelNo']").val();
			var taskId=$("#raisebacklistdetail_form input[name='taskId']").val();
			var raisedNo=$("#raisebacklistdetail_form input[name='raisedNo']").val();
			var isCfo=$("#raisebacklistdetail_form input[name='isCfo']").val();
			
			$("#operate_raisecancel").modal("show");
			if(isCfo){
				$("#operate_raisecancel div[id='cfoShow']").show();
			}else{
				$("#operate_raisecancel div[id='cfoShow']").hide();
			}
			$("#submitcheck_form")[0].reset();
			$("#submitRaiseCheck").off().click(function(){
				var checked=$("#submitcheck_form input[type='radio']:checked").val();
				var checkRemark=$("#submitcheck_form textarea[name='checkRemark']").val();
				var cfoRemarkDoc='';
				if(isCfo){
					cfoRemarkDoc=$("#submitcheck_form input[type='checkbox'][name='remarkDoc']:checked").map(function(index,elem) {
				            return $.parseJSON($(elem).val());
				        }).get().join(',');;
				}
				$http.get('raiseCancel/audit?cancelNo='+cancelNo+"&checked="+checked+"&checkRemark="+checkRemark+"&taskId="+taskId+"&raisedNo="+raisedNo+"&cfoRemarkDoc="+cfoRemarkDoc).success(function(response) {
					
					$("#myModal_detail").modal("hide");
					$("#operate_raisecancel").modal("hide");
					alertMsg("提示", "审核成功");
					LoadList();
				}).error(function() {
					alertMsg("提示", "系统出错,请稍后重试.");
				});
				
				
			});
		});
		
		//详情里面查看审核流水
    	$("#showDetailCheckList").off().click(function(){
    		var cancelNo=$("#raisebacklistdetail_form input[name='cancelNo']").val();
    		getCheckList(cancelNo);
    		
    	});

    };
   
    // 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
    
});
app.register.service('RaisebackSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('raiseCancel/getRaiseCancelCheckList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	
});
