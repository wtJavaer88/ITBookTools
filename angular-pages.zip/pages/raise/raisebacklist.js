app.register.controller('RaisebacklistCtrl', function($scope, $rootScope,
		RaisebacklistSer, AppUtil, $http, $q,$location,$routeParams) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};

	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	
	$http.get("raiseCancel/dicts").success(function(data){
		$scope.cancelStatus=data.data.cancelStatus;
	});
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		RaisebacklistSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
			setTimeout(check_table_tr,500);
		});
	};
	
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//获取审核流水
	var getCheckList=function(cancelNo){
		
		$http.get('raiseCancel/getRaiseCancelListCheck?cancelNo='+cancelNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	//提交审核
	$scope.submitCheck = function() {
		
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.cancelStatus!=CON_ROSTATUS.WTJ){
			alertMsg("提示", "只能选择未提交的数据.");
			return;
		}
		showconfirm("单据确定提交审核？",
				function(){
			$http.get('raiseCancel/submitCheck?cancelNo='+data.cancelNo).success(function(response) {
				alertMsg("提示", "已成功提交审核.");
				LoadList();
			}).error(function(msg) {
				alertMsg("提示", msg.message);
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});
		
	};
	
	
	//作废
    $scope.nullifyOrder = function() {
    	if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		console.log(CON_ROSTATUS.WTJ);
		if(data.cancelStatus!=CON_ROSTATUS.WTJ&&data.cancelStatus!=CON_ROSTATUS.SHBTG){
			alertMsg("提示", "只有未提交或审核不通过的单据才能作废");
			return;
		}
		
		showconfirm("单据确定作废？",
				function(){
			$http.get('raiseCancel/nullifyOrder?cancelNo='+data.cancelNo+'&raisedNo='+data.raisedNo).success(function(response) {
				if(response.code=='1'){
					alertMsg("提示", "已成功作废");
					LoadList();
				}else{
					alertMsg("提示", response.data);
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});
    };
    
    
    
    //打印
	$scope.printRaiseCancelOrder = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.cancelStatus!=CON_ROSTATUS.WTJ&&data.cancelStatus!=CON_ROSTATUS.DSH&&data.cancelStatus!=CON_ROSTATUS.SHTG){
			alertMsg("提示", "只有未提交、审核中、审核通过的退筹单才能打印");
			return;
		}
		$scope.PrintData(data.cancelNo,'/print/raisecancel.html');
		
	};
	
	//审核流水
	$scope.showchecklist = function() {
		getCheckList($scope.data.cancelNo);
	};
	
	//双击跳转明细页面
	$scope.showDetail = function(entity) {
		if($scope.changeElem){
			$($scope.changeElem).removeAttr("disabled");
		}
		$scope.c=entity;
		if(entity.cancelStatus==CON_ROSTATUS.WTJ){
			$http.post("/common/printCount?",{sourceNo:entity.cancelNo,sourceType:'1011'}).success(function(response){
				$scope.c.printCount=response;
				if($rootScope.user.loginRole!='XSGW'||response!=1){
					var elem=$("#raisebacklistdetail_form").find("input,select,textarea").attr("disabled","disabled");
					$scope.changeElem=elem;
				}
			});
		}
		//显示并加载数据
		$("#myModal_detail").modal("show");
		$("#raisebacklistdetail_form")[0].reset();
		//大写金额的写入
		if(entity["refundAmount"]){
			$("#refundAmountDetailDx").val(digitUppercase(entity["refundAmount"]));
		};
		$("input:checkbox").attr("checked", false);
		//加载复选框
		if(entity["basicDocument"]){
			var valueArr=entity["basicDocument"].split(",");
			for (var i=0; i<valueArr.length; i++){
			  $("input:checkbox[value="+valueArr[i]+"]").attr('checked','true');
			}
		}
		if(entity.cancelStatus!=CON_ROSTATUS.WTJ){
			var elem=$("#raisebacklistdetail_form input[disabled!='disabled'][readonly!='readonly']," +
					"   #raisebacklistdetail_form textarea[disabled!='disabled'][readonly!='readonly']," +
					"   #raisebacklistdetail_form select[disabled!='disabled'][readonly!='readonly']").attr("disabled","disabled");
			$scope.changeElem=elem;
		}
		
		
		
		
		//详情里面查看审核流水
    	$("#showDetailCheckList").off().click(function(){
    		var cancelNo=$("#raisebacklistdetail_form input[name='cancelNo']").val();
    		getCheckList(cancelNo);
    		
    	});
    	
    	//详情里面打印
    	$("#raiseCancelPrint").off().click(function(){
    		var cancelNo=$("#raisebacklistdetail_form input[name='cancelNo']").val();
    		$scope.PrintData(cancelNo,'/print/raisecancel.html');
    	});
		
		//编辑保存
		$("#editRaiseBackOrder").off().click(function(){
			if($scope.data.cancelStatus!=CON_ROCANCEL_STATUS.WTJ)
				return;
			var entity = AppUtil.Params("#myModal_detail .ng-binding",true);
			var text = $("input:checkbox[name='basicDocument']:checked").map(function(index,elem) {
			            return $(elem).val();
			        }).get().join(',');
				entity['basicDocument']=text;
			
				
				
			var config={
	    			sel:".ng-binding",
	    			msgDiv:"#reg_tip_box",
	    			id:"#raisebacklistdetail_form"
	    			};
    		var flag  = ValidF.valid(config);
    		if(flag){	
    			if(!text){
                	$("#reg_tip_box span[class='msg']").html("请选择基本资料");
    				$("#reg_tip_box").show();
    				setTimeout(function(){$('#reg_tip_box').fadeOut()},3000);
    				return false;
    			}
	    		$http.post('raiseCancel/eidtRaiseCancelOrder', entity).success(function(response) {
	    			LoadList();
	    			$("#myModal_detail").modal("hide");
	    			alertMsg("提示", "编辑成功");
	    		}).error(function(msg) {
	    			alertMsg("提示", msg.message);
	    		});
    		}
			
		});
		
    };
    
    // 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
    
});
app.register.service('RaisebacklistSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('raiseCancel/listOrder', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	
});


//新增时触发大写金额
function changeNum(e,changeid){
	$("#"+changeid).val(digitUppercase($(e).val()));
}
