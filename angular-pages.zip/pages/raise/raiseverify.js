app.register.controller('RaiseverifyCtrl', function($scope, $rootScope,
		RaiseverifySer, AppUtil, $http, $q,$location,$routeParams) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};

	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	
	
	$http.get("raiseOrder/dicts").success(function(data){
		$scope.roStatus=data.data.roStatus;
		$scope.payMode=data.data.payMode;
		$scope.hasProve=data.data.hasProve;
		$scope.cashier=data.data.cashier;
		$scope.cashierName=data.data.cashierName;
		$scope.created=data.data.created;
		$scope.salesList=data.data.salesList;
		$scope.cwsalesList=data.data.cwsalesList;
	});
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		RaiseverifySer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			delete $scope.data;
			delete $scope.selectIndex;
			setTimeout(check_table_tr,500);
		});
	};
	
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	// 双击跳转明细页面
	$scope.showDetail = function(entity) {
		$scope.detailEntity=entity;
		$("#raiseDetailForm input").val('');
		$("#raiseDetailForm select").val('');
		$("#raiseDetailForm textarea").val('');
		//显示并加载数据
		$("#myModal_detail").modal("show");
		for(key in entity){
			if(key&&key.indexOf('$')==-1){
				$("#raiseDetailForm input[name="+key+"]").val(entity[key]);
				$("#raiseDetailForm select[name="+key+"]").val(entity[key]);
			}
		};
		$("#raiseDetailForm textarea[name='remark']").val(entity["remark"]);
		if(entity["raisedAmount"]){
			$("#raisedAmountDxEdit").val(digitUppercase(entity["raisedAmount"]));
		};
		$http.get('publicCustomer/list?billNo='+entity.raisedNo).success(function(response) {
			$scope.publicCustomerList=response;
		})
		
		//详情里面查看审核流水
		$("#showDetailCheckList").off().click(function(){
			getCheckList($scope.data.raisedNo);
		});
		
		
		//审核操作
		$("#operate_check").off().click(function(){
			var raisedNo=$("#raiseDetailForm input[name='raisedNo']").val();
			var taskId=$("#raiseDetailForm input[name='taskId']").val();
			$("#operate_raise").modal("show");
			$("#submitcheck_form")[0].reset();
			$("#submitRaiseCheck").off().click(function(){
				var checked=$("#submitcheck_form input[type='radio']:checked").val();
				var checkRemark=$("#submitcheck_form textarea[name='checkRemark']").val();
				
				$http.get('raiseOrder/audit?raisedNo='+raisedNo+"&checked="+checked+"&checkRemark="+checkRemark+"&taskId="+taskId).success(function(response) {
					
					$("#myModal_detail").modal("hide");
					$("#operate_raise").modal("hide");
					alertMsg("提示", "审核成功");
					LoadList();
				}).error(function(msg) {
					alertMsg("提示", msg.message);
				});
				
				
			});
		});
		
		

    };
    
    
    //获取审核流水
	var getCheckList=function(raisedNo){
		$http.get('raiseOrder/getRaiseCheckList?raisedNo='+raisedNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
    
    //审核流水
	$scope.showchecklist = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		getCheckList(data.raisedNo);
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
    
});
app.register.service('RaiseverifySer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('raiseOrder/getRaiseOrderCheckList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	
});
