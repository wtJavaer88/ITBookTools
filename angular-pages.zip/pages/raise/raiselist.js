app.register.controller('RaiselistCtrl', function($scope, $rootScope,
		RaiselistSer, AppUtil, $http, $q,$location,$routeParams) {
	$scope.pagination = {
		currentPage :1,
		itemsPerPage :10
	};

	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	$http.get("raiseOrder/dicts").success(function(data){
		$scope.roStatus=data.data.roStatus;
		$scope.payMode=data.data.payMode;
		$scope.hasProve=data.data.hasProve;
		$scope.cashier=data.data.cashier;
		$scope.cashierName=data.data.cashierName;
		$scope.created=data.data.created;
		$scope.salesList=data.data.salesList;
		$scope.cwsalesList=data.data.cwsalesList;
	});
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		RaiselistSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
			setTimeout(check_table_tr,500);
		});
	};
	
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	
	//获取审核流水
	var getCheckList=function(raisedNo){
		$http.get('raiseOrder/getRaiseCheckList?raisedNo='+raisedNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	
	
	
	//双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#raiseDetailForm")[0].reset();
		$scope.c=entity;
		//显示并加载数据
		$("#myModal_detail").modal("show");
		for(key in entity){
			if(key&&key.indexOf('$')==-1){
				$("#raiseDetailForm input[name="+key+"]").val(entity[key]);
				$("#raiseDetailForm select[name="+key+"]").val(entity[key]);
			}
		};
		$("#raiseDetailForm textarea[name='remark']").val(entity["remark"]);
		if(entity["raisedAmount"]){
			$("#raisedAmountDxEdit").val(digitUppercase(entity["raisedAmount"]));
		};
		$http.get('publicCustomer/list?billNo='+entity.raisedNo).success(function(response) {
			$scope.publicCustomerList=response;
		})

    	//详情里面查看审核流水
    	$("#showDetailCheckList").off().click(function(){
    		
    		var raiseNo=$("#raiseDetailForm input[name='raisedNo']").val();
    		var raiseStatus=$("#raiseDetailForm input[name='roStatus']").val();
    		if(raiseStatus==CON_ROSTATUS.WTJ){
    			getCheckList(raiseNo);
    		}else{
    			getCheckList(raiseNo);
    		}
    		
    	});
    	
    };
    
    //审核流水
	$scope.showchecklist = function() {
		if($scope.data)
			getCheckList($scope.data.raisedNo);
	};
    
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
        
});
app.register.service('RaiselistSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('raiseOrder/listOrder', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});


