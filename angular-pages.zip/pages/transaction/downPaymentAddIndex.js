app.register.controller('DownPayAddIndexCtrl', function($scope, $http, $rootScope,
		$route, DownPayAddIndexSer,SelectSignedOrderSer, AppUtil, $q,$routeParams) {
	
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	
	$scope.paginationSignOrder = {
			currentPage : 1,
			itemsPerPage : 10
	};
	
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		$scope.master=false;
		if ($scope.postData == undefined)
			$scope.postData = {};
//		var params = AppUtil.Params(".form_params");
//		params = $.extend({}, params,$scope.selected);
//		// 当有查询参数时,重置页数
//		if (AppUtil.Length(params) > 0) {
//			if($scope.entity_name != null){
//				params['entity_name'] = $scope.entity_name;
//			}
//			$scope.postData.params = params;
//		}
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		DownPayAddIndexSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.downPayments = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
			setTimeout(check_table_tr,500);
		});
	};
	// 配置分页基本参数
	$scope.$watch('pagination.refresh',LoadList);

	//加载下拉列表数据
	$http.get("downPayment/dicts").success(function(data){
		$scope.downPayStatus=data.data.downPayStatus;
		$scope.payModes=data.data.payModes;
		$scope.loanTypes=data.data.loanTypes;
		$scope.soStatus=data.data.soStatus;
		$scope.salesList=data.data.salesList;
	});
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.downPayments[$scope.selectIndex];
	};
	
	  //提交审核
		$scope.submitCheck = function() {
			if($scope.selectIndex==undefined){
				alertMsg("提示", "请选择一条记录");
				return;
			}
			var data = $scope.data;
			if(data.status!=CON_DP_STATUS.WTJ){
				alertMsg("提示", "只能选择未提交的数据.");
				return;
			}
			showconfirm("单据确定提交审核？",
					function(){
				$http.post('downPayment/submitCheck',data).success(function(response) {
					alertMsg("提示", "已成功提交审核");
					LoadList();
		    	}).error(function(response) {
					alertMsg("提示", response.message);
				});
			},
			function(){
				$("#showConfirm").modal("hide");
				return false;
			});
		};
		//作废
	    $scope.nullifyOrder = function() {
	    	if($scope.selectIndex==undefined){
				alertMsg("提示", "请选择一条记录");
				return;
			}
			var data = $scope.data;
			if(data.status!=CON_DP_STATUS.WTJ && data.status!=CON_DP_STATUS.WTG){
				alertMsg("提示", "只有未提交和审核未通过的单据才能作废");
				return;
			}
			showconfirm("单据确定作废？",function(){
				cancelingDownPay(data,false);
				},function(){
				$("#showConfirm").modal("hide");
				return false;
			});
	    };
	    
	    var cancelingDownPay= function(check_value,closed_win){
	    	$http.post('downPayment/batchNullifyOrder',check_value).success(function(response) {
				alertMsg("提示", "已成功作废");
				if(closed_win){
					$("#myModal_detail").modal("hide");
				}
				LoadList();
			}).error(function(response) {
				alertMsg("提示", response.message);
			});
	    };
		
	    //新增
	    $scope.showAddDownPayModal = function(){
	    	$scope.selectedData = null;
	    	$scope.publicCustomers = null;
	    	$("#addDownPay_form")[0].reset();
	      	$("#add_modal").modal("show");
			// 加载数据方法
	    	$http.get('downPayment/getDownPayNo').success(function(response) {
	    		$("#add_modal input[name='initialNo']").val(response.data.downPayNo.replace(/\"/g,""));
	    		$("#add_modal input[name='created']").val(response.data.createdTime);
	    		$("#add_modal input[name='receiptNumber']").val(response.data.receiptNumber.replace(/\"/g,""));
	    	}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
	    	
	    	
	    	$("#saveDownPayOrder").off().click(function(){
//	    		if(!$scope.selectedData || $scope.selectedData == null){
//	    			alertMsg("提示", "请选择所属的签约单");
//	    			return ;
//	    		}
	    		var entity = AppUtil.Params("#add_modal .ng-binding");
	    		var config={
	        			sel:".ng-binding",
	        			msgDiv:"#addDownPay_tip",
	        			id:"#addDownPay_form"
	        			};
	    		var flag  = ValidF.valid(config);
	    		if(flag){
	    			var textareaVal = $("#addDownPay_form textarea[name='remark']").val();
	    			if(textareaVal != ''){
	    				if(textareaVal.length > 255) {
	    					alertMsg("提示","备注信息不能超过255个字符");
	    					return false;
	    				}
	    			}
	    			$http.post('downPayment/createDownPay', entity).success(function(response) {
	    				LoadList();
	    				$("#add_modal").modal("hide");
	    				alertMsg("提示", "新增成功");
	    			}).error(function() {
	    				alertMsg("提示", "系统出错,请稍后重试.");
	    			});
	    		}
	    	});
	    };
	    
		//打印
		$scope.print = function(){
			if($scope.selectIndex==undefined){
				alertMsg("提示", "请选择一条记录");
				return;
			}
			var data = $scope.data;
			if(data.status!=CON_DP_STATUS.WTJ && data.status!=CON_DP_STATUS.SHZ && data.status!=CON_DP_STATUS.YTG){
				alertMsg("提示", "只能打印未提交/审核中/已通过的单据");
				return;
			}
				$scope.PrintData(data.initialNo,'/print/downpay.html');
		};
	    
	  //审核流水
		$scope.showchecklist = function() {
			if($scope.selectIndex==undefined){
				alertMsg("提示", "请选择一条记录");
				return;
			}
			var data = $scope.data;
			if(data.status==CON_DP_STATUS.WTJ){
				return;
			}
			getCheckList(data.initialNo);
		};
		
		var getCheckList = function(initialNo){
			$http.get('downPayment/getCheckList?initialNo='+initialNo).success(function(response) {
				if(response.data.length>0){
					$scope.comments=response.data;
					$("#show_check_modal").modal("show");
				}else{
					alertMsg("提示", "单据无审核流水.");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		};
	    
	    //双击跳转明细页面
		$scope.showDetail = function(entity) {
			$scope.publicCustomerList = null;
			if($scope.changeElem){
				$($scope.changeElem).removeAttr("disabled");
			}
			$("#myModal_detail form")[0].reset();
			$scope.detailEntity=entity;
			if($scope.detailEntity.payAmount){
				$scope.detailEntity.upperPayAmount=digitUppercase($scope.detailEntity.payAmount);
			}
			
			$http.get('publicCustomer/list?billNo='+entity.signedNo).success(function(response) {
				$scope.publicCustomerList=response;
			})
			if($rootScope.user.loginRole==ROLE_CODE.XSGW && entity.status==CON_DP_STATUS.WTJ){
				$http.post("/common/printCount?",{sourceNo:entity.initialNo,sourceType:'1005'}).success(function(response){
					$scope.detailEntity.printCount=response;
					if(response!=1){
						$scope.changeElem=$("#downpayDetailForm input[disabled!='disabled'][readonly!='readonly']," +
						"   #downpayDetailForm textarea[disabled!='disabled'][readonly!='readonly']," +
						"   #downpayDetailForm select[disabled!='disabled'][readonly!='readonly']").attr("disabled","disabled");
					}
				});
			}else{
				var elem=$("#downpayDetailForm input[disabled!='disabled'][readonly!='readonly']," +
						"   #downpayDetailForm textarea[disabled!='disabled'][readonly!='readonly']," +
						"   #downpayDetailForm select[disabled!='disabled'][readonly!='readonly']").attr("disabled","disabled");
				$scope.changeElem=elem;
			}
			//显示并加载数据
			$("#myModal_detail").modal("show");
			//编辑
			$("#editDownPay").off().click(function(){
	    		var entity = AppUtil.Params("#downpayDetailForm .ng-binding");
	    		var config={
	        			sel:".ng-binding",
	        			msgDiv:"#editDownPay_tip",
	        			id:"#downpayDetailForm"
	        			};
	    		var flag  = ValidF.valid(config);
	    		if(flag){
	    			var textareaVal = $("#downpayDetailForm textarea[name='remark']").val();
	    			if(textareaVal != ''){
	    				if(textareaVal.length > 255) {
	    					alertMsg("提示","备注信息不能超过255个字符");
	    					return false;
	    				}
	    			}
	    			$http.post('downPayment/editDownPay', entity).success(function(response) {
	    				LoadList();
	    				$("#myModal_detail").modal("hide");
	    				alertMsg("提示", "修改成功");
	    			}).error(function(response) {
	    				alertMsg("提示", response.message);
	    			});
	    		}
	    	});
			
			//详情页面打印按钮事件
			$("#printDownPay").off().click(function(){
				$scope.PrintData(entity['initialNo'],'/print/downpay.html');
			});
			
			//详情页面审核流水按钮事件
			$("#checkDownPay").off().click(function(){
	    		getCheckList(entity['initialNo']);
			});
			
			//详情页面作废按钮事件
			$("#nullifyDownPay").off().click(function(){
				var check_value = [];
				check_value.push(entity);
				cancelingDownPay(check_value,true);
			});
			
			
			/*//控制详情页面按钮
			$(".row button").show();
			
			if(entity.status==CON_DP_STATUS.SHZ || entity.status==CON_DP_STATUS.YTG){
				$("#editDownPay").hide();
				$("#nullifyDownPay").hide();
			}
			
			if(entity.status==CON_DP_STATUS.YZF){
				$("#editDownPay").hide();
				$("#nullifyDownPay").hide();
				$("#printDownPay").hide();
			}
			
			if(entity.status==CON_DP_STATUS.WTG){
				$("#editDownPay").hide();
				$("#printDownPay").hide();
			}*/
		};
		
		$scope.selectSignedOrder = function(e){
			$scope.selectedData = e;
			 $scope.confirmSignOrder();
		};
		
		//checkbox单选，并将选中的值存放在selectData变量里
		 $scope.updateSelected = function ($event, e) {
		    	$scope.selected = [];
		  	    $scope.selectedData = null;
		    	var checkbox = $event.target;
		        var action = (checkbox.checked ? 'add' : 'remove');
		        if (action == 'add' & $scope.selected.indexOf(e.signedNo) == -1) {
		        	
		        	for(var i in $scope.contractList){
		        		$scope.contractList[i].checked=false;
		        	}
		        	e.checked = true;
		        	$scope.selected.push(e.signedNo);
		        	$scope.selectedData = e;
		        }
		        if (action == 'remove' & $scope.selected.indexOf(e.signedNo) != -1){
		        	$scope.selected.splice($scope.selected.indexOf(e.signedNo), 1);
		        	e.checked = false;
		        	$scope.selectedData = null;
		        }
		    };
		    //确定选择签约单
		    $scope.confirmSignOrder = function(){
		    	if(!$scope.selectedData || $scope.selectedData == null){
		    		alertMsg("提示", "请选择一个签约单");
		    		return ;
		    	}else{
		    		$http.get('publicCustomer/list?billNo='+$scope.selectedData.signedNo).success(function(response) {
		    			$scope.publicCustomers=response;
		    		})
		    	}
		    	 $("#select_modal").modal("hide");
		    	 $("#add_modal").modal("show");
		    };
		    
		    //取消选择签约单
		    $scope.cancelSignOrder = function(){
		    	$scope.selectedData = null;
		    	 $("#select_modal").modal("hide");
		    	 $("#add_modal").modal("show");
		    };
		    
		    $scope.showSignModal = function(){
		   	 $("#select_modal").modal("show");
		   	 $("#add_modal").modal("hide");
//		   $("#select_modal").css("z-index","1041");
		   	$scope.SearchSignOrder = function() {
				$scope.postDataSignOrder={};
				// 点击查询按钮时,恢复页码为1
				$scope.paginationSignOrder.currentPage = 1;
				// 表单查询参数
				var params = AppUtil.Params('.form_sign_order');
				// 当有查询参数时,重置页数
				if (AppUtil.Length(params) > 0) {
					$scope.postDataSignOrder.params = params;
				}
				LoadListSignOrder();
			};
			
			// 加载数据方法
			var LoadListSignOrder = function() {
				if ($scope.postDataSignOrder == undefined)
					$scope.postDataSignOrder = {};
				$scope.postDataSignOrder.page = $scope.paginationSignOrder.currentPage;
				$scope.postDataSignOrder.size = $scope.paginationSignOrder.itemsPerPage;
				// 加载数据
				SelectSignedOrderSer.list($scope.postDataSignOrder).success(function(response) {
					AppUtil.remove_loading();
					$scope.paginationSignOrder.totalItems = response.total;
					$scope.contractList = response.data;
				});
			};
			// 配置分页监听
			$scope.$watch('paginationSignOrder.refresh', LoadListSignOrder);
		   };
		   
});

app.register.service('DownPayAddIndexSer', function($http,AppUtil) {
	this.list = function(postData) {
		AppUtil.loading();
		//设置查询开始下标
		postData.start= (postData.page-1<0?0:postData.page-1)*postData.size;
		return $http.post('downPayment/list', postData).error(function() {
			AppUtil.remove_loading();
		});
	};

});

app.register.service('SelectSignedOrderSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('signedOrder/selectSignedOrderList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});
