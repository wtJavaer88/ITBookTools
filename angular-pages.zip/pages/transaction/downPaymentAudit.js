app.register.controller('DownPaymentAuditCtrl', function($scope, $http, $rootScope,
		$route, DownPaymentAuditSer, AppUtil, $q,$routeParams) {
	
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		DownPaymentAuditSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.downPayments = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
			setTimeout(check_table_tr,500);
		});
	};
	// 配置分页基本参数
	$scope.$watch('pagination.refresh',LoadList);

//	//加载下拉列表数据
	$http.get("downPayment/dicts").success(function(data){
		$scope.downPayStatus=data.data.downPayStatus;
		$scope.payModes=data.data.payModes;
		$scope.loanTypes=data.data.loanTypes;
		$scope.salesList=data.data.salesList;
	});
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.downPayments[$scope.selectIndex];
	};
	
	$scope.showDetail = function(entity) {
		$scope.publicCustomerList = null;
		$("#myModal_detail form")[0].reset();
		$scope.detailEntity=entity;
		if($scope.detailEntity.payAmount){
			$scope.detailEntity.upperPayAmount=digitUppercase($scope.detailEntity.payAmount);
		}
		
		$http.get('publicCustomer/list?billNo='+entity.signedNo).success(function(response) {
			$scope.publicCustomerList=response;
		})
		//显示并加载数据
		$("#myModal_detail").modal("show");
		//审核操作
		$("#checkOperate").off().click(function(){
			var initialNo = entity['initialNo'];
			var taskId = entity['taskId'];
			var signedRoomNo = entity['signedRoomNo'];
			
				$("#operate_check_modal").modal("show");
				$("#submitcheck_form")[0].reset(); 
				//审核操作点击确定按钮
				$("#sureCheck").off().click(function(){
					var checked=$("#submitcheck_form input[type='radio']:checked").val();
					var checkRemark=$("#submitcheck_form textarea[name='checkRemark']").val();
					$http.get('downPayment/downPayCheck?initialNo='+initialNo+"&checked="+checked+"&checkRemark="+checkRemark+"&taskId="+taskId+"&signedRoomNo="+signedRoomNo).success(function(response) {
						$("#myModal_detail").modal("hide");
						$("#operate_check_modal").modal("hide");
						alertMsg("提示", "审核成功");
						LoadList();
					}).error(function(response) {
						alertMsg("提示", response.message);
					});
				});
		});
		
		//详情页面审核流水按钮事件
		$("#checkDownPay").off().click(function(){
			getCheckList(entity['initialNo']);
		});
		
	};
	
	 //列表页面审核流水按钮
	$scope.showCheck = function(){
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.status==CON_DP_STATUS.WTJ){
			return;
		}
		getCheckList(data.initialNo);
	};
	
    //审核流水
	var getCheckList=function(initialNo){
		$http.get('downPayment/getCheckList?initialNo='+initialNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
});

app.register.service('DownPaymentAuditSer', function($http,AppUtil) {
	this.list = function(postData) {
		AppUtil.loading();
		//设置查询开始下标
		postData.start= (postData.page-1<0?0:postData.page-1)*postData.size;
		return $http.post('downPayment/getDownPayCheckList', postData).error(function() {
			AppUtil.remove_loading();
		});;
	};

});
