app.register.controller('DownPaymentListCtrl', function($scope, $http, $rootScope,
		$route, DownPaymentSer, AppUtil, $q,$routeParams) {
	
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
//		var params = AppUtil.Params(".form_params");
//		// 当有查询参数时,重置页数
//		if (AppUtil.Length(params) > 0) {
//			$scope.postData.params = params;
//		}
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		DownPaymentSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.downPayments = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
			setTimeout(check_table_tr,500);
		});
	};
	// 配置分页基本参数
	$scope.$watch('pagination.refresh',LoadList);

	//表格单击
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.downPayments[$scope.selectIndex];
	}
	
//	//加载下拉列表数据
	$http.get("downPayment/dicts").success(function(data){
		$scope.downPayStatus=data.data.downPayStatus;
		$scope.payModes=data.data.payModes;
		$scope.loanTypes=data.data.loanTypes;
		$scope.salesList=data.data.salesList;
	});
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
	
	 //列表页面审核流水按钮
	$scope.showCheck = function(){
		if($scope.data)
			getCheckList($scope.data.initialNo);
	};
	
	 //审核流水
	var getCheckList=function(initialNo){
		$http.get('downPayment/getCheckList?initialNo='+initialNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "该单据未提交，无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	$scope.showDetail = function(entity) {
		$("#downpayDetailForm")[0].reset();
		$scope.detailEntity=entity;
		if($scope.detailEntity.payAmount){
			$scope.detailEntity.upperPayAmount=digitUppercase($scope.detailEntity.payAmount);
		}
		//显示并加载数据
		$("#myModal_detail").modal("show");
		$http.get('publicCustomer/list?billNo='+entity.signedNo).success(function(response) {
			$scope.publicCustomerList=response;
		})
		//详情页面审核流水按钮事件
		$("#checkDownPay").off().click(function(){
    			getCheckList(entity['initialNo']);
		});
		
	};
});

app.register.service('DownPaymentSer', function($http,AppUtil) {
	this.list = function(postData) {
		AppUtil.loading();
		//设置查询开始下标
		postData.start= (postData.page-1<0?0:postData.page-1)*postData.size;
		return $http.post('downPayment/list', postData).error(function() {
			AppUtil.remove_loading();
		});;
	};

});
