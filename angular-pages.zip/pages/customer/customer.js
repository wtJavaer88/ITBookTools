app.register.controller('CustomerCtrl', function($scope, $rootScope,
		CustomerSer, AppUtil, $http, $q,$location,$routeParams) {
	
	loadFlag($routeParams.id,$scope);
	
	$scope.pagination = {
		currentPage : 1 ,
		itemsPerPage :  10
	};

	$rootScope.$watch('projects',function(){
		if($rootScope.projects==undefined)
			return;
		if($rootScope.projects.length>0)
			$scope.project_no= $scope.projects[0].project_no;
	});

	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		LoadList();
	};
	
	// 加载数据方法
	var LoadList = function() {
		var projectNo;
		if($scope.user.projectNo != undefined && $scope.user.projectNo !='' ){
			projectNo=$scope.user.projectNo;
		}
		else{
			projectNo = $(pno).val();
			if(projectNo == undefined || projectNo ==''){
				return;
			}
		}
		$scope.initData(projectNo);
	}
	
	$scope.initData = function(projectNo){
		
		if ($scope.postData == undefined)
			$scope.postData = {};
		var params = AppUtil.Params("#searchPanel .form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		else{
			params = new Object();
			$scope.postData.params = params;
			params.project_no = projectNo;
		}
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		CustomerSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.customerReports = response.data;
			setTimeout(check_table_tr,500);
		});
	}
	$scope.OpenUrl = function(c){
		location.href="#/customer/detail/"+c.entity_code+"";
	};

	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	

	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
	
	// 双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#myModal_detail").modal("show");
		$("#cus_detail input").val('');
		$("#cus_detail select").val('');
		$("#cus_detail textarea").val('');
		$(".order_no").html("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
		$(".order_statu").html("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
		
		for(key in entity){
			if(key&&key.indexOf('$')==-1){
				$("#baseinfo input[name="+key+"]").val(entity[key]);
				$("#baseinfo select[name="+key+"]").val(entity[key]);
			}
		};
		// 加载数据方法
		AppUtil.loading();
		$http.get('customer/detail?customer_idcard='+entity.customer_idcard).success(function(data) {
			AppUtil.remove_loading();
			if(data.data && data.data.raised_order && data.data.raised_order.length > 0){
				var raised_order = data.data.raised_order[0];
				$("#rcLInk").show();
				$("#rcLInk").trigger("click");
				$("#tabs-1").show();

				$('#raised_order_no').text(raised_order.raised_no);
				$('#raised_order_statu').text(raised_order.ro_statu_name);
				//raised_order_statu
				for(key in raised_order){
					if(key&&key.indexOf('$')==-1){
						$("#tabs-1 input[name="+key+"]").val(raised_order[key]);
						$("#tabs-1 select[name="+key+"]").val(raised_order[key]);
						$("#tabs-1 textarea[name="+key+"]").val(raised_order[key]);
						$("#tabs-1 input[name=raised_amount]").val(formatMoney(raised_order.raised_amount));
						$("#tabs-1 input[name=raised_area]").val(formatMoney(raised_order.raised_area));
					}
				};
			}
			else{
				$("#rcLInk").hide();
				$("#tabs-1").hide();
			}
			
			if(data.data && data.data.deposit_order && data.data.deposit_order.length > 0){
				var deposit_order = data.data.deposit_order[0];
				$("#ydLInk").show();
				$("#ydLInk").trigger("click");
				$("#tabs-2").show();

				$('#deposit_order_no').text(deposit_order.deposit_no);
				$('#deposit_order_statu').text(deposit_order.deposit_statu_name);
				$("#earnest_money_cn").val(digitUppercase(deposit_order["total_earnest_money"]));
				for(key in deposit_order){
					if(key&&key.indexOf('$')==-1){
						$("#tabs-2 input[name="+key+"]").val(deposit_order[key]);
						$("#tabs-2 select[name="+key+"]").val(deposit_order[key]);
						$("#tabs-2 textarea[name="+key+"]").val(deposit_order[key]);
						$("#tabs-2 input[name=subscribed_area]").val(formatMoney(deposit_order.subscribed_area));
						$("#tabs-2 input[name=subscribed_price]").val(formatMoney(deposit_order.subscribed_price));
						$("#tabs-2 input[name=total_earnest_money]").val(formatMoney(deposit_order.total_earnest_money));
					}
				};
			}
			else{
				$("#ydLInk").hide();
				$("#tabs-2").hide();
			}
			
			if(data.data && data.data.signed_order && data.data.signed_order.length > 0){
				var signed_order = data.data.signed_order[0];
				$("#qyLInk").show();
				$("#qyLInk").trigger("click");
				$("#tabs-3").show();
				
				$scope.downpays =  signed_order.downpays;
				$scope.invoices =  signed_order.invoices;
				$('#so_order_no').text(signed_order.signed_no);
				$('#so_order_statu').text(signed_order.so_statu_name);
				for(key in signed_order){
					if(key&&key.indexOf('$')==-1){
						$("#tabs-3 input[name="+key+"]").val(signed_order[key]);
						$("#tabs-3 select[name="+key+"]").val(signed_order[key]);
						$("#tabs-3 textarea[name="+key+"]").val(signed_order[key]);
						$("#tabs-3 input[name=signed_area]").val(formatMoney(signed_order.signed_area));
						$("#tabs-3 input[name=total_signed_price]").val(formatMoney(signed_order.total_signed_price));
						$("#tabs-3 input[name=signed_price]").val(formatMoney(signed_order.signed_price));
						$("#tabs-3 input[name=loan_agree_amount]").val(formatMoney(signed_order.loan_agree_amount));
						$("#tabs-3 input[name=receivable_amount]").val(formatMoney(signed_order.receivable_amount));
						$("#tabs-3 input[name=loan_amount]").val(formatMoney(signed_order.loan_amount));
					}
				};
			}
			else{
				$("#qyLInk").hide();
				$("#tabs-3").hide();
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});

    };
    
    formatMoney = function(input){
		var returnStr = "";
		if(input == undefined){
			return "";
		}
		var re = /\d+\.?\d*/;
		if(re.test(input)){
			var num = input.toFixed(2);
			returnStr=num+"";
			var len = returnStr.length;
			if(num>1000){
				returnStr=returnStr.substring(0,len-6)+","+returnStr.substring(len-6);
			}
			if(num>1000*1000){
				returnStr=returnStr.substring(0,len-9)+","+returnStr.substring(len-9);
			}
		}
	    return returnStr;
	}
});
app.register.service('CustomerSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('customer/list', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	
});
