app.register.controller('CustomerRecepCtrl', function($scope, $rootScope,
		CustomerRecepSer, AppUtil, $http, $q,$location,$routeParams) {
	

	$scope.pagination = {
		currentPage : 1,
		itemsPerPage : 10
	};

	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		CustomerRecepSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.customerInfos = response.data;
			setTimeout(check_table_tr,500);
		});
	};
	
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	//加载下拉列表数据
	$http.get("customerRecep/dicts").success(function(data){
		$scope.customerFroms=data.data.customerFroms;
		$scope.customerTypes=data.data.customerTypes;
		$scope.createTime=data.data.createTime;
		$scope.followUpTypes=data.data.followUpTypes;
		$scope.customerSexs=data.data.customerSexs;
		$scope.intentiontypes=data.data.intentiontypes;
		$scope.salesList=data.data.salesList;
		$scope.outsideSalerList=data.data.outsideSalerList;
	});
	
	// 双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#myModal_detail form")[0].reset();
		$("#myModal_detail").modal("show");
		$scope.detailEntity=entity;
		//编辑按钮
		$("#editCustomerRecep").off().click(function(){
			var config={
        			sel:".ng-binding",
        			msgDiv:"#customerRecep_tip",
        			id:"#customerRecepForm"
        			};
    		var flag  = ValidF.valid(config);
    		var postData = AppUtil.Params("#customerRecepForm .ng-binding");
    		postData.customerSex=$("#customerRecepForm input:radio:checked").val();
    		console.info(postData);
    		if(flag){
    			$http.post('customerRecep/editCustomerRecep', postData).success(function(response) {
    				LoadList();
    				$("#myModal_detail").modal("hide");
    				alertMsg("提示", "修改成功");
    			}).error(function() {
    				alertMsg("提示", "系统出错,请稍后重试.");
    			});
    		}
		});
		
		$("#showFollowUpList").off().click(function(){
			// 加载数据方法
			var postData = {};
			postData.customerNo=entity.customerNo;
			postData.followUpPeo=$rootScope.user.userId;
			AppUtil.loading();
			$http.post('customerRecep/getFollowUpByParams', postData).success(function(response) {
				AppUtil.remove_loading();
				if(response.data.length > 0){
					$scope.followUpList = response.data;
					$("#followUpList_modal").modal("show");
				}else{
					alertMsg("提示", "该用户无跟进信息");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
				AppUtil.remove_loading();
			});
		});
		

    };
    
    //新增客户操作
    $scope.showAddCustomerModal = function(){
    	$scope.customerRecep={};
    	$scope.customerRecep.created=$scope.createTime;
    	$scope.customerRecep.createBy=$rootScope.user.userId;
    	$("#addCustomerRecep_modal").modal("show");
    	//保存按钮
    	$("#addCustomerRecep").off().click(function(){
    		var config={
        			sel:".ng-binding",
        			msgDiv:"#addCustomerRecep_tip",
        			id:"#addCustomerRecep_form"
        			};
    		var flag  = ValidF.valid(config);
    		if(flag){
    			$http.post('customerRecep/saveCustomerRecep', $scope.customerRecep).success(function(response) {
    				LoadList();
    				$("#addCustomerRecep_modal").modal("hide");
    				alertMsg("提示", "新增成功");
    			}).error(function() {
    				alertMsg("提示", "系统出错,请稍后重试.");
    			});
    		}
    	});
    	
    };
   
    //新增跟进信息按钮
    $scope.addCustomerFollowUp = function(customerNo){
    	$("#addFollowUp_modal").modal("show");
    	$scope.customerFollowUp={};
    	$scope.customerFollowUp.followUpPeo=$rootScope.user.userId;
    	$scope.customerFollowUp.customerNo=customerNo;
    	$("#addFollowUp").off().click(function(){
    		$http.post('customerRecep/saveCustomerFollowUp', $scope.customerFollowUp).success(function(response) {
    			LoadList();
    			$("#addFollowUp_modal").modal("hide");
    			alertMsg("提示", "新增成功");
    		}).error(function() {
    			alertMsg("提示", "系统出错,请稍后重试.");
    		});
    	});
    	
    	
    };
});
app.register.service('CustomerRecepSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('customerRecep/list', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	
});
