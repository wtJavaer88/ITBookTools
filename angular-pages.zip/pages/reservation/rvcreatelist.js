app.register.controller('ReservationCreateCtrl', function($scope, $rootScope,
		ReservationCreateSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		delete $scope.selectIndex;
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ReservationCreateSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	}
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	//表格单击
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	//加载字典
	$http.get("reservation/dicts").success(function(data){
		$scope.rvStatus=data.data.rvStatus;
		$scope.rvPayModes=data.data.rvPayModes;
		$scope.rvDepositPayModes=data.data.rvDepositPayModes;
		$scope.rvBuildings=data.data.rvBuildings;
		$scope.zygwEmployee=data.data.zygwEmployee;
		$scope.cwgwEmployee=data.data.cwgwEmployee;
		$scope.disList=data.data.disList;
	});
	
	// 加载数据方法
	var LoadDiscountList = function() {
		$scope.checked = false;
		if ($scope.postData == undefined)
			$scope.postData = {};
		// 加载数据
		AppUtil.Post("/discount/list",$scope.postData,function(response){
			$scope.dispros = response.data;
			$("#add").hide();
			$scope.model=null;
			$("#detail").show();
			$scope.mode = 'view';
			$scope.checked = false;
		});
	};
	
	//双击跳转明细页面
	$scope.showDetail = function(entity) {
		$scope.detail = entity;
		//移除所有共同业主
		$("#detail_modal .remove_new_customer").click();
		
		$http.get('publicCustomer/list?billNo='+entity.depositNo).success(function(response) {
			$scope.publicCustomerList=response;
			if(entity.doStatus==CON_RV_STATUS.WTJ){
				if(($rootScope.user.loginRole == ROLE_CODE.XSGW) || ($rootScope.user.loginRole == ROLE_CODE.XSJL)){
					$http.post("/common/printCount?",{sourceNo:entity.depositNo,sourceType:'1002'}).success(function(response){
						$scope.detail.printCount=response;
						if(response > 1){
							$("#detail_modal .ng-binding").prop('disabled', true);
						}else{
							$("#detail_modal .ng-binding").prop('disabled', false);
						}
					});
				}else{
					$("#detail_modal .ng-binding").prop('disabled', true);
				}
				
			}else{
				$("#detail_modal .ng-binding").prop('disabled', true);
			}
		});
		
		$("#detail_modal form")[0].reset();
		//显示并加载数据
		$("#detail_modal").modal("show");
		if($scope.detail.totalEarnestMoney){
			$scope.detail.totalEarnestMoneyFormat = digitUppercase($scope.detail.totalEarnestMoney);
			$scope.totalHoursPrice = $scope.detail.subscribedPrice * $scope.detail.subscribedArea;
		}
    	
		//加载认购面积
		$("#editForm input[name='subscribedRoomNo']").off().change(function(){
			var recNo = $("#editForm input[name='subscribedRoomNo']").val();
			$http.get('common/loadRoomInfo?roomNo='+recNo).success(function(response) {
				var room = response.data;
				if(room){
					$("#editForm input[name='subscribedArea']").val(room["basicArea"]);	
				}else{
					$("#editForm input[name='subscribedArea']").val("");
				}
				$("#editForm input[name='subscribedArea']").change();
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
		
		//加载推荐人信息
		$("#editForm input[name='referenceRoomNumer']").off().change(function(){
			var recNo = $("#editForm input[name='referenceRoomNumer']").val();
			$http.get('common/loadCusInfo?roomNo='+recNo+"&type="+CON_BILL_TYPE.QYD).success(function(response) {
				var customer = response.data;
				if(customer){
					$("#editForm input[name='referenceName']").val(customer["recName"]);	
				}else{
					$("#editForm input[name='referenceName']").val("");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
		
		$scope.calculatePrice = function(){
    		$scope.totalHoursPrice = $("#editForm input[name='subscribedPrice']").val() * $("#editForm input[name='subscribedArea']").val();
    	}
		
		//编辑按钮事件
		$("#editReservation").off().click(function(){
			var flag  = ValidF.valid({id:"#editForm",sel:".ng-binding,.ng-binding-p",msgDiv:"#edit_reg_tip_box"})
    		if(flag){
	    		var entity = AppUtil.Params("#detail_modal .ng-binding", true);
	    		//共同客户信息
	    		var pubCusName= new Array;
	    		$("#editForm .new_customer_list .ng-binding-p[name='customerName']").each(function(index,item){
	    			pubCusName[index]=$(item).val();
	    		});
	    		var pubCusId= new Array;
	    		$("#editForm .new_customer_list .ng-binding-p[name='customerIdcard']").each(function(index,item){
	    			pubCusId[index]=$(item).val();
	    		});
	    		var pubCusPhone= new Array;
	    		$("#editForm .new_customer_list .ng-binding-p[name='customerPhone']").each(function(index,item){
	    			pubCusPhone[index]=$(item).val();
	    		});
	    		
	    		var jsonItemArr=new Array;
	    		$.each(pubCusName,function(i,o){
	    				var json={};
	    				json.customerName=pubCusName[i];
	    				json.customerIdcard=pubCusId[i];
	    				json.customerPhone=pubCusPhone[i];
	    				json.billNo=entity.depositNo;
	    				json.sourceType='1002';
	    				json.createBy=$rootScope.user.userId;
	    				jsonItemArr.push(json);
	    		});
	    		entity.publicCustomerList=jsonItemArr;
	    		$http.post('reservation/editReservation', entity).success(function(response) {
	    			if(response.code == 1){
		    			alertMsg("提示", "编辑成功",function(){
							LoadList();
							$("#detail_modal").modal("hide");
						});
	    			}else{
	    				alertMsg("提示", response.message);
	    			}
	    		}).error(function() {
	    			alertMsg("提示", "系统出错,请稍后重试.");
	    		});
			}
		});
		
		//退定按钮事件  创建退定单
		$("#createReservationCancel").off().click(function(){
			$("#detail_modal").modal("hide");
			$("#reservation_cancel").modal("show");
			$("#createCancelForm")[0].reset(); 
			
			//加载退定单相关的数据
			$http.get('rvcancel/createInit').success(function(response) {
	    		$("#createCancelForm input[name='cancelNo']").val(response.data.cancelNo.replace(/\"/g,""));//退定单号
	    		$("#createCancelForm input[name='created']").val(response.data.created.replace(/\"/g,""));
	    		$("#createCancelForm input[name='createBy']").val(response.data.createBy.replace(/\"/g,""));
	    		$("#createCancelForm input[name='cancelReceiptNumber']").val(response.data.cancelReceiptNumber.replace(/\"/g,""));
	    		
	    	}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
			
			//将定金单相关信息带入新增退定页面显示
			$("#createCancelForm input[name='depositNo']").val(entity['depositNo']);
			$("#createCancelForm input[name='applicantName']").val(entity['customerName']);
			$("#createCancelForm input[name='offerBuyTime']").val(entity['offerBuyTime']);
			$("#createCancelForm input[name='subscribedRoomName']").val(entity['subscribedRoomName']);
			$("#createCancelForm input[name='subscribedArea']").val(entity['subscribedArea']);
		});
		
		//保存退定单
		$("#saveRvcBtn").off().click(function(){
			var flag  = ValidF.valid({id:"#createCancelForm",sel:".ng-binding",msgDiv:"#cancel_add_reg_tip_box"});
			if(flag){
				var entity = AppUtil.Params("#createCancelForm .ng-binding" , true);
				var text = $("input:checkbox[name='basicDocument']:checked").map(function(index,elem) {
			            return $(elem).val();
			        }).get().join(',');
				if(text.length >0){
					entity['basicDocument']=text;
				}else{
					alertMsg("提示","请勾选基本资料");
					return false;
				}
				$http.post('rvcancel/createRvc', entity).success(function(response) {
	    			LoadList();
	    			$("#reservation_cancel").modal("hide");
	    			alertMsg("提示", "新增退定单成功，请到退定信息列表查询");
	    		}).error(function() {
	    			alertMsg("提示", "系统出错,请稍后重试.");
	    		});
			}
		});
		
		//详情页面打印按钮事件
		$("#printReservation").off().click(function(){
			$scope.PrintData(entity['depositNo'],'/print/reservation.html');
			$("#detail_modal").modal("hide");
		});
		
		//详情页面审核流水按钮事件
		$("#checkReservation").off().click(function(){
			getCheckList(entity['depositNo']);
		});
		
		//转签按钮事件 创建转签单
		$("#createContract").off().click(function(){
			//移除所有共同业主
			$("#contract_dialog .remove_new_customer").click();
			
			$http.get('publicCustomer/list?billNo='+entity.depositNo).success(function(response) {
				$scope.publicCustomerList=response;
			});
			
			$("#contract_dialog").modal("show");
			$("#detail_modal").modal("hide");
			
			$http.get("signedOrder/dicts").success(function(data){
				$scope.payMode=data.data.payMode;
				$scope.userSex=data.data.userSex;
			});
			// 加载数据方法
	    	$http.get('signedOrder/getSignedNo').success(function(response) {
	    		$scope.signedNo=response.replace(/\"/g,"");
	    	}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
	    	
	    	$("#contractadd_form")[0].reset();
	    	
	    	//将定金单相关信息带入转签页面显示
	    	$("#contractadd_form input[name='depositNo']").val(entity['depositNo']);
			$("#contractadd_form input[name='customerName']").val(entity['customerName']);
			$("#contractadd_form input[name='subscribedRoomName']").val(entity['subscribedRoomName']);
			$("#contractadd_form input[name='signedRoomNo']").val(entity['subscribedRoomNo']);
			$("#contractadd_form input[name='signedArea']").val(entity['subscribedArea']);
			$("#contractadd_form input[name='offerBuyTime']").val(entity['offerBuyTime']);
			$("#contractadd_form input[name='customerIdcard']").val(entity['customerIdcard']);
			$("#contractadd_form input[name='customerPhone']").val(entity['customerPhone']);
			$("#contractadd_form input[name='originallyPrice']").val(entity['originallyPrice']);
			$("#contractadd_form input[name='totalOriginallyPrice']").val(entity['totalOriginallyPrice']);
			$("#contractadd_form input[name='signedPrice']").val(entity['originallyPrice']);
			$("#contractadd_form input[name='totalSignedPrice']").val(entity['totalOriginallyPrice']);
			
//			$("#contractadd_form input[name='customerName']").attr("readonly","readonly");
			//转签页面重写选择房号 禁止弹出
			$scope.openSelectRoom = function(clazz) {
				return;
			};
			
			//显示折扣详情单
			$scope.showDiscountWin = function(formId) {
				if(!$("#"+formId+" input[name='signedRoomNo']").val()){
					alertMsg("提示", "请先选择房号");
					return false;
				}
				$("#discount_dialog").modal("show");
				LoadDiscountList();
				var discountProject=$("#"+formId+" input[name='discountProject']").val();
				if(discountProject){
					setTimeout(function(){$("#disproTable tr[value='"+discountProject+"']").click();},500);
				}else{
					setTimeout(function(){$("#disproTable tr").removeAttr("class");},100);
				}
				
				//选择折扣方案
				$("#submitDiscountButton").off().click(function(){
					var dispro_no=$("#contractdiscount_form input[name='dispro_no']").val();
					var dispro_name=$("#contractdiscount_form input[name='dispro_name']").val();
					$.each($scope.dispros,function(i,o){
						if(o.dispro_no==dispro_no){
							$scope.disproMain=o;
						}
					})
					$("#"+formId+" textarea[name='discountRemark']").val($scope.disproMain.dispro_desc);
					$("#"+formId+" input[name='discountProject']").val(dispro_no);
					$("#"+formId+" input[name='discountProjectName']").val(dispro_name);
					var priceEntity=countDiscountPrice($("#"+formId+" input[name='signedArea']").val(),
							                           $("#"+formId+" input[name='totalOriginallyPrice']").val(),
							                           $scope.disproMain);
					
					$("#"+formId+" input[name='signedPrice']").val(priceEntity.price);
					$("#"+formId+" input[name='totalSignedPrice']").val(priceEntity.totalprice);
					$("#discount_dialog").modal("hide");
				});
				
				//清空折扣方案
				$("#clearChooseDiscount").off().click(function(){
					$("#discount_dialog").modal("hide");
					$("#"+formId+" input[name='discountProject']").val('');
					$("#"+formId+" input[name='discountProjectName']").val('');
					$("#"+formId+" input[name='signedPrice']").val('');
					$("#"+formId+" input[name='totalSignedPrice']").val('');
					$("#"+formId+" textarea[name='discountRemark']").val('');
					
					$("#"+formId+" input[name='signedPrice']").val($("#"+formId+" input[name='originallyPrice']").val());
					$("#"+formId+" input[name='totalSignedPrice']").val($("#"+formId+" input[name='totalOriginallyPrice']").val());
				});
				
			};
			
			$scope.selectProject=function(model,target,index){
				$scope.checked = true;
				$scope.model=model;
				$scope.mode="view";
				$scope.selectedIdex=index;
				$scope.detailIdex = undefined;
				$("#detail").show();
				$("#add").hide();
				$scope.viewMode = true;
				if(!model.details){
					$http.get("/discount/details/"+model.dispro_no).success(function(response) {
						if(response.code==1)
							model.details = response.data;
					});
				}
			};
			
			$("#saveButton").off().click(function(){
				var entity = AppUtil.Params("#contractadd_form .input_params" , true);
				//共同客户信息
				var pubCusName= new Array;
				$("#contractadd_form .new_customer_list .input_params_p[name='customerName']").each(function(index,item){
					pubCusName[index]=$(item).val();
				});
				var pubCusId= new Array;
				$("#contractadd_form .new_customer_list .input_params_p[name='customerIdcard']").each(function(index,item){
					pubCusId[index]=$(item).val();
				});
				var pubCusPhone= new Array;
				$("#contractadd_form .new_customer_list .input_params_p[name='customerPhone']").each(function(index,item){
					pubCusPhone[index]=$(item).val();
				});
				var pubCusSex= new Array;
				$("#contractadd_form .new_customer_list .input_params_p[name='customerSex']").each(function(index,item){
					pubCusSex[index]=$(item).val();
				});
				var pubCusBirth= new Array;
				$("#contractadd_form .new_customer_list .input_params_p[name='customerDate']").each(function(index,item){
					pubCusBirth[index]=$(item).val();
				});
				var jsonItemArr=new Array;
				$.each(pubCusName,function(i,o){
						var json={};
						json.customerName=pubCusName[i];
						json.customerIdcard=pubCusId[i];
						json.customerPhone=pubCusPhone[i];
						json.customerSex=pubCusSex[i];
						json.customerBirth=pubCusBirth[i];
						json.billNo=entity.signedNo;
						json.sourceType='1004';
						json.createBy=$rootScope.user.userId;
						jsonItemArr.push(json);
				});
				entity.publicCustomerList=jsonItemArr;
				var flag  = ValidF.valid({id:"#contractadd_form",sel:".input_params,.input_params_p",msgDiv:"#reg_tip_box"});
				if(flag){
					$http.post('signedOrder/createSignedOrder', entity).success(function(response) {
						LoadList();
						$("#contract_dialog").modal("hide");
						alertMsg("提示", "定金单转签约成功");
					}).error(function() {
						alertMsg("提示", "系统出错,请稍后重试.");
					});
				}
			});
		});
		
		//控制详情页面按钮
		$(".row button").show();
		
		if(entity.doStatus==CON_RV_STATUS.WTJ){
			$("#createContract").hide();
			$("#createReservationCancel").hide();
		}
		
		if(entity.doStatus==CON_RV_STATUS.SHZ){
			$("#editReservation").hide();
			$("#createContract").hide();
			$("#createReservationCancel").hide();
		}
		
		if(entity.doStatus==CON_RV_STATUS.YTG){
			$("#editReservation").hide();
		}
		

		if (entity.doStatus == CON_RV_STATUS.WTG
				|| entity.doStatus == CON_RV_STATUS.YZQ
				|| entity.doStatus == CON_RV_STATUS.YTD
				|| entity.doStatus == CON_RV_STATUS.YSC
				|| entity.doStatus == CON_RV_STATUS.YZF) {
			$("#editReservation").hide();
			$("#printReservation").hide();
			$("#createContract").hide();
			$("#createReservationCancel").hide();
		}
		
		//详情页面重写选择房号
		$scope.openSelectRoom1 = function(clazz) {
			if (entity.doStatus != CON_RV_STATUS.WTJ) {
				return;
			}
			$scope.retClazz = clazz;
			AppUtil.openModal('selectRoom', 'selectRoom', $scope);
		};
    };
    
	//新增
    $scope.showAddWin = function(){
		$("#add_dialog").modal("show");
		//清空表单
		$("#createForm")[0].reset(); 
		//移除所有共同业主
		$("#add_dialog .remove_new_customer").click();
		
		// 获取初始化数据
    	$http.get('reservation/createInit').success(function(response) {
    		$("#add_dialog input[name='depositNo']").val(response.data.depositNo.replace(/\"/g,""));
    		$("#add_dialog input[name='created']").val(response.data.created.replace(/\"/g,""));
    		$("#add_dialog input[name='createBy']").val(response.data.createBy.replace(/\"/g,""));
    		$("#add_dialog input[name='receiptNumber']").val(response.data.receiptNumber.replace(/\"/g,""));
    	}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
    	
    	$scope.calculatePrice = function(){
    		$scope.totalHoursPrice = $("#add_dialog input[name='subscribedPrice']").val() * $("#add_dialog input[name='subscribedArea']").val();
    	}
    	//加载认购面积
		$("#createForm input[name='subscribedRoomNo']").off().change(function(){
			var recNo = $("#createForm input[name='subscribedRoomNo']").val();
			$http.get('common/loadRoomInfo?roomNo='+recNo).success(function(response) {
				var room = response.data;
				if(room){
					$("#createForm input[name='subscribedArea']").val(room["basicArea"]);	
				}else{
					$("#createForm input[name='subscribedArea']").val("");
				}
				$("#createForm input[name='subscribedArea']").change();
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
		
    	//加载推荐人信息
		$("#createForm input[name='referenceRoomNumer']").off().change(function(){
			var recNo = $("#createForm input[name='referenceRoomNumer']").val();
			$http.get('common/loadCusInfo?roomNo='+recNo+"&type="+CON_BILL_TYPE.QYD).success(function(response) {
				var customer = response.data;
				if(customer){
					$("#createForm input[name='referenceName']").val(customer["recName"]);
				}else{
					$("#createForm input[name='referenceName']").val("");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
    	//新增保存按钮事件
    	$("#saveReservation").off().click(function(){
    		var flag  = ValidF.valid({id:"#createForm",sel:".ng-binding,.ng-binding-p",msgDiv:"#add_reg_tip_box"})
    		if(flag){
	    		var entity = AppUtil.Params("#add_dialog .ng-binding", true);
	    		
	    		//共同客户信息
	    		var pubCusName= new Array;
	    		$("#createForm .new_customer_list .ng-binding-p[name='customerName']").each(function(index,item){
	    			pubCusName[index]=$(item).val();
	    		});
	    		var pubCusId= new Array;
	    		$("#createForm .new_customer_list .ng-binding-p[name='customerIdcard']").each(function(index,item){
	    			pubCusId[index]=$(item).val();
	    		});
	    		var pubCusPhone= new Array;
	    		$("#createForm .new_customer_list .ng-binding-p[name='customerPhone']").each(function(index,item){
	    			pubCusPhone[index]=$(item).val();
	    		});
	    		
	    		var jsonItemArr=new Array;
	    		$.each(pubCusName,function(i,o){
	    				var json={};
	    				json.customerName=pubCusName[i];
	    				json.customerIdcard=pubCusId[i];
	    				json.customerPhone=pubCusPhone[i];
	    				json.billNo=entity.depositNo;
	    				json.sourceType='1002';
	    				json.createBy=$rootScope.user.userId;
	    				jsonItemArr.push(json);
	    		});
	    		entity.publicCustomerList=jsonItemArr;
	    		
	    		$http.post('reservation/createReservation', entity).success(function(response) {
	    			if(response.code == 1){
		    			alertMsg("提示", "新增成功",function(){
							LoadList();
							$("#add_dialog").modal("hide");
						});
	    			}else{
	    				alertMsg("提示", response.message);
	    			}
	    		}).error(function() {
	    			alertMsg("提示", "系统出错,请稍后重试.");
	    		});
    		}
    	});
    	
    	
	};
	
	//提交审核
	$scope.submitCheck = function(){
		if($scope.data){
			showconfirm("单据确定提交审核？",function(){
				$http.get('reservation/submitCheck?depositNo='+$scope.data.depositNo).success(function(response) {
					if(response.code == 1){
						alertMsg("提示", "已成功提交审核");
						LoadList();
					}else{
						alertMsg("提示", response.message);
					}
				}).error(function(data) {
					alertMsg("提示", data.message);
				});
			},
			function(){
				$("#showConfirm").modal("hide");
				return false;
			});
		}
	};

	//作废
    $scope.toCancel = function() {
    	if($scope.data){
				showconfirm("单据确定作废？",function(){
					var entity={ids:$scope.data.depositNo};
					$http.post('reservation/cancelReservation',entity).success(function(response) {
						if(response.code == 1){
							alertMsg("提示", "已成功作废");
							LoadList();
						}else{
							alertMsg("提示", response.message);
						}
					}).error(function() {
						alertMsg("提示", "系统出错,请稍后重试.");
					});
				},
				function(){
					$("#showConfirm").modal("hide");
					return false;
				});
		}
    };
    
    
    //删除
    $scope.toDelete = function() {
    	if($scope.data){
    		showconfirm("单据确定删除？",function(){
				var entity={ids:$scope.data.depositNo};
				$http.post('reservation/deleteReservation',entity).success(function(response) {
					if(response.code == 1){
						alertMsg("提示", "已成功删除");
						LoadList();
					}else{
						alertMsg("提示", response.message);
					}
				}).error(function() {
					alertMsg("提示", "系统出错,请稍后重试.");
				});
			},
			function(){
				$("#showConfirm").modal("hide");
				return false;
			});
    	}
    };

	//列表页面审核流水按钮
	$scope.showCheck = function(){
		if($scope.data)
			getCheckList($scope.data.depositNo);
	};
	
	//打印
	$scope.print = function(){
		if($scope.data)
			$scope.PrintData($scope.data.depositNo,'/print/reservation.html');
	}
	
	//审核流水
	var getCheckList=function(depositNo){
		$http.get('reservation/getCheckList?depositNo='+depositNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "该单据未提交，无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

function changeNum(e,changeid){
	$("#"+changeid).val(digitUppercase($(e).val()));
}

app.register.service('ReservationCreateSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('reservation/listCreate', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

