app.register.controller('ReservationCancelCtrl', function($scope, $rootScope,
		ReservationCancelSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ReservationCancelSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	}
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	//表格单击
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	//加载字典
	$http.get("rvcancel/dicts").success(function(data){
		$scope.cancelStatus=data.data.cancelStatus;
	});
	
	//双击跳转明细页面
	$scope.showDetail = function(entity) {
		$scope.detail = entity;
		if(entity.cancelStatus==CON_RVC_STATUS.WTJ){
			if(($rootScope.user.loginRole == ROLE_CODE.XSGW) || ($rootScope.user.loginRole == ROLE_CODE.XSJL)){
				$http.post("/common/printCount?",{sourceNo:entity.depositNo,sourceType:'1021'}).success(function(response){
					$scope.detail.printCount=response;
					if(response > 1){
						$("#detail_modal .ng-binding").prop('disabled', true);
					}else{
						$("#detail_modal .ng-binding").prop('disabled', false);
					}
				});
			}else{
				$("#detail_modal .ng-binding").prop('disabled', true);
			}
		}else{
			$("#detail_modal .ng-binding").prop('disabled', true);
		}
		
		$("#detail_modal form")[0].reset();
		//显示并加载数据
		$("#detail_modal").modal("show");
		//编辑按钮事件
		$("#editRvc").off().click(function(){
			var flag  = ValidF.valid({id:"#editForm",sel:".ng-binding",msgDiv:"#cancel_edit_reg_tip_box"});
			if(flag){
				var entity = AppUtil.Params("#editForm .ng-binding", true);
				var text = $("input:checkbox[name='basicDocument']:checked").map(function(index,elem) {
			            return $(elem).val();
			        }).get().join(',');
				if(text.length >0){
					entity['basicDocument']=text;
				}else{
					alertMsg("提示","请勾选基本资料");
					return false;
				}
				//提交修改信息
	    		$http.post('rvcancel/editRvc', entity).success(function(response) {
	    			if(response.code == 1){
		    			alertMsg("提示", "编辑退定单成功",function(){
							LoadList();
							$("#detail_modal").modal("hide");
						});
	    			}else{
	    				alertMsg("提示", response.message);
	    			}
	    		}).error(function() {
	    			alertMsg("提示", "系统出错,请稍后重试.");
	    		});
			}
		});
		
		//详情页面打印按钮事件
		$("#printRvc").off().click(function(){
			$scope.PrintData(entity['cancelNo'],'/print/reservationcancel.html');
			$("#detail_modal").modal("hide");
		});
		
		//详情页面审核流水按钮事件
		$("#checkRvc").off().click(function(){
			getCheckList(entity['cancelNo']);
		});
		
		//控制详情页面按钮
		$(".row button").show();
		if(entity.printCount>0){
			$("#editRvc").hide();
		}
		if(entity.cancelStatus==CON_RVC_STATUS.SHZ || entity.cancelStatus==CON_RVC_STATUS.YTG){
			$("#editRvc").hide();
		}
		if(entity.cancelStatus==CON_RVC_STATUS.WTG || entity.cancelStatus==CON_RVC_STATUS.YSC || entity.cancelStatus==CON_RVC_STATUS.YZF ){
			$("#editRvc").hide();
			$("#printRvc").hide();
		}
    };
    
	//提交审核
	$scope.submitCheck = function(){
		if($scope.data){
				showconfirm("单据确定提交审核？",function(){
					$http.get('rvcancel/submitCheck?cancelNo='+$scope.data.cancelNo).success(function(response) {
						if(response.code == 1){
							alertMsg("提示", "已成功提交审核");
							LoadList();
						}else{
							alertMsg("提示", response.message);
						}
					}).error(function(data) {
						alertMsg("提示", data.message);
					});
				},
				function(){
					$("#showConfirm").modal("hide");
					return false;
				});
		}
	};

	//作废
    $scope.toCancel = function() {
    	if($scope.data){
			showconfirm("单据确定作废？",function(){
				var entity={ids:$scope.data.cancelNo};
				$http.post('rvcancel/cancelRvc',entity).success(function(response) {
					if(response.code == 1){
						alertMsg("提示", "已成功作废");
						LoadList();
					}else{
						alertMsg("提示", response.message);
					}
				}).error(function() {
					alertMsg("提示", "系统出错,请稍后重试.");
				});
			},
			function(){
				$("#showConfirm").modal("hide");
				return false;
			});
		}
    };
    
    
    //删除
    $scope.toDelete = function() {
    	if($scope.data){
    		showconfirm("单据确定删除？",function(){
				var entity={ids:$scope.data.cancelNo};
				$http.post('rvcancel/deleteRvc',entity).success(function(response) {
					if(response.code == 1){
						alertMsg("提示", "已成功删除");
						LoadList();
					}else{
						alertMsg("提示", response.message);
					}
				}).error(function() {
					alertMsg("提示", "系统出错,请稍后重试.");
				});
			},
			function(){
				$("#showConfirm").modal("hide");
				return false;
			});
    	}
    };
    
    //列表页面审核流水按钮
	$scope.showCheck = function(){
		if($scope.data)
			getCheckList($scope.data.cancelNo);
	};
	
	//打印
	$scope.print = function(){
		if($scope.data)
			$scope.PrintData($scope.data.cancelNo,'/print/reservationcancel.html');
	}
	
    //审核流水
	var getCheckList=function(cancelNo){
		$http.get('rvcancel/getCheckList?cancelNo='+cancelNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "该单据未提交，无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('ReservationCancelSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('rvcancel/listCancel', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

