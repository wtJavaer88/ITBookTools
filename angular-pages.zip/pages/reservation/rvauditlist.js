app.register.controller('ReservationAuditCtrl', function($scope, $rootScope,
		ReservationAuditSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ReservationAuditSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
		});
	}
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	//表格单击
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	//加载字典
	$http.get("reservation/dicts").success(function(data){
		$scope.rvStatus=data.data.rvStatus;
		$scope.rvPayModes=data.data.rvPayModes;
		$scope.rvDepositPayModes=data.data.rvDepositPayModes;
		$scope.currentRole=data.data.currentRole;
		$scope.rvBuildings=data.data.rvBuildings;
		$scope.zygwEmployee=data.data.zygwEmployee;
	});
	
	//双击跳转明细页面
	$scope.showDetail = function(entity, role) {
		$("#detail_modal form")[0].reset();
		//显示并加载数据
		$("#detail_modal").modal("show");
		//共同业主
		$http.get('publicCustomer/list?billNo='+entity.depositNo).success(function(response) {
			$scope.publicCustomerList=response;
		});
		
		$scope.detail = entity;
		if($scope.detail.totalEarnestMoney){
			$scope.detail.totalEarnestMoneyFormat = digitUppercase($scope.detail.totalEarnestMoney);
			$scope.totalHoursPrice = $scope.detail.subscribedPrice * $scope.detail.subscribedArea;
		}
		
		//审核操作
		$("#checkOperate").off().click(function(){
			var depositNo = $scope.detail.depositNo;
			var taskId = $scope.detail.taskId;
				//非收银员操作
				$("#operate_check_modal").modal("show");
				$("#submitcheck_form")[0].reset(); 
				//审核操作点击确定按钮
				$("#sureCheck").off().click(function(){
					var flag = ValidF.valid({
						id : "#submitcheck_form",
						sel : ".ng-binding",
						msgDiv : "#audit_tip_box"
					})
					if (flag) {
						var checked=$("#submitcheck_form input[type='radio']:checked").val();
						var checkRemark=$("#submitcheck_form textarea[name='checkRemark']").val();
						$http.get('reservation/reservationCheck?depositNo='+depositNo+"&checked="+checked+"&checkRemark="+checkRemark+"&taskId="+taskId).success(function(response) {
							if(response.code == 1){
								$("#detail_modal").modal("hide");
								$("#operate_check_modal").modal("hide");
								alertMsg("提示", "审核成功");
								LoadList();
							}else{
								alertMsg("提示", response.message);
							}
						}).error(function(data) {
							alertMsg("提示", data.message);
						});
					}
				});
		});
		
		//详情页面审核流水按钮事件
		$("#checkReservation").off().click(function(){
			getCheckList($scope.detail.depositNo);
		});
    };
    
    //列表页面审核流水按钮
	$scope.showCheck = function(){
		if($scope.data)
			getCheckList($scope.data.depositNo);
	};
	
    //审核流水
	var getCheckList=function(depositNo){
		$http.get('reservation/getCheckList?depositNo='+depositNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "该单据未提交，无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('ReservationAuditSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('reservation/listAudit', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

