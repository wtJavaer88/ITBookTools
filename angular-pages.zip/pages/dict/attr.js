app.register.controller('HouseAttrCtrl', function($scope, $http, $rootScope,
		$route, AppUtil, $q,$routeParams) {
	
	//获取本地存储中的页码页数
	$scope.pagination = {
			currentPage :1,
			itemsPerPage : 10
	};
	var flag = true;
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		$scope.postData = AppUtil.Params(".form_params");
		$scope.postData.project_no=$scope.project_no;
		// 表单查询参数
		LoadList();
	};
	$rootScope.$watch('projects',function(){
		if($rootScope.projects==undefined)
			return;
		if($rootScope.projects.length>0){
			$scope.project_no= $scope.projects[0].project_no;
			$scope.SearchData();
		}
	
	});
	
	// 加载数据方法
	var LoadList = function() {
		if(flag){
			 flag = false;
			 return;
		}
		delete $scope.selectIndex;
		if ($scope.postData == undefined)
			$scope.postData = {};
		if(!$scope.postData.project_no)
			return;
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		$scope.postData.start= ($scope.postData.page-1<0?0:$scope.postData.page-1)*$scope.postData.size;
		AppUtil.Post("/attrs/list",$scope.postData,function(response){
			if(response.code==1){
				$scope.pagination.totalItems = response.total;
				$scope.datas = response.data;
			}
		});
	}
	
	
	$http.get('/attrs/types').success(function(response) {
		$scope.attrTypes = response.data;
	});
	
	
	$scope.setSelected=function(index){
		$scope.selectIndex=index;
	}
	
	$scope.setEnabled=function(attr,event){
		var checked = $(event.target).attr("checked");
		var flag = checked?'1':'0';
		
		$http.post('/attrs/update/'+attr.attr_code,{enabled:flag}).success(function(response){
			
			if(response.code==1)
				attr.enabled=flag;
			
		});
		event.stopPropagation();
	}
	$scope.deleteAttr=function(){
		var attr = $scope.datas[$scope.selectIndex];
		showconfirm("是否确认删除属性:"+attr.attr_name+"?",function(){
			$http.get('/attrs/delete/'+attr.attr_code).success(function(response) {
				if(response.code==1)
					LoadList();
			});
		});
	};
	
	$scope.openAttrModal=function(){
		var option = $("#option").val();
		if(option!='add'){
			delete $scope.attr;
		}
	};
	$scope.openAttrModal=function(){
		var option = $("#option").val();
		if(option!='add'){
			$("#attrForm")[0].reset();
			$("#option").val("add");
			$(".modal-title").html("新增字典");
		}
		$("#attrModal").modal("show");
	};
	
	$scope.toEdit=function(){
		var option = $("#option").val("edit");
		$(".modal-title").html("编辑字典");
		var attr = $scope.datas[$scope.selectIndex];
		$("#attr_code").val(attr.attr_code);
		$("#attr_name").val(attr.attr_name);
		$("#attr_type").val(attr.attr_type);
		$("#enabled").val(attr.enabled);
		$("#project_no").val(attr.project_no);
		$("#attrModal").modal("show");
	};
	
	$scope.saveAttr=function(){
		var option = $("#option").val();
		var flag  = ValidF.valid({id:"#attrForm"})
		if(!flag)return;
		var postData = AppUtil.Params(".input_params");
		postData.project_no=$scope.project_no;
		if(option=='add'){
			AppUtil.Post("/attrs/create",postData,function(){
				$("#attrModal").modal("hide");
				$("#attrForm")[0].reset();
				LoadList();
			});
		}else{
			
			AppUtil.Post("/attrs/update/"+$("#attr_code").val(),postData,function(){
				//ValidF.alert("保存成功.");
				$("#attrModal").modal("hide");
				LoadList();
			});
		}
		
	};
	$scope.$watch('pagination.refresh',LoadList);
	
});

