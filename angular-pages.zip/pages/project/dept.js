app.register.controller('DeptCtrl', function($scope, $rootScope,
		DeptSer, AppUtil, $http, $q,$location,$routeParams) {

	$rootScope.$watch('projects',function(){
		if($rootScope.projects==undefined)
			return;
		if($rootScope.projects.length>0)
			$scope.project_no= $scope.projects[0].project_no;
	});
	$scope.$watch('project_no',function(){
		if($scope.project_no!=undefined){
			initData($scope.project_no)
		}
	});
	
	var initData = function(projectNo){
		$('#add_modal_show').show();
		$('#editBt').hide();
		$('#delBt').hide();

		$http.get("dept/roots?pro_no="+projectNo).success(function(data) {
			$scope.rootdepts = data;
		});
		//加载树结构
		$http.get("dept/treeData?pro_no="+projectNo).success(function(data){
			var setting = {
					check: {
						enable: false
					},
					callback: {
						onMouseDown : function(event, treeId, treeNode) {
							if(treeNode!=null){
								$("#checkDept").val(treeNode.id);
								$("#delBt").show();
								$("#editBt").show();
								var obj = treeNode.obj;
								$scope.model=obj;
								$("#headDiv input[name='dept_name']").val(obj.dept_name); 
								$("#headDiv input[name='dept_no']").val(obj.dept_no); 
								if(obj.parent_name!=undefined){
									$("#headDiv select[name='parent_name']").append('<option selected>'+obj.parent_name+'</option>');
								}
								$("#headDiv select[name='root_dept']").val(obj.root_dept);
								$("#headDiv input[name='fund_day']").val(obj.fund_day); 
								$("#headDiv input[name='create_by']").val(obj.create_by_name); 
								$("#headDiv textarea[name='dept_desc']").val(obj.dept_desc); 
							}
						}
					}
			};
			$scope.zNodes=data;
			$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);	
		});
	};
	
	$scope.showAddWin = function() {
		$("#add_modal").modal("show");
		
		var dept_no = $("#dept_no");
		if(dept_no.val()==''){
			$http.get('/dept/nextNo').success(function(data) {
				if(data.code==1)
					dept_no.val(data.data)
				else{
					errorModal();
				}
			}).error(function() {
				errorModal();
			});
		}
	};
	//加载编辑页面
    $scope.edit = function() {
    	$("#edit_modal").modal("show");
    	for(key in $scope.model){
			if(key&&key.indexOf('$')==-1){
				$("#edit_modal input[name="+key+"]").val($scope.model[key]);
				$("#edit_modal select[name="+key+"]").val($scope.model[key]);
				$("#edit_modal textarea[name="+key+"]").val($scope.model[key]);
			}
		};
    };
    $scope.updateDept = function() {
		var flag = ValidF.valid({sel:"#editdept_form .ng-binding",msgDiv:"#reg_tip_box2"});
		if(flag){
			var deptinfo = AppUtil.Params("#editdept_form .ng-binding",true);
			$http.post('dept/updateDept', deptinfo).success(function(response) {
				initData($scope.project_no);
				$("#edit_modal").modal("hide");
				for(key in deptinfo){
					if(key&&key.indexOf('$')==-1){
						$("#headDiv input[name="+key+"]").val(deptinfo[key]);
						$("#headDiv select[name="+key+"]").val(deptinfo[key]);
						$("#headDiv textarea[name="+key+"]").val(deptinfo[key]);
					}
				};
				$("#editdept_form input").val('');
				$("#editdept_form textarea").val('');
				alertMsg("提示", "修改成功");
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		}    	
    };
	 // 保存新部门
    $scope.addDept = function() {
    		var flag = ValidF.valid({id:"#adddept_form",sel:".ng-binding",msgDiv:"#reg_tip_box"});
    		if(flag){
    			var deptinfo = AppUtil.Params("#adddept_form .ng-binding");
    			deptinfo.project_no=$scope.project_no;
    			$http.post('dept/addDept', deptinfo).success(function(response) {
    				console.log($scope.project_no);
    				initData($scope.project_no);
    				$("#add_modal").modal("hide");
					$("#adddept_form input").val('');
					$("#adddept_form textarea").val('');
    				var SelectArr = $(".resetsel")
					for (var i = 0; i < SelectArr.length; i++) {
					  SelectArr[i].options[0].selected = true; 
					}
    				
    				alertMsg("提示", "新增部门成功");
    			}).error(function() {
    				alertMsg("提示", "系统出错,请稍后重试.");
    			});
    		}
    };
    $scope.deleteDept = function() {
    	showconfirm("是否确认删除?",function(){
			var dept_no = $("#checkDept").val();
			var flag = true;
			if(flag){
				$http({url:'dept/deleteDept?dept_no='+dept_no,method:'GET'}).success(function(response) {
					initData($scope.project_no);
					$("#add_modal").modal("hide");
					$("#delBt").hide();
					$("#headDiv .form-control").val("");
					alertMsg("提示", "删除成功");
				}).error(function(data) {
					alertMsg("提示", data.message);
				});
			}
    	});
    };
    
    $scope.formatStr = function(input){
		var returnStr = "";
		if(input == undefined){
			return;
		}
		var itemArr = input.split(";");
		for (var i = 0; i < itemArr.length; i++) {
			var temp = itemArr[i].split(":");
			if(temp.length>1){
				returnStr += temp[1];
			}else{
				returnStr += itemArr[i];
			}
		}
	    return returnStr;
	}
});
app.register.service('DeptSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('dept/list', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});
