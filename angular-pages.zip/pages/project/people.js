app.register
		.controller(
				'PeopleCtrl',
				function($scope, $rootScope, PeopleSer, AppUtil, $http, $q,
						$location, $routeParams, Upload) {
					$scope.pagination = {
						currentPage : 1,
						itemsPerPage : 10
					};
					var flag = true;
					$rootScope.$watch('projects', function() {
						if ($rootScope.projects == undefined)
							return;
						if ($rootScope.projects.length > 0)
							$scope.project_no = $scope.projects[0].project_no;
						if (!flag)
							return;
						$scope.$watch('pagination.refresh', function() {
							if ($scope.project_no != undefined)
								LoadList();
						});
					});
					$scope.$watch('project_no', function() {
						if ($scope.project_no != undefined) {
							if (flag)
								flag = !flag;
							else
								LoadList();
							LoadPosts();
							$http.get("dept/list?pro_no=" + $scope.project_no)
									.success(function(data) {
										$scope.depts = data.data;
									});
						}
					});

					var multiselect;
					var multiselect2;
					var LoadPosts = function() {
						$http
								.get("pos/list?pro_no=" + $scope.project_no)
								.success(
										function(data) {
											$scope.positions = data.data;
											$("#position_add").html("");
											$("#position").html("");
											$.each($scope.positions, function(
													i, o) {
												$("#position_add").append(
														"<option value='"
																+ o.post_no
																+ "'>"
																+ o.post_name
																+ "</option>");
												$("#position").append(
														"<option value='"
																+ o.post_no
																+ "'>"
																+ o.post_name
																+ "</option>");
											})
											if (multiselect) {
												multiselect
														.multiselect("destroy");
											}
											if (multiselect2) {
												multiselect2
														.multiselect("destroy");
											}
											multiselect = $("#position_add")
													.multiselect(
															{
																noneSelectedText : "请选择",
																checkAllText : "全选",
																uncheckAllText : '全不选',
																selectedList : 3,
																minWidth : "100%"
															});
											multiselect2 = $("#position")
													.multiselect(
															{
																noneSelectedText : "请选择",
																checkAllText : "全选",
																uncheckAllText : '全不选',
																selectedList : 3,
																minWidth : "100%"
															});
										});
					};

					var LoadList = function() {
						$('#add_modal_show').show();
						if ($scope.postData == undefined)
							$scope.postData = {};
						$scope.postData.page = $scope.pagination.currentPage;
						$scope.postData.size = $scope.pagination.itemsPerPage;
						$scope.postData.pro_no = $scope.project_no;
						// 加载数据
						PeopleSer
								.list($scope.postData)
								.success(
										function(response) {
											AppUtil.remove_loading();
											$scope.pagination.totalItems = response.total;
											$scope.emplist = response.data;
											setTimeout(check_table_tr, 500);
										});
						// 加载下拉列表数据
					};
					$scope.setSelected = function($index) {
						$('.btn-sm').show();
						$scope.selectIndex = $index;
						$scope.data = $scope.emplist[$scope.selectIndex];
					}
					$scope.showAddWin = function() {
						if ($scope.uploadImg && $scope.uploadImg != '') {
							$('#uploadImg').show();
						} else {
							$('#uploadImg').hide();
						}
						$("#add_modal").modal("show");
						$scope.uploadImg = '';
						var emp_no = $("#emp_no");
						if (emp_no.val() == '') {
							$http.get('/people/nextNo').success(function(data) {
								if (data.code == 1)
									emp_no.val(data.data)
								else {
									errorModal();
								}
							}).error(function() {
								errorModal();
							});
						}

						// 重置复选框各种元素
						$("#position_add option").attr("selected", false);
						$('.ui-multiselect span').text('请选择');
						$('.ui-multiselect-checkboxes :checkbox').attr(
								"checked", false);
						$('.ui-multiselect button').css("width", "120px");
						$('.ui-multiselect-menu').css("width", "120px");
					};
					// 加载新增页面
					$scope.addPeople = function() {
						var flag = ValidF.valid({
							sel : "#addpeople_form .ng-binding",
							msgDiv : "#reg_tip_box"
						});
						if (flag) {
							var peopleinfo = AppUtil
									.Params("#addpeople_form .ng-binding");
							var email = $("#addpeople_form input[name='email']")
									.val();
							var emailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
							if (email.length > 0 && !emailReg.test(email)) {
								alertMsg("提示", "邮箱格式不合法!");
								return;
							}
							var idNoReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
							var id_number = $(
									"#addpeople_form input[name='id_number']")
									.val();
							if (!idNoReg.test(id_number)) {
								alertMsg("提示", "身份证格式不合法!");
								return;
							}
							peopleinfo.project_no = $scope.project_no;
							$http
									.post('people/addPeople', peopleinfo)
									.success(
											function(response) {
												LoadList();
												$("#add_modal").modal("hide");
												var SelectArr = $(".resetsel")
												for (var i = 0; i < SelectArr.length; i++) {
													SelectArr[i].options[0].selected = true;
												}
												$("#addpeople_form input").val(
														'');
												$scope.uploadImg = '';

												alertMsg("提示", "新增成功");
											}).error(function() {
										alertMsg("提示", "系统出错,请稍后重试.");
									});
						}
					};
					// 编辑
					$scope.edit = function() {
						var entity = $scope.data;
						$("#edit_modal").modal("show");
						$("#edit_modal .ng-binding").val('');
						$scope.model = entity;
						$scope.editImg = entity.emp_img;
						if ($scope.editImg && $scope.editImg != '') {
							$('#editImg').show();
						} else {
							$('#editImg').hide();
						}
						var d = entity.dept_no;
						$http
								.get("dept/list?pro_no=" + $scope.project_no)
								.success(
										function(data) {
											$('.dept_sel option').remove();
											$
													.each(
															data.data,
															function(i, o) {
																if (o.dept_no == d) {
																	$(
																			'.dept_sel')
																			.append(
																					"<option selected='selected' value="
																							+ o.dept_no
																							+ ">"
																							+ o.dept_name
																							+ "</option>");
																} else {
																	$(
																			'.dept_sel')
																			.append(
																					"<option value="
																							+ o.dept_no
																							+ ">"
																							+ o.dept_name
																							+ "</option>");
																}
															});
										});

						$("#edit_modal input[name='project_no']").val(
								entity.project_no);
						$("#edit_modal input[name='emp_no']")
								.val(entity.emp_no);
						$("#edit_modal input[name='emp_name']").val(
								entity.emp_name);
						$("#edit_modal input[name='emp_job_no']").val(
								entity.emp_job_no);
						$("#edit_modal input[name='emp_phone']").val(
								entity.emp_phone);
						$("#edit_modal input[name='email']").val(entity.email);
						$("#edit_modal input[name='id_number']").val(
								entity.id_number);
						$("#edit_modal select[name='group_user']").find(
								"option[value='" + entity.group_user + "']")
								.attr("selected", true);
						$("#edit_modal select[name='login']").find(
								"option[value='" + entity.login + "']").attr(
								"selected", true);

						// 重置复选框各种元素
						// 重置复选框各种元素
						$("#position_add option").attr("selected", false);
						$('.ui-multiselect span').text('请选择');
						$('.ui-multiselect-checkboxes :checkbox').attr(
								"checked", false);
						$('.ui-multiselect button').css("width", "120px");
						$('.ui-multiselect-menu').css("width", "120px");

						$http
								.get(
										"people/position?people_no="
												+ entity.emp_no)
								.success(
										function(data) {
											var allpos = [];
											$
													.each(
															data.data,
															function(i, o) {
																allpos
																		.push(o.post_name);
																$("#position")
																		.find(
																				"option[value='"
																						+ o.post_no
																						+ "']")
																		.attr(
																				"selected",
																				true);
																$(
																		".ui-multiselect-checkboxes")
																		.find(
																				"input[value='"
																						+ o.post_no
																						+ "']")
																		.attr(
																				"checked",
																				true);
															});
											$('.ui-multiselect span').text(
													allpos);
										});
					};
					// 打开上传对话框
					$scope.openUpload = function() {
						$("#file").click();
					};
					// 提交
					$scope.submit = function() {
						$scope.upload($scope.file);
					};
					$scope.upload = function(file) {
						var p_id = $("#emp_no").val();
						if (p_id == '') {
							p_id = $("#emp_no_edit").val();
						}
						$scope.fileInfo = file;
						Upload.upload({
							// 服务端接收
							url : 'upload/emp_profiles?p_id=' + p_id,
							// 上传的同时带的参数
							data : {
								project_no : $scope.project_no
							},
							// 上传的文件
							file : file
						}).progress(function(evt) {
						}).success(function(data, status, headers, config) {
							// 上传成功
							$scope.uploadImg = data.path;
							$scope.editImg = data.path;
							$('#uploadImg').show();
							$('#editImg').show();
						}).error(function(data, status, headers, config) {
							// 上传失败
							console.log('error status: ' + status);
						});
					};
					$scope.updatePeople = function() {
						var flag = ValidF.valid({
							sel : "#editpeople_form .ng-binding",
							msgDiv : "#reg_tip_box2"
						});
						if (flag) {
							console.log('复选框' + $('#position').val());
							var peopleinfo = AppUtil.Params(
									"#editpeople_form .ng-binding", true);
							peopleinfo.position = $('#position').val();
							var email = $(
									"#editpeople_form input[name='email']")
									.val();
							var emailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
							if (email.length > 0 && !emailReg.test(email)) {
								alertMsg("提示", "邮箱格式不合法!");
								return;
							}
							var idNoReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
							var id_number = $(
									"#editpeople_form input[name='id_number']")
									.val();
							if (!idNoReg.test(id_number)) {
								alertMsg("提示", "身份证格式不合法!");
								return;
							}

							$http.post('people/updatePeople', peopleinfo)
									.success(function(response) {
										LoadList();
										alertMsg("提示", "更新成功");
										$("#edit_modal").modal("hide");
										$("#editpeople_form input").val('');
										$("#editpeople_form textarea").val('');
										$scope.editImg = '';
									}).error(function() {
										alertMsg("提示", "系统出错,请稍后重试.");
									});
						}
					};

					$scope.deletePeople = function(people_no) {
						var people_no = $scope.data.emp_no;
						showconfirm(
								"是否确认删除?",
								function() {
									var flag = true;
									if (flag) {
										$http(
												{
													url : 'people/deletePeople?people_no='
															+ people_no,
													method : 'GET'
												}).success(function(response) {
											LoadList();
											$("#add_modal").modal("hide");
											alertMsg("提示", "删除成功");
										}).error(function() {
											alertMsg("提示", "系统出错,请稍后重试.");
										});
									}
								});
					};

				});

app.register.service('PeopleSer', function($http, AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('people/list', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};

});
