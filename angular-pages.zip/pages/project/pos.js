app.register.controller('PosCtrl', function($scope, $rootScope,
		 AppUtil, $http, $q,$location,$routeParams) {
	
	
	var LoadAttr = function(){
		$http.get("dept/list?pro_no="+$scope.project_no).success(function(data) {
			$scope.depts = data.data;
		});
		
		var params=new Object();
		params.start=0;
		params.size=10000;
		params.query_str="";
		$http.post("pos/rolesList",params).success(function(data) {
			$scope.sysRoles = data.data;
		});
	}
	$rootScope.$watch('projects',function(){
		if($rootScope.projects==undefined)
			return;
		if($rootScope.projects.length>0)
			$scope.project_no= $scope.projects[0].project_no;
	});
	$scope.$watch('project_no',function(){
		if($scope.project_no!=undefined){
			initData($scope.project_no);
		}
	});
	$scope.$watch('role_code_add',function(){
		watch(1);
	});
	
	$scope.$watch('role_code_edit',function(){
		watch(2);
	});

	watch = function(type){
		var rc = type==1 ? $scope.role_code_add:$scope.role_code_edit;
		var selobj= type==1 ? $("#add_modal select[name='dept_limit']"):$("#edit_modal select[name='dept_limit']");
		console.log("ret:"+isXsRole(rc));
		$(selobj).attr('disabled',!isXsRole(rc));
	}
	isXsRole = function(rc){
		var flag = false;
		if($scope.sysRoles != undefined){
			$.each($scope.sysRoles, function(i, o) {
				if(o.roleId==rc && o.deptLimit){
					console.log(rc+'是限制部门....');
					flag = true;
				}
			});
		}
		return flag;
	}
	initData = function(project_no){
		LoadAttr();
		$('.option_edit li').remove();
		//加载树结构
		$http.get("pos/list?pro_no="+project_no).success(function(data){
			$scope.postdatas = data.data;
			$("#add_modal").hide();
			$scope.model=null;
			$scope.mode = 'view';
			$scope.checked = false;
			$('#add_modal_show').show();
			$('#delBt').hide();
			$('#adjBt').hide();
			$('#editBt').hide();
		});
	};
	
	$scope.selectPost=function(model,target,index){
		$scope.checked = true;
		$scope.model=model;
		$scope.mode="view";
		$('#delBt').show();
		$('#editBt').show();
		$scope.selectedIdex=index;
		$("#add_modal").hide();
		$scope.viewMode = true;
		$('.option_edit li').remove();
		//获取岗位同事信息
		$http.get("pospeople/teammates?post_no="+model.post_no+"&pro_no="+$scope.project_no).success(function(data) {
			$scope.p_members = data.data.members;
			$scope.p_rest = data.data.rest;
		});
	};
	//删除岗位下员工
	$scope.delTeammate=function(val,name){
		$('#adjBt').show();
		$('#user_now li').remove('li[e_no='+val+']');
		$('#user_all').append('<li e_no="'+val+'">'+name+'</li>');
		$('#user_all li').each(function(){
			$(this).unbind();
			$(this).bind('click',function(){
				$scope.addTeammate($(this).attr('e_no'),$(this).text());
			});
		});
	}
	//添加到临时区
	$scope.addTeammate=function(val, name){
		$('#adjBt').show();
		$('#user_all li').remove('li[e_no='+val+']');
		$('#user_add').append('<li e_no="'+val+'">'+name+'</li>');
		$('#user_add li').each(function(){
			$(this).unbind();
			$(this).bind('click',function(){
				backTeammate($(this).attr('e_no'),$(this).text());
			});
		});
	}
	//从临时区返回
	var backTeammate=function(val,name){
		$('#user_add li').remove('li[e_no='+val+']');
		$('#user_all').append('<li e_no="'+val+'">'+name+'</li>');
		$('#user_all li').each(function(){
			$(this).unbind();
			$(this).bind('click',function(){
				$scope.addTeammate($(this).attr('e_no'),$(this).text());
			});
		});
	}
	$scope.showAddWin = function() {
		$("#add_modal").modal("show");
		var post_no = $("#post_no");
		if(post_no.val()==''){
			$http.get('/pos/nextNo').success(function(data) {
				if(data.code==1)
					post_no.val(data.data)
				else{
					errorModal();
				}
			}).error(function() {
				errorModal();
			});
		}
	};
	//加载编辑页面
    $scope.edit = function() {
    	$("#edit_modal").modal("show");
    	
    	$("#edit_modal select[name='dept_no']").val($scope.model.dept_no);
    	$("#edit_modal select[name='role_code']").val($scope.model.role_code);
    	$("#edit_modal select[name='dept_limit']").val($scope.model.dept_limit);
		$("#edit_modal textarea[name='post_desc']").val($scope.model.post_desc);
		$("#edit_modal input[name='post_name']").val($scope.model.post_name);
		$("#edit_modal select[name='dept_limit']").attr('disabled',true);
		$scope.role_code_edit = $scope.model.role_code;
		watch(2);
    };
    $scope.updatePos = function() {
		var flag = ValidF.valid({sel:"#editpos_form .ng-binding",msgDiv:"#reg_tip_box2"});
		if(flag){
			var posinfo = AppUtil.Params("#editpos_form .ng-binding",true);
			$http.post('pos/updatePos', posinfo).success(function(response) {
				initData($scope.project_no);
				$("#edit_modal").modal("hide");
				for(key in posinfo){
					if(key&&key.indexOf('$')==-1){
						$("#headDiv input[name="+key+"]").val(posinfo[key]);
						$("#headDiv select[name="+key+"]").val(posinfo[key]);
						$("#headDiv textarea[name="+key+"]").val(posinfo[key]);
					}
				};
				$("#editpos_form input").val('');
				$("#editpos_form textarea").val('');
				alertMsg("提示", "修改成功");
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		}    	
    };
    
	//加载新增页面
    $scope.addPos = function() {
    		var flag = ValidF.valid({sel:"#addpos_form .ng-binding",msgDiv:"#reg_tip_box"});
    		if(flag){
    			var posinfo = AppUtil.Params("#addpos_form .ng-binding");
    			posinfo.project_no=$scope.project_no;
    			$http.post('pos/addPos', posinfo).success(function(response) {
    				initData($('#pno').val());
    				$("#add_modal").modal("hide");
    				$('.option_edit li').remove();
    				var SelectArr = $(".resetsel")
					for (var i = 0; i < SelectArr.length; i++) {
					  SelectArr[i].options[0].selected = true; 
					}
    				$("#addpos_form input").val('');
    				$("#addpos_form textarea").val('');
    				alertMsg("提示", "新增成功");
    			}).error(function() {
    				alertMsg("提示", "系统出错,请稍后重试.");
    			});
    		}
    };
    $scope.switchPos = function() {
    	var post_no = $scope.model.post_no;
    	var add_emps=new Array();
    	var del_emps=new Array();
    	var arr1=new Array();
    	var arr2=new Array();
    	var emps = $scope.p_members;
    	for(var i=0;i<emps.length;i++){
    		arr1.push(emps[i].emp_no);
    	}
    	$('#user_now li').each(function(){
    		arr2.push($(this).attr('e_no'));
    	});
    	$('#user_add li').each(function(){
    		arr2.push($(this).attr('e_no'));
    	});
    	console.log(arr1.join(','));
    	for(var i=0;i<arr1.length;i++){
    		if(arr2.indexOf(arr1[i]) == -1){
    			console.log(i+'删除...'+arr1[i]);
    			del_emps.push(arr1[i]);
    		}
    	}
    	for(var i=0;i<arr2.length;i++){
    		if(arr1.indexOf(arr2[i]) == -1){
    			console.log('新增...'+arr2[i]);
    			add_emps.push(arr2[i]);
    		}
    	}
    	$http({url:'pospeople/ppswitch?post_no='+post_no+'&add_emps='+add_emps+'&del_emps='+del_emps, method:'GET'}).success(function(response) {
    		alertMsg("提示", "岗位调整成功");
			$http.get("pospeople/teammates?post_no="+post_no+"&pro_no="+$scope.project_no+"&r="+Math.random()).success(function(data) {
				$('.option_edit li').remove();
				$scope.p_members = data.data.members;
				$scope.p_rest = data.data.rest;
			});
		}).error(function(data) {
			alertMsg("提示", "系统错误,请稍后重试.");
		});
    }
    $scope.deletePos = function() {
    	showconfirm("是否确认删除?",function(){
			var pos_no = $("#headDiv input[name='post_no']").val();
			console.log('pos_no:'+pos_no);
			var flag = true;
			if(flag){
				$http({url:'pos/deletePos?pos_no='+pos_no,method:'GET'}).success(function(response) {
    				initData($('#pno').val());
					$("#headDiv .form-control").val("");
					$('.option_edit li').remove();
					alertMsg("提示", "删除成功");
				}).error(function(data) {
					alertMsg("提示", data.message);
				});
			}
    	});
};
    
    $scope.formatStr = function(input){
		var returnStr = "";
		if(input == undefined){
			return;
		}
		var itemArr = input.split(";");
		for (var i = 0; i < itemArr.length; i++) {
			var temp = itemArr[i].split(":");
			if(temp.length>1){
				returnStr += temp[1];
			}else{
				returnStr += itemArr[i];
			}
		}
	    return returnStr;
	}
});
