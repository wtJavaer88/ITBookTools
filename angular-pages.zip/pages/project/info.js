app.register.controller('ProCtrl', function($scope, $rootScope,
		ProSer, AppUtil, $http, $q,$location,$routeParams) {
	
	// 加载数据方法
	var LoadList = function() {
		$("#delBt").hide();
		$("#editBt").hide();
		//加载树结构
		$http.get("project/treeData").success(function(data){
			var setting = {
					check: {
						enable: false
					},
					callback: {
						onMouseDown : function(event, treeId, treeNode) {
							if(treeNode!=null){
								$("#checkPro").val(treeNode.id);
								$("#delBt").show();
								$("#editBt").show();

								var obj = treeNode.obj;
								$scope.model=obj;
								for(key in $scope.model){
									if(key&&key.indexOf('$')==-1){
										$("#headDiv input[name="+key+"]").val(obj[key]);
										$("#headDiv select[name="+key+"]").val(obj[key]);
										$("#headDiv textarea[name="+key+"]").val(obj[key]);
									}
								};
							}
						}
					}
			};
			$scope.zNodes=data;
			$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);	
		});
	}
	
	LoadList();
	
	$scope.showAddWin = function() {
		$("#add_modal").modal("show");
		$http.get("project/roots").success(function(data) {
			$scope.rootpros = data.data;
		});
		var pno = $scope.user.projectNo;
		if(pno != undefined && pno != ''){
			$("#addpro_form select[name=parent_no]").val(pno);
			$("#addpro_form select[name=parent_no]").attr("readonly","readonly").attr("disabled","disabled");
		}
		
		var pro_no=$("#project_no");
		if(pro_no.val()==''){
			$http.get('/project/nextNo').success(function(data) {
				if(data.code==1)
					pro_no.val(data.data)
				else{
					errorModal();
				}
			}).error(function() {
				errorModal();
			});
		}
		
		
	};
	
	 // 保存新部门
    $scope.addPro = function() {
    		var flag = ValidF.valid({sel:"#addpro_form .ng-binding",msgDiv:"#reg_tip_box"});
    		if(flag){
    			var proinfo = AppUtil.Params("#addpro_form .ng-binding");
    			$http.post('project/addPro', proinfo).success(function(response) {
    				if(response.code==1){
    					LoadList();
    					$("#addpro_form input").val('');
    					$("#addpro_form textarea").val('');
    					var SelectArr = $(".resetsel")
    					for (var i = 0; i < SelectArr.length; i++) {
    					  SelectArr[i].options[0].selected = true; 
    					}
    					
    					$("#add_modal").modal("hide");
        				
        				alertMsg("提示", "新增项目成功");
        				var pro = {};
        				pro.project_no=proinfo.project_no;
        				pro.project_name=proinfo.project_name;
        				console.log($rootScope.projects);
        				$rootScope.projects.push(pro);
    				}
    				
    			}).error(function() {
    				alertMsg("提示", "系统出错,请稍后重试.");
    			});
    		}
    };
    
  //加载编辑页面
    $scope.edit = function() {
    	$("#edit_modal").modal("show");
    	for(key in $scope.model){
			if(key&&key.indexOf('$')==-1){
				$("#edit_modal input[name="+key+"]").val($scope.model[key]);
				$("#edit_modal select[name="+key+"]").val($scope.model[key]);
				$("#edit_modal textarea[name="+key+"]").val($scope.model[key]);
			}
		};
		var pno = $scope.user.projectNo;
		if(pno != undefined && pno != ''){
			$("#edit_modal select[name=parent_no]").attr("readonly","readonly").attr("disabled","disabled");
		}
    };
    $scope.updatePro = function() {
		var flag = ValidF.valid({sel:"#editpro_form .ng-binding",msgDiv:"#reg_tip_box2"});
		if(flag){
			var proinfo = AppUtil.Params("#editpro_form .ng-binding",true);
			$http.post('project/updatePro', proinfo).success(function(response) {
				for(key in proinfo){
					if(key&&key.indexOf('$')==-1){
						$("#headDiv input[name="+key+"]").val(proinfo[key]);
						$("#headDiv select[name="+key+"]").val(proinfo[key]);
						$("#headDiv textarea[name="+key+"]").val(proinfo[key]);
					}
				};
				$("#editpro_form input").val('');
				$("#editpro_form textarea").val('');
				LoadList();
				$("#edit_modal").modal("hide");
				alertMsg("提示", "修改成功");
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		}    	
    };
    
    $scope.deletePro = function() {
    	showconfirm("是否确认删除?",function(){
			var pro_no = $("#checkPro").val();
			var flag = true;
			if(flag){
				$http({url:'project/deletePro?pro_no='+pro_no,method:'GET'}).success(function(response) {
					LoadList();
					$("#add_modal").modal("hide");
					$("#delBt").hide();
					$("#editBt").hide();
					$("#headDiv .form-control").val("");
					alertMsg("提示", "删除成功");
				}).error(function(data) {
					alertMsg("提示", data.message);
				});
			}
    	});
    };
    
});
app.register.service('ProSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('pro/list', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});
