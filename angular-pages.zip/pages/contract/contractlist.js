app.register.controller('ContractCreateCtrl', function($scope, $rootScope,
		ContractCreateSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	
	//查询备注历史信息
	$scope.SearchRemarkData=function(){
		var signedNo=$scope.data.signedNo;
		$http.get("/signedOrder/listRemark?signedNo="+signedNo).success(function(data){
			$scope.remarks = data;
			if($scope.remarks.length==0){
				alertMsg("提示", "暂无信息");
				return false;
			}
			$("#show_remark_modal").modal("show");
		});
	}
	
	
	// 加载数据方法
	var LoadDiscountList = function() {
		$scope.checked = false;
		if ($scope.postData == undefined)
			$scope.postData = {};
		// 加载数据
		AppUtil.Post("/discount/list",$scope.postData,function(response){
			$scope.dispros = response.data;
			$("#add").hide();
			$scope.model=null;
			$("#detail").show();
			$scope.mode = 'view';
			$("#disproTable tr").removeAttr("class");
			$scope.checked = false;
		});
	};
	
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ContractCreateSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.conctractList = response.data;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	};
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	$http.get("signedOrder/dicts").success(function(data){
		$scope.payMode=data.data.payMode;
		$scope.userSex=data.data.userSex;
		$scope.soStatus=data.data.soStatus;
		$scope.passStatus=data.data.passStatus;
		$scope.disList=data.data.disList;
		$scope.PaySituation=data.data.PaySituation;
	});
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	
	//获取审核流水
	var getCheckList=function(signedNo){
		$http.get('signedOrder/getSignedCheckList?signedNo='+signedNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	//审核流水
	$scope.showchecklist = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.soStatus==CON_SOSTATUS.WTJ){
			return;
		}
		var data = $scope.data;
		getCheckList(data.signedNo);
	};
	
	//打印
	$scope.printRaiseOrder = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.soStatus==CON_SOSTATUS.WTJ||data.soStatus==CON_SOSTATUS.DSH||data.soStatus==CON_SOSTATUS.SHTG){
			$scope.PrintData(data.signedNo,'/print/signed.html');
		}else{
			alertMsg("提示", "只有未提交、审核中、审核通过的签约单才能打印");
		}
		
	};
	
	//新增
	$("#add_modal_show").click(function(){
		$("#add_dialog").modal("show");
		$("#contractadd_form .new_customer:gt(0)").remove();
		// 加载数据方法
    	$http.get('signedOrder/getSignedNo').success(function(response) {
    		$scope.signedNo=response.replace(/\"/g,"");
    	}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
    	
    	$("#contractadd_form")[0].reset();
    	
    	
		$("#saveButton").off().click(function(){
			var entity = AppUtil.Params("#contractadd_form .input_params",true);
			//共同客户信息
			var pubCusName= new Array;
			$("#contractadd_form .new_customer_list .input_params_p[name='customerName']").each(function(index,item){
				pubCusName[index]=$(item).val();
			});
			var pubCusId= new Array;
			$("#contractadd_form .new_customer_list .input_params_p[name='customerIdcard']").each(function(index,item){
				pubCusId[index]=$(item).val();
			});
			var pubCusPhone= new Array;
			$("#contractadd_form .new_customer_list .input_params_p[name='customerPhone']").each(function(index,item){
				pubCusPhone[index]=$(item).val();
			});
			var pubCusSex= new Array;
			$("#contractadd_form .new_customer_list .input_params_p[name='customerSex']").each(function(index,item){
				pubCusSex[index]=$(item).val();
			});
			var pubCusBirth= new Array;
			$("#contractadd_form .new_customer_list .input_params_p[name='customerDate']").each(function(index,item){
				pubCusBirth[index]=$(item).val();
			});
			var jsonItemArr=new Array;
			$.each(pubCusName,function(i,o){
					var json={};
					json.customerName=pubCusName[i];
					json.customerIdcard=pubCusId[i];
					json.customerPhone=pubCusPhone[i];
					json.customerSex=pubCusSex[i];
					json.customerBirth=pubCusBirth[i];
					json.billNo=entity.signedNo;
					json.sourceType='1004';
					json.createBy=$rootScope.user.userId;
					jsonItemArr.push(json);
			});
			entity.publicCustomerList=jsonItemArr;
			var flag  = ValidF.valid({id:"#contractadd_form",sel:".input_params,.input_params_p",});
			if(flag){
				$http.post('signedOrder/createSignedOrder', entity).success(function(response) {
					LoadList();
					$("#add_dialog").modal("hide");
					alertMsg("提示", "新增成功");
				}).error(function() {
					alertMsg("提示", "系统出错,请稍后重试.");
				});
			}
		});
	});
	//显示折扣详情单
	$scope.showDiscountWin = function(formId) {
		if(!$("#"+formId+" input[name='signedRoomNo']").val()){
			alertMsg("提示", "请先选择房号");
			return false;
		}
		$("#discount_dialog").modal("show");
		LoadDiscountList();
		var discountProject=$("#"+formId+" input[name='discountProject']").val();
		if(discountProject){
			setTimeout(function(){$("#disproTable tr[value='"+discountProject+"']").click();},500);
		}else{
			setTimeout(function(){$("#disproTable tr").removeAttr("class");},100);
		}
		
		//选择折扣方案
		$("#submitDiscountButton").off().click(function(){
			var dispro_no=$("#contractdiscount_form input[name='dispro_no']").val();
			var dispro_name=$("#contractdiscount_form input[name='dispro_name']").val();
			$.each($scope.dispros,function(i,o){
				if(o.dispro_no==dispro_no){
					$scope.disproMain=o;
				}
			})
			$("#"+formId+" textarea[name='discountRemark']").val($scope.disproMain.dispro_desc);
			$("#"+formId+" input[name='discountRole']").val($scope.disproMain.dispro_role);
			$("#"+formId+" input[name='discountProject']").val(dispro_no);
			$("#"+formId+" input[name='discountProjectName']").val(dispro_name);
			var priceEntity=countDiscountPrice($("#"+formId+" input[name='signedArea']").val(),
					                           $("#"+formId+" input[name='totalOriginallyPrice']").val(),
					                           $scope.disproMain);
			
			$("#"+formId+" input[name='signedPrice']").val(priceEntity.price);
			$("#"+formId+" input[name='totalSignedPrice']").val(priceEntity.totalprice);
			$("#discount_dialog").modal("hide");
		});
		
		//清空折扣方案
		$("#clearChooseDiscount").off().click(function(){
			$("#discount_dialog").modal("hide");
			$("#"+formId+" input[name='discountProject']").val('');
			$("#"+formId+" input[name='discountProjectName']").val('');
			$("#"+formId+" input[name='signedPrice']").val('');
			$("#"+formId+" input[name='totalSignedPrice']").val('');
			$("#"+formId+" textarea[name='discountRemark']").val('');
			$("#"+formId+" input[name='discountRole']").val('');
			
			$("#"+formId+" input[name='signedPrice']").val($("#"+formId+" input[name='originallyPrice']").val());
			$("#"+formId+" input[name='totalSignedPrice']").val($("#"+formId+" input[name='totalOriginallyPrice']").val());
		});
		
	};
	
	$scope.selectProject=function(model,target,index){
		$scope.checked = true;
		$scope.model=model;
		$scope.mode="view";
		$scope.selectedIdex=index;
		$scope.detailIdex = undefined;
		$("#detail").show();
		$("#add").hide();
		$scope.viewMode = true;
		if(!model.details){
			$http.get("/discount/details/"+model.dispro_no).success(function(response) {
				if(response.code==1)
					model.details = response.data;
			});
		}
	};
	
	//删除
    $scope.nullifyOrder = function() {
    	if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.soStatus!=CON_SOSTATUS.WTJ){
			alertMsg("提示", "只有未提交的单据才能删除");
			return;
		}
		showconfirm("单据确定删除？",
				function(){
			var entity={signedNo:data.signedNo,soStatus:CON_SOSTATUS.YSC};
			$http.post('signedOrder/bathEditEntity',entity).success(function(response) {
				alertMsg("提示", "已成功删除");
				LoadList();
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});
    };
    
    
    
	
  //提交审核
	$scope.submitCheck = function() {

		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.soStatus!=CON_SOSTATUS.WTJ&&data.soStatus!=CON_SOSTATUS.SHBTG){
			alertMsg("提示", "只能选择未提交或者未通过的数据.");
			return;
		}
		showconfirm("单据确定提交审核？",
				function(){
			$http.get('signedOrder/submitCheck?signedNo='+data.signedNo).success(function(response) {
				alertMsg("提示", "已成功提交审核");
				LoadList();
			}).error(function(msg) {
				alertMsg("提示", msg.message);
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});	
	};
    
	
	
	
	 //双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#contractedit_form .input-group-btn button").removeAttr("disabled");
		$("#contractedit_form .remove_new_customer").removeAttr("disabled");
		$("#contractedit_form .add_new_customer").removeAttr("disabled");
		$scope.c=entity;
		$http.get('publicCustomer/list?billNo='+entity.signedNo).success(function(response) {
			$scope.publicCustomerList=response;
			if(entity.soStatus==CON_ROSTATUS.WTJ){
				$http.post("/common/printCount?",{sourceNo:entity.signedNo,sourceType:'1003'}).success(function(response){
					entity.printCount=response;
					if($rootScope.user.loginRole!='XSGW'||response!=1){
						$("#contractedit_form").find("input,select,textarea,.input-group-btn button").attr("disabled","disabled");
					}
					if(entity.soStatus==CON_SOSTATUS.WTJ&&entity.printCount!=1){
						$("#editButton").hide();
					}
				});
			}
			
			setTimeout(function(){
				//显示并加载数据
				$("#contractedit_form .input_params,#contractedit_form .input_params_p").attr("disabled","disabled");
				if(entity.soStatus!=CON_SOSTATUS.WTJ||entity.printCount!=1){
					$("#editButton").hide();
					$("#contractedit_form .input-group-btn button").attr("disabled","disabled");
					$("#contractedit_form .remove_new_customer").attr("disabled","disabled");
					$("#contractedit_form .add_new_customer").attr("disabled","disabled");
				}
				if(entity.soStatus==CON_SOSTATUS.WTJ&&entity.printCount==1){
					$("#contractedit_form div[id='edit_tabs_1']  .input_params").removeAttr("disabled");
					$("#contractedit_form div[id='edit_tabs_1']  .input_params_p").removeAttr("disabled");
				}
			},100)
			
		})
		var roleCode=$("#roleCode").val();
		//设置按钮显示或隐藏
		$("#button_row button").show();
		if(entity.soStatus==CON_SOSTATUS.WTJ){
            $("#changeToEarnest").hide();
		}else if(entity.soStatus==CON_SOSTATUS.DSH){
			$("#editButton").hide();
			$("#changeToEarnest").hide();
		}else if(entity.soStatus==CON_SOSTATUS.SHTG){
			$("#editButton").hide();
		}else if(entity.soStatus==CON_SOSTATUS.SHBTG){
			$("#editButton").hide();
            $("#printSignedOrder").hide();
            $("#changeToEarnest").hide();
		}else if(entity.soStatus==CON_SOSTATUS.TQZ||entity.soStatus==CON_SOSTATUS.YTQ){
			$("#editButton").hide();
            $("#printSignedOrder").hide();
            $("#changeToEarnest").hide();
		}
		
		//清空表单
		$("#contractedit_form")[0].reset(); 
		//加载关联表信息
		$http.get('signedOrder/getDetailList?signedNo='+entity.signedNo).success(function(response) {
			$scope.SignedInvoice=response.data.SignedInvoice;
			$scope.SignedPaylogDk=response.data.SignedPaylogDk;
			$scope.SignedPaylogWk=response.data.SignedPaylogWk;
			$scope.dowPayOrder=response.data.dowPayOrder;
		});
		
		$("#edit_dialog").modal("show");
		//默认选中第一个tab
		$("#edit_tabs").tabs({active:0});
		$scope.c=entity;
		//angular。js赋值延迟，故这里用jquery赋值
		for(key in entity){
			if(key&&key.indexOf('$')==-1){
				$("#contractedit_form input[name="+key+"][isNumber!='true'] .input_params").val(entity[key]);
				$("#contractedit_form select[name="+key+"] .input_params").val(entity[key]);
				$("#contractedit_form textarea[name="+key+"] .input_params").val(entity[key]);
			}
		};
		$.each($scope.disList,function(i,o){
			if(entity.discountProject==o.dispro_no){
				$("input[name='discountProjectName']").val(o.dispro_name);
				$("input[name='discountProject']").val(o.dispro_no);
			}
		});
		
		
		if(entity.soStatus==CON_SOSTATUS.SHBTG&&roleCode==ROLE_CODE.XSGW){
			$("#editButton").show();
			//如果是驳回的，销售顾问访问，则能改变相关的信息
			$("#contractedit_form div[id='edit_tabs_1']  .input_params[name='customerName']").removeAttr("disabled");
			$("#contractedit_form div[id='edit_tabs_1']  .input_params[name='customerSex']").removeAttr("disabled");
			$("#contractedit_form div[id='edit_tabs_1']  .input_params[name='customerDate']").removeAttr("disabled");
			$("#contractedit_form div[id='edit_tabs_1']  .input_params[name='customerIdcard']").removeAttr("disabled");
			$("#contractedit_form div[id='edit_tabs_1']  .input_params[name='customerAddress']").removeAttr("disabled");
			$("#contractedit_form div[id='edit_tabs_1']  .input_params[name='customerPhone']").removeAttr("disabled");
		}
		
		var signedNo=$scope.c.signedNo;
		
		
		$("#editButton").off().click(function(){
			var editEntity=AppUtil.Params("#contractedit_form div[id='edit_tabs_1'] .input_params",true);
			editEntity.signedNo=signedNo;
			editEntity.soStatus=$scope.c.soStatus;
			editEntity.procId=$scope.c.procId;
			
			//共同客户信息
			var pubCusName= new Array;
			$("#contractedit_form .new_customer_list .input_params_p[name='customerName']").each(function(index,item){
				pubCusName[index]=$(item).val();
			});
			var pubCusId= new Array;
			$("#contractedit_form .new_customer_list .input_params_p[name='customerIdcard']").each(function(index,item){
				pubCusId[index]=$(item).val();
			});
			var pubCusPhone= new Array;
			$("#contractedit_form .new_customer_list .input_params_p[name='customerPhone']").each(function(index,item){
				pubCusPhone[index]=$(item).val();
			});
			var pubCusSex= new Array;
			$("#contractedit_form .new_customer_list .input_params_p[name='customerSex']").each(function(index,item){
				pubCusSex[index]=$(item).val();
			});
			var pubCusBirth= new Array;
			$("#contractedit_form .new_customer_list .input_params_p[name='customerDate']").each(function(index,item){
				pubCusBirth[index]=$(item).val();
			});
			var jsonItemArr=new Array;
			$.each(pubCusName,function(i,o){
					var json={};
					json.customerName=pubCusName[i];
					json.customerIdcard=pubCusId[i];
					json.customerPhone=pubCusPhone[i];
					json.customerSex=pubCusSex[i];
					json.customerBirth=pubCusBirth[i];
					json.billNo=editEntity.signedNo;
					json.sourceType='1004';
					json.createBy=$rootScope.user.userId;
					jsonItemArr.push(json);
			});
			editEntity.publicCustomerList=jsonItemArr;
			var config={
	    			sel:"div[id='edit_tabs_1'] .input_params,div[id='edit_tabs_1'] .input_params_p",
	    			msgDiv:"#edit_reg_tip_box",
	    			id:"#contractedit_form"
	    	};
			var flag  = ValidF.valid(config);
			if(flag){
				$http.post('signedOrder/editEntity', editEntity).success(function(response) {
					LoadList();
					$("#edit_dialog").modal("hide");
					alertMsg("提示", "编辑成功");
				}).error(function(msg) {
	    			alertMsg("提示", msg.message);
	    		});
			}
		});
		

		//详情里面查看审核流水
		$("#showDetailCheckList").off().click(function(){
			var signedNo=$("#contractedit_form input[name='signedNo']").val();
			var soStatus=$("#contractedit_form input[name='soStatus']").val();
			if(soStatus==CON_SOSTATUS.WTJ){
				getCheckList(signedNo);
			}else{
				getCheckList(signedNo);
			}
			
		});
		
		//详情页里的打印
		$("#printSignedOrder").off().click(function(){
			var raiseNo=$("#contractedit_form input[name='signedNo']").val();
			$scope.PrintData(raiseNo,'/print/signed.html');
		});
		
		//详情里面退房
		$("#changeToEarnest").off().click(function(){
			$("#edit_dialog").modal("hide");
			$("#signedbackcreate_detail").modal("show");
			
			$("#signedBackCreate_form")[0].reset();
			//加载唯一编码
			$http.get('signedCancel/getSignedCancelNo').success(function(response) {
	    		$("#signedBackCreate_form input[name='cancelNo']").val(response.replace(/\"/g,""));
	    	}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
			
			
			for(key in entity){
				if(key&&key.indexOf('$')==-1){
					$("#signedBackCreate_form input[name="+key+"]").val(entity[key]);
				}
			};
			var date=new Date();
			var month=(date.getMonth()+1)>9?(date.getMonth()+1):"0"+(date.getMonth()+1);
			var day=(date.getDate())>9?(date.getDate()):"0"+(date.getDate());
			var dataStr=date.getFullYear()+"-"+month+"-"+day;
			$("#applyDate").val(dataStr);
			
		});
		
		
		
		//保存退房单
		$("#saveSignedBackOrder").off().click(function(){
			var entity = AppUtil.Params("#signedBackCreate_form .ng-binding",true);
			var text = $("input:checkbox[name='basicDocument']:checked").map(function(index,elem) {
		            return $(elem).val();
		        }).get().join(',');
			if(text){
				entity['basicDocument']=text;
			};
			
			var config={
	    			sel:".ng-binding",
	    			msgDiv:"#back_reg_tip_box",
	    			id:"#signedBackCreate_form"
	    			};
    		var flag  = ValidF.valid(config);
    		
    		if(flag){
				$http.post('signedCancel/createSignedCancelOrder', entity).success(function(response) {
	    			LoadList();
	    			$("#signedbackcreate_detail").modal("hide");
	    			alertMsg("提示", "新增成功");
	    		}).error(function() {
	    			alertMsg("提示", "系统出错,请稍后重试.");
	    		});
    		}
		});
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('ContractCreateSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('signedOrder/listOrder', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});

