app.register.controller('ContractCtrl', function($scope, $rootScope,
		ContractSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ContractSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.contractList = response.data;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	};
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	$http.get("signedOrder/dicts").success(function(data){
		$scope.payMode=data.data.payMode;
		$scope.userSex=data.data.userSex;
		$scope.soStatus=data.data.soStatus;
		$scope.passStatus=data.data.passStatus;
		$scope.disList=data.data.disList;
		$scope.PaySituation=data.data.PaySituation;
		
	});
	
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//查询备注历史信息
	$scope.SearchRemarkData=function(){
		var signedNo=$scope.data.signedNo;
		$http.get("/signedOrder/listRemark?signedNo="+signedNo).success(function(data){
			$scope.remarks = data;
			if($scope.remarks.length==0){
				alertMsg("提示", "暂无信息");
				return false;
			}
			$("#show_remark_modal").modal("show");
		});
	}
	
	//获取审核流水
	var getCheckList=function(signedNo){
		$http.get('signedOrder/getSignedCheckList?signedNo='+signedNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	//审核
	$scope.showchecklist = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.soStatus==CON_SOSTATUS.WTJ){
			return;
		}
		var data = $scope.data;
		getCheckList(data.signedNo);
	};
	
	
	
	//双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#detail_dialog").modal("show");
		$scope.c=entity;
		//默认选中第一个tab
		$("#edit_tabs").tabs({active:0});
		//清空表单
		$("#contractdetail_form")[0].reset(); 
		$http.get('signedOrder/getDetailList?signedNo='+entity.signedNo).success(function(response) {
			$scope.SignedInvoice=response.data.SignedInvoice;
			$scope.SignedPaylogDk=response.data.SignedPaylogDk;
			$scope.SignedPaylogWk=response.data.SignedPaylogWk;
			$scope.dowPayOrder=response.data.dowPayOrder;
		});
		
		$http.get('publicCustomer/list?billNo='+entity.signedNo).success(function(response) {
			$scope.publicCustomerList=response;
			
			
			setTimeout(function(){
				//angular。js赋值延迟，故这里用jquery赋值
				$("#contractdetail_form input").attr("disabled","disabled");
				$("#contractdetail_form select").attr("disabled","disabled");
				$("#contractdetail_form textarea").attr("disabled","disabled");
				$("#contractdetail_form .input-group-btn button").attr("disabled","disabled");
				$("#contractdetail_form").find(".remove_new_customer,.add_new_customer").remove();
			},100)
			for(key in entity){
				if(key&&key.indexOf('$')==-1){
					$("#contractdetail_form input[name="+key+"]").val(entity[key]);
					$("#contractdetail_form select[name="+key+"]").val(entity[key]);
					$("#contractdetail_form textarea[name="+key+"]").val(entity[key]);
				}
			};
		});
		
		
		$.each($scope.disList,function(i,o){
			if(entity.discountProject==o.dispro_no){
				$("input[name='discountProjectName']").val(o.dispro_name);
				$("input[name='discountProject']").val(o.dispro_no);
			}
		});
		
		//详情里面查看审核流水
		$("#showDetailCheckList").off().click(function(){
			var signedNo=$("#contractdetail_form input[name='signedNo']").val();
			var soStatus=$("#contractdetail_form input[name='soStatus']").val();
			if(soStatus==CON_SOSTATUS.WTJ){
				getCheckList(signedNo);
			}else{
				getCheckList(signedNo);
			}
			
		});
	};

	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('ContractSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('signedOrder/listOrder', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

