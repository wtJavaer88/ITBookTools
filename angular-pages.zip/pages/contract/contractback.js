app.register.controller('ContractBackCtrl', function($scope, $rootScope,
		ContractBackSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ContractBackSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.contractBacklist = response.data;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	};
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	
	$http.get("signedCancel/dicts").success(function(data){
		$scope.cancelStatus=data.data.cancelStatus;
		$scope.PaySituation=data.data.PaySituation;
	});
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//获取审核流水
	var getCheckList=function(cancelNo){
		$http.get('signedCancel/getSignedCancelListCheck?cancelNo='+cancelNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	//审核流水
	$scope.showchecklist = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.cancelStatus==CON_ROCANCEL_STATUS.WTJ){
			return;
		}
		var data = $scope.data;
		getCheckList(data.cancelNo);
	};
	
	
	//打印
	$scope.printSignedCancelOrder = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.cancelStatus==CON_ROCANCEL_STATUS.WTJ||data.cancelStatus==CON_ROCANCEL_STATUS.DSH||data.cancelStatus==CON_ROCANCEL_STATUS.SHTG){
			$scope.PrintData(data.cancelNo,'/print/signedcancel.html');
		}else{
			alertMsg("提示", "只有未提交、审核中、审核通过的退房单才能打印");
		}
		
	};
	
	
	 //作废
    $scope.nullifyOrder = function() {
    	if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.cancelStatus!=CON_ROCANCEL_STATUS.WTJ&&data.cancelStatus!=CON_ROCANCEL_STATUS.SHBTG){
			alertMsg("提示", "只有未提交或未通过的单据才能作废");
			return;
		}
		showconfirm("单据确定作废？",
				function(){
			var entity={cancelNo:data.cancelNo,cancelStatus:CON_ROCANCEL_STATUS.YZF,signedNo:data.signedNo};
			$http.post('signedCancel/bathEditEntity',entity).success(function(response) {
				alertMsg("提示", "已成功作废");
				LoadList();
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});
    };
    
    
  //提交审核
	$scope.submitCheck = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.cancelStatus!=CON_ROCANCEL_STATUS.WTJ){
			alertMsg("提示", "只能选择未提交的数据.");
			return;
		}
		showconfirm("单据确定提交审核？",
				function(){
			$http.get('signedCancel/submitCheck?cancelNo='+data.cancelNo).success(function(response) {
				alertMsg("提示", "已成功提交审核");
				LoadList();
			}).error(function(msg) {
				alertMsg("提示", msg.message);
			});
		},
		function(){
			$("#showConfirm").modal("hide");
			return false;
		});	
	};
	
    
  //双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#signedBackDetail_form")[0].reset();
		//设置按钮显示或隐藏
		$("#button_row button").show();
		if(entity.cancelStatus==CON_ROCANCEL_STATUS.DSH){
			$("#editSignedCancelOrder").hide();
		}else if(entity.cancelStatus==CON_ROCANCEL_STATUS.SHTG){
			$("#editSignedCancelOrder").hide();
		}else if(entity.cancelStatus==CON_ROCANCEL_STATUS.SHBTG){
			$("#editSignedCancelOrder").hide();
			$("#printSignedCancelOrder").hide();
		}else if(entity.cancelStatus==CON_ROCANCEL_STATUS.YZF){
			$("#editSignedCancelOrder").hide();
			$("#printSignedCancelOrder").hide();
			$("#showDetailCheckList").hide();
		}
		if(entity.cancelStatus==CON_ROCANCEL_STATUS.WTJ){
			$http.post("/common/printCount?",{sourceNo:entity.cancelNo,sourceType:'1031'}).success(function(response){
				entity.printCount=response;
				if($rootScope.user.loginRole!='XSGW'||response!=1){
					$("#signedBackDetail_form").find("input,select,textarea").attr("disabled","disabled");
				}
				if(entity.cancelStatus==CON_ROCANCEL_STATUS.WTJ&&entity.printCount!=1){
					$("#editSignedCancelOrder").hide();
				}
			});
		}
		if(entity.cancelStatus!=CON_ROCANCEL_STATUS.WTJ){
			$("#signedBackDetail_form .ng-binding").attr("disabled","disabled");
		}
		
		
		$scope.detailEntity=entity;
		//显示并加载数据
		$("#edit_dialog").modal("show");
		for(key in entity){
			if(key&&key.indexOf('$')==-1&&key!='basicDocument'){
				$("#signedBackDetail_form input[name="+key+"]").val(entity[key]);
				$("#signedBackDetail_form textarea[name="+key+"]").val(entity[key]);
				$("#signedBackDetail_form select[name="+key+"]").val(entity[key]);
			}
		};
		
		$("input:checkbox").attr("checked", false);
		//加载复选框
		if(entity["basicDocument"]){
			var valueArr=entity["basicDocument"].split(",");
			for (var i=0; i<valueArr.length; i++){
			  $("input:checkbox[value="+valueArr[i]+"]").attr('checked','true');
			}
		}
		
		
		
		//编辑
		$("#editSignedCancelOrder").off().click(function(){
    		var entity = AppUtil.Params("#signedBackDetail_form .ng-binding",true);
    		var config={
	    			sel:".ng-binding",
	    			msgDiv:"#reg_tip_box",
	    			id:"#signedBackDetail_form"
	    			};
    		var flag  = ValidF.valid(config);
    		if(flag){
	    		$http.post('signedCancel/eidtSignedCancelOrder', entity).success(function(response) {
	    			LoadList();
	    			$("#edit_dialog").modal("hide");
	    			alertMsg("提示", "修改成功");
	    		}).error(function(msg) {
	    			alertMsg("提示", msg.message);
	    		});
    		}
    	});
		
		//详情里面查看审核流水
    	$("#showDetailCheckList").off().click(function(){
    		
    		var cancelNo=$("#signedBackDetail_form input[name='cancelNo']").val();
    		var signedCancelStatus=$("#signedBackDetail_form input[name='canceloStatus']").val();
    		if(signedCancelStatus==CON_ROCANCEL_STATUS.WTJ){
    			getCheckList(cancelNo);
    		}else{
    			getCheckList(cancelNo);
    		}
    		
    	});
    	
    	//详情页里的打印
		$("#printSignedCancelOrder").off().click(function(){
			var cancelNo=$("#signedBackDetail_form input[name='cancelNo']").val();
			$scope.PrintData(cancelNo,'/print/signedcancel.html');
		});
		
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('ContractBackSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('signedCancel/listOrder', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});

