app.register.controller('ContractBackListAuditCtrl', function($scope, $rootScope,
		ContractBackListAudittSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ContractBackListAudittSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.contractBacklist = response.data;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	};
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	$http.get("signedCancel/dicts").success(function(data){
		$scope.cancelStatus=data.data.cancelStatus;
		$scope.PaySituation=data.data.PaySituation;
	});
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//获取审核流水
	var getCheckList=function(cancelNo){
		$http.get('signedCancel/getSignedCancelListCheck?cancelNo='+cancelNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	//审核流水
	$scope.showchecklist = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.cancelStatus==CON_ROCANCEL_STATUS.WTJ){
			return;
		}
		var data = $scope.data;
		getCheckList(data.cancelNo);
	};
	
	
	//双击跳转明细页面
	$scope.showDetail = function(entity) {
		
		
		$scope.detailEntity=entity;
		//显示并加载数据
		$("#edit_dialog").modal("show");
		for(key in entity){
			if(key&&key.indexOf('$')==-1&&key!='basicDocument'){
				$("#signedBackDetail_form input[name="+key+"]").val(entity[key]);
				$("#signedBackDetail_form textarea[name="+key+"]").val(entity[key]);
				$("#signedBackDetail_form select[name="+key+"]").val(entity[key]);
			}
		};
		//加载复选框
		if(entity["basicDocument"]){
			var valueArr=entity["basicDocument"].split(",");
			for (var i=0; i<valueArr.length; i++){
			  $("input:checkbox[value="+valueArr[i]+"]").attr('checked','true');
			}
		}
		

		//详情里面查看审核流水
    	$("#showDetailCheckList").off().click(function(){
    		
    		var cancelNo=$("#signedBackDetail_form input[name='cancelNo']").val();
    		var signedCancelStatus=$("#signedBackDetail_form input[name='canceloStatus']").val();
    		if(signedCancelStatus==CON_ROCANCEL_STATUS.WTJ){
    			getCheckList(cancelNo);
    		}else{
    			getCheckList(cancelNo);
    		}
    		
    	});
		
		 //审核操作
		$("#checkButton").off().click(function(){
			var cancelNo=$("#signedBackDetail_form input[name='cancelNo']").val();
			var taskId=$("#signedBackDetail_form input[name='taskId']").val();
			var signedNo=$("#signedBackDetail_form input[name='signedNo']").val();
			var isCfo=$("#signedBackDetail_form input[name='isCfo']").val();
			
			$("#operate_signedcancel").modal("show");
			if(isCfo){
				$("#operate_signedcancel div[id='cfoShow']").show();
			}else{
				$("#operate_signedcancel div[id='cfoShow']").hide();
			}
			$("#submitcheck_form")[0].reset();
			$("#saveSignedCancelCheck").off().click(function(){
				var checked=$("#submitcheck_form input[type='radio']:checked").val();
				var checkRemark=$("#submitcheck_form textarea[name='checkRemark']").val();
				var cfoRemarkDoc='';
				if(isCfo){
					cfoRemarkDoc=$("#submitcheck_form input[type='checkbox'][name='remarkDoc']:checked").map(function(index,elem) {
				            return $.parseJSON($(elem).val());
				        }).get().join(',');;
				}
				$http.get('signedCancel/signedCancelCheck?cancelNo='+cancelNo+"&checked="+checked+"&checkRemark="+checkRemark+"&taskId="+taskId+"&signedNo="+signedNo+"&cfoRemarkDoc="+cfoRemarkDoc).success(function(response) {
					
					$("#edit_dialog").modal("hide");
					$("#operate_signedcancel").modal("hide");
					alertMsg("提示", "审核成功");
					LoadList();
				}).error(function(msg) {
					alertMsg("提示", msg.message);
				});
				
				
			});
		});
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('ContractBackListAudittSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('signedCancel/getSignedCancelCheckList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

