app.register.controller('ContractAuditListCtrl', function($scope, $rootScope,
		ContractAuditListSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage :10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		ContractAuditListSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.contractAuditList = response.data;
			$scope.datas = response.data;
			delete $scope.selectIndex;
			delete $scope.data;
		});
	};
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//查询备注历史信息
	$scope.SearchRemarkData=function(){
		var signedNo=$scope.data.signedNo;
		$http.get("/signedOrder/listRemark?signedNo="+signedNo).success(function(data){
			$scope.remarks = data;
			if($scope.remarks.length==0){
				alertMsg("提示", "暂无信息");
				return false;
			}
			$("#show_remark_modal").modal("show");
		});
	}
	
	//获取审核流水
	var getCheckList=function(signedNo){
		$http.get('signedOrder/getSignedCheckList?signedNo='+signedNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "单据无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	//审核流水
	$scope.showchecklist = function() {
		if($scope.selectIndex==undefined){
			alertMsg("提示", "请选择一条记录");
			return;
		}
		var data = $scope.data;
		if(data.soStatus==CON_SOSTATUS.WTJ){
			return;
		}
		var data = $scope.data;
		getCheckList(data.signedNo);
	};
	
	
	$http.get("signedOrder/dicts").success(function(data){
		$scope.payMode=data.data.payMode;
		$scope.userSex=data.data.userSex;
		$scope.soStatus=data.data.soStatus;
		$scope.passStatus=data.data.passStatus;
		$scope.disList=data.data.disList;
		$scope.PaySituation=data.data.PaySituation;
		
	});
	
	
	 //双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#edit_dialog").modal("show");
		//默认选中第一个tab
		$("#edit_tabs").tabs({active:0});
		//清空表单
		$("#contractauditedit_form")[0].reset(); 
		$http.get('signedOrder/getDetailList?signedNo='+entity.signedNo).success(function(response) {
			$scope.SignedInvoice=response.data.SignedInvoice;
			$scope.SignedPaylogDk=response.data.SignedPaylogDk;
			$scope.SignedPaylogWk=response.data.SignedPaylogWk;
			$scope.dowPayOrder=response.data.dowPayOrder;
		});
		$http.get('publicCustomer/list?billNo='+entity.signedNo).success(function(response) {
			$scope.publicCustomerList=response;
			setTimeout(function(){hideByRole(roleNum);},500);
		})
		//angular。js赋值延迟，故这里用jquery赋值
		for(key in entity){
			if(key&&key.indexOf('$')==-1){
				$("#contractauditedit_form input[name="+key+"][isNumber!='true']").val(entity[key]);
				$("#contractauditedit_form select[name="+key+"]").val(entity[key]);
				$("#contractauditedit_form textarea[name="+key+"]").val(entity[key]);
			}
		};
		
		$.each($scope.disList,function(i,o){
			if(entity.discountProject==o.dispro_no){
				$("input[name='discountProjectName']").val(o.dispro_name);
				$("input[name='discountProject']").val(o.dispro_no);
			}
		});
		//角色权限控制
		var roleNum=$("#roleCode").val();
		$scope.c=entity;
		
		
		//初始化
		$("#contractauditedit_form input[group='once'],#contractauditedit_form select[group='once']").removeAttr("disabled");
		$(".row_1 button,.row_2 button").removeAttr("disabled");
		//一次性付款设置只读属性
		if(entity.payMode==PAY_MODE.YCX){
			setTimeout(function(){
				$("#contractauditedit_form input[group='once'],#contractauditedit_form select[group='once']").attr("disabled","disabled");
				$(".row_1 button,.row_2 button").attr("disabled","disabled");
			},200);
		}
		selectTab(roleNum);
		//只有完成了相关信息填写才可以提交审核
		$("#checkButton").off().click(function(){
			var signedNo=$("#contractauditedit_form input[name='signedNo']").val();
			var taskId=$("#contractauditedit_form input[name='taskId']").val();
			$("#operate_signed").modal("show");
			$("#submitcheck_form")[0].reset();
			
			
			
			//提交流程按钮
			$("#saveSignedCheck").off().click(function(){
				var checked=$("#submitcheck_form input[type='radio']:checked").val();
				var checkRemark=$("#submitcheck_form textarea[name='checkRemark']").val();
				var editEntity={};
				editEntity.signedNo=signedNo;
				editEntity.taskId=taskId;
				editEntity.checked=checked;
				editEntity.checkRemark=checkRemark;
				editEntity.customerIdcard=$scope.c.customerIdcard;
				
				//判断是否填写了相关信息
				var flag  = true;
				if(roleNum==ROLE_CODE.XSNQ){
					var netNumber=$scope.c.netNumber;
					if(!netNumber||netNumber==''){
						flag=false;
					}
				}else if(roleNum==ROLE_CODE.KJ){
					var realArea=$scope.c.realArea;
					if(!realArea||realArea==''){
						flag=false;
					}
				}
				
				//当flag为验证通过或审批不通过时，才能提交审核
				if(flag||checked!='YES'){
						$http.post('signedOrder/signedCheck',editEntity).success(function(response) {
							$("#edit_dialog").modal("hide");
							$("#operate_signed").modal("hide");
							alertMsg("提示", "保存成功");
							LoadList();
						}).error(function(msg) {
							alertMsg("提示", msg.message);
						});
				}else{
					alertMsg("提示", "请先填写相关信息并保存，再提交审核");
				}
			});
		});
		
		
		//详情里面查看审核流水
		$("#showDetailCheckList").off().click(function(){
			var signedNo=$("#contractauditedit_form input[name='signedNo']").val();
			var soStatus=$("#contractauditedit_form input[name='soStatus']").val();
			if(soStatus==CON_SOSTATUS.WTJ){
				getCheckList(signedNo);
			}else{
				getCheckList(signedNo);
			}
			
		});
		
		
		
		//保存按钮
		$("#saveSignedModel").off().click(function(){
			var signedNo=$("#contractauditedit_form input[name='signedNo']").val();
			var config={
	    			sel:".input_params[disabled!='disabled']",
	    			msgDiv:"#edit_reg_tip_box",
	    			id:"#contractauditedit_form"
	    			};
				//销售内勤点击保存时，是做更新操作
				if(roleNum==ROLE_CODE.XSNQ){
					var flag  = ValidF.valid(config);
					if(flag){
						editEntity=AppUtil.Params("#contractauditedit_form div[id='edit_tabs_2'] .input_params",true);
						editEntity.signedNo=signedNo;
						$http.post('signedOrder/editEntity',editEntity).success(function(response) {
							$("#edit_dialog").modal("hide");
							$("#operate_signed").modal("hide");
							alertMsg("提示", "保存成功");
							LoadList();
						}).error(function() {
							alertMsg("提示", "系统出错,请稍后重试.");
						});
					}
				}//当登录人员是会计时，是更新与新增共存
				else if(roleNum==ROLE_CODE.KJ){
					var flag  = ValidF.valid(config);
					if(flag){
						editEntity=AppUtil.Params("#contractauditedit_form div[id='edit_tabs_3'] .input_params",true);
						editEntity.signedNo=signedNo;
						    //开票日期信息采集
							var billingDateArr= new Array;
							$("#contractauditedit_form div[id='edit_tabs_3'] .input_params[name='billingDate']").each(function(index,item){
								billingDateArr[index]=$(item).val();
							});
							
							var invoiceNumberArr= new Array;
							$("#contractauditedit_form div[id='edit_tabs_3'] .input_params[name='invoiceNumber']").each(function(index,item){
								invoiceNumberArr[index]=$(item).val();
							});
							
							var invoiceAmountArr= new Array;
							$("#contractauditedit_form div[id='edit_tabs_3'] .input_params[name='invoiceAmount']").each(function(index,item){
								invoiceAmountArr[index]=$(item).val();
							});
							
							var jsonItemArr=new Array;
							$.each(billingDateArr,function(i,o){
								var json={};
								json.billingDate=billingDateArr[i];
								json.invoiceNumber=invoiceNumberArr[i];
								json.invoiceAmount=invoiceAmountArr[i];
								json.sourceNo=signedNo;
								jsonItemArr.push(json);
							});
							editEntity.listSignInvoice=jsonItemArr;
							
						//贷款信息采集
							var payDateArr_d= new Array;
							$("#contractauditedit_form div[id='edit_tabs_3'] .input_params[name='payDate_d']").each(function(index,item){
								payDateArr_d[index]=$(item).val();
							});
							
							var payAmountArr_d= new Array;
							$("#contractauditedit_form div[id='edit_tabs_3'] .input_params[name='payAmount_d']").each(function(index,item){
								payAmountArr_d[index]=$(item).val();
							});
							
							
							var jsonItemArrDk=new Array;
							$.each(payDateArr_d,function(i,o){
								var json={};
								json.payDate=payDateArr_d[i];
								json.payAmount=payAmountArr_d[i];
								json.signedNo=signedNo;
								json.payType=PAY_TYPE.DK;
								jsonItemArrDk.push(json);
							});
							editEntity.SignedPaylogDk=jsonItemArrDk;
							
					    //尾款信息采集
							var payDateArr_w= new Array;
							$("#contractauditedit_form div[id='edit_tabs_3'] .input_params[name='payDate_w']").each(function(index,item){
								payDateArr_w[index]=$(item).val();
							});
							
							var payAmountArr_w= new Array;
							$("#contractauditedit_form div[id='edit_tabs_3'] .input_params[name='payAmount_w']").each(function(index,item){
								payAmountArr_w[index]=$(item).val();
							});
							
							
							var jsonItemArrWk=new Array;
							$.each(payDateArr_w,function(i,o){
								var json={};
								json.payDate=payDateArr_w[i];
								json.payAmount=payAmountArr_w[i];
								json.signedNo=signedNo;
								json.payType=PAY_TYPE.WK;
								jsonItemArrWk.push(json);
							});
							editEntity.SignedPaylogWk=jsonItemArrWk;
							
							
						$http.post('signedOrder/editEntity',editEntity).success(function(response) {
							$("#edit_dialog").modal("hide");
							$("#operate_signed").modal("hide");
							alertMsg("提示", "保存成功");
							LoadList();
						}).error(function() {
							alertMsg("提示", "系统出错,请稍后重试.");
						});
					}
					
				}
		});
		
		
		
	};
	
	
	/**
	 * @param roleNum
	 */
	hideByRole=function (roleNum){
		switch(roleNum){
		   //销售内勤
		    case ROLE_CODE.XSNQ:
		    	   $("#edit_tabs").tabs({active:1});
		           $("#contractauditedit_form div[id='edit_tabs_1'] .input_params").attr("disabled","disabled");
		           $("#contractauditedit_form div[id='edit_tabs_3'] .input_params").attr("disabled","disabled");
		           $(".row_1 button,.row_2 button,.row_3 button").attr("disabled","disabled");
		    	   break;
		   //会计
		    case ROLE_CODE.KJ:
		    	   $("#edit_tabs").tabs({active:2});
		    	   $("#contractauditedit_form div[id='edit_tabs_1'] .input_params").attr("disabled","disabled");
		    	   $("#contractauditedit_form div[id='edit_tabs_2'] .input_params").attr("disabled","disabled");
		    	   break;
		   default:
			       $("#edit_tabs").tabs({active:0});
			       $("#contractauditedit_form div[id='edit_tabs_1'] .input_params").attr("disabled","disabled");
    	           $("#contractauditedit_form div[id='edit_tabs_2'] .input_params").attr("disabled","disabled");
    	           $("#contractauditedit_form div[id='edit_tabs_3'] .input_params").attr("disabled","disabled");
    	           $(".row_1 button,.row_2 button,.row_3 button").attr("disabled","disabled");
    	           $("#saveSignedModel").remove();
		}
		
	};
	
	/**
	 * @param roleNum
	 */
	selectTab=function (roleNum){
		switch(roleNum){
		   //销售内勤
		    case ROLE_CODE.XSNQ:
		    	   $("#edit_tabs").tabs({active:1});
		    	   break;
		   //会计
		    case ROLE_CODE.KJ:
		    	   $("#edit_tabs").tabs({active:2});
		    	   break;
		   default:
			       $("#edit_tabs").tabs({active:0});
		}
		
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('ContractAuditListSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('signedOrder/getSignedOrderCheckList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
});

