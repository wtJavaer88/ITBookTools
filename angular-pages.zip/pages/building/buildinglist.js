app.register.controller('BuildingListCtrl', function($scope, $http, $rootScope,
		$route, BuildingListSer, AppUtil, $q,$routeParams) {
	
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10 
	};
	
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1;
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		BuildingListSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.roomInfo = response.data;
			setTimeout(check_table_tr,500);
		});
	};
	// 配置分页基本参数
	$scope.$watch('pagination.refresh',LoadList);
	$scope.$watch('selectArea',function(){
		$scope.loadBuildings($scope.selectArea);
	});
	$scope.$watch('selectBuilding',function(){
		$scope.loadRooms($scope.selectBuilding);
	});

	//加载下拉列表数据
	$http.get("building/dicts").success(function(data){
		$scope.areas=data.data.areas;
		$scope.buildings=data.data.buildings;
		$scope.rooms=data.data.rooms;
		$scope.roomStatus=data.data.roomStatus;
		$scope.orientation_types=data.data.orientation_types;
		$scope.roomModels=data.data.roomModels;
	});
	
	//选择项目，重新加载区域、楼栋、房间的下拉框
	$scope.loadEreas = function(projectNo){
		var postData = {};
		postData.projectNo = projectNo;
		$http.get("building/loadEreas?projectNo="+projectNo).success(function(data){
			$scope.areas=data.data.areas;
			$scope.buildings=data.data.buildings;
			$scope.rooms=data.data.rooms;
			$scope.roomModels=data.data.roomModels;
		});
	};
	
	//选择区域，重新加载楼栋、房间的下拉框
	$scope.loadBuildings = function(areaNo){
		var postData = {};
		postData.areaNo = areaNo;
		$http.post("building/loadBuildings",postData).success(function(data){
			$scope.buildings=data.data.buildings;
			$scope.rooms=data.data.rooms;
		});
	};
	
	//选择楼栋 重新加载房间下拉框
	$scope.loadRooms = function(buildingNo){
		var postData = {};
		postData.buildingNo = buildingNo;
		$http.post("building/loadRooms",postData).success(function(data){
			$scope.rooms=data.data.rooms;
		});
	};
	
	$scope.showDetail = function(room) {
		$("#myModal_detail").modal("show");
		$("#myModal_detail section").show();
		$scope.basicInfo=room;
		// 加载数据方法
		AppUtil.loading();
		$http.get('building/getRoomDetailInfo?roomNo='+room.room_no).success(function(response) {
			AppUtil.remove_loading();
			$scope.roomPayDetail=response.data;
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
		
		if(room.room_status == CON_ROOM_STATUS.WFP || room.room_status == CON_ROOM_STATUS.WXS){
			$("#payInfo").hide();
			$("#signedInfo").hide();
			$("#otherInfo").hide();
		}
		
		if(room.room_status == CON_ROOM_STATUS.YYD){
			$("#signedInfo").hide();
		}
	};
});

app.register.service('BuildingListSer', function($http,AppUtil) {
	this.list = function(postData) {
		AppUtil.loading();
		//设置查询开始下标
		postData.start= (postData.page-1<0?0:postData.page-1)*postData.size;
		return $http.post('building/list', postData).error(function() {
			AppUtil.remove_loading();
		});;
	};

});
