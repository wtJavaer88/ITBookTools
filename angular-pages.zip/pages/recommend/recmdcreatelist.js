app.register.controller('RecommendCreateCtrl',function($scope, $rootScope, RecommendCreateSer, AppUtil,$http, $q) {
	$scope.pagination = {
		currentPage : 1,
		itemsPerPage : 10
	};
	$scope.SearchData = function() {
		$scope.postData = {};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
			$scope.postData.page = $scope.pagination.currentPage;
			$scope.postData.size = $scope.pagination.itemsPerPage;
			// 加载数据
			RecommendCreateSer.list($scope.postData).success(
				function(response) {
					AppUtil.remove_loading();
					$scope.pagination.totalItems = response.total;
					$scope.datas = response.data;
					delete $scope.selectIndex;
					delete $scope.data;
				}
			);
	}
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	//表格单击
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//字典数据查询
	$http.get("recommend/dicts").success(function(data) {
		$scope.recmdStatus = data.data.recmdStatus;
	});

	// 双击跳转明细页面
	$scope.showDetail = function(entity) {
		if (entity.status == CON_RECMD_STATUS.WTJ || entity.status == CON_RECMD_STATUS.WTG) {
			if(($rootScope.user.loginRole == ROLE_CODE.XSGW) || ($rootScope.user.loginRole == ROLE_CODE.XSJL)){
				$("#detail_modal textarea[name='remark']").prop("disabled", false);
			}else{
				$("#detail_modal textarea[name='remark']").prop("disabled", true);
			}
		}else{
			$("#detail_modal textarea[name='remark']").prop("disabled", true);
		}
		$("#detail_modal form")[0].reset();
		// 显示并加载数据
		$("#detail_modal").modal("show");
		$scope.detail = entity;

		//加载推荐人信息
		$("#editForm input[name='recRoomNo']").off().change(function(){
			var recNo = $("#editForm input[name='recRoomNo']").val();
			$http.get('common/loadCusInfo?roomNo='+recNo+"&type="+CON_BILL_TYPE.QYD).success(function(response) {
				var customer = response.data;
				if(customer){
					for (key in customer) {
						if (key && key.indexOf('$') == -1) {
							$("#editForm input[name=" + key + "]").val(customer[key]);
						}
					}	
				}else{
					$("#editForm input[name='recName']").val("");
					$("#editForm input[name='recPhone']").val("");
					$("#editForm input[name='recIdcard']").val("");
					$("#editForm input[name='recOffbuyDate']").val("");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
		
		//加载认购人信息
		$("#editForm input[name='offbuyRoomNo']").off().change(function(){
			var recNo = $("#editForm input[name='offbuyRoomNo']").val();
			$http.get('common/loadCusInfo?roomNo='+recNo+"&type="+CON_BILL_TYPE.YDD).success(function(response) {
				var customer = response.data;
				if(customer){
					for (key in customer) {
						if (key && key.indexOf('$') == -1) {
							$("#editForm input[name=" + key + "]").val(customer[key]);
						}
					}
				}else{
					$("#editForm input[name='offbuyName']").val("");
					$("#editForm input[name='offbuyPhone']").val("");
					$("#editForm input[name='offbuyIdcard']").val("");
					$("#editForm input[name='offbuyDate']").val("");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
		
		// 详情页面编辑按钮事件
		$("#editRecommend").off().click(
			function() {
				var flag = ValidF.valid({
					id : "#editForm",
					sel : ".ng-binding",
					msgDiv : "#edit_reg_tip_box"
				})
				if (flag) {
					var entity = AppUtil.Params("#detail_modal .ng-binding");
					$http.post('recommend/editRecommend',entity).success(function(response) {
						if(response.code == 1){
							alertMsg("提示","编辑成功",function() {
								LoadList();
								$("#detail_modal").modal("hide");
							});
						}else{
							alertMsg("提示", response.message);
						}
					}).error(function() {
						alertMsg("提示","系统出错,请稍后重试.");
					});
				}
			});

		// 详情页面打印按钮事件
		$("#printRecommend").off().click(function() {
			$scope.PrintData(entity['rcNo'],'/print/recommend.html');
			$("#detail_modal").modal("hide");
		});

		// 详情页面审核流水按钮事件
		$("#checkRecomend").off().click(function() {
			getCheckList(entity['rcNo']);
		});

		// 控制详情页面按钮
		$(".row button").show();

		if (entity.status == CON_RECMD_STATUS.WTG) {
			$("#printRecommend").hide();
		}
		if(entity.status==CON_RECMD_STATUS.SHZ || entity.status==CON_RECMD_STATUS.YTG){
			$("#editRecommend").hide();
		}
		if (entity.status == CON_RECMD_STATUS.YSC
				|| entity.status == CON_RECMD_STATUS.YZF) {
			$("#editRecommend").hide();
			$("#printRecommend").hide();
		}
		$scope.entity_status = entity.status;
		
		$scope.openSelectRoom1 = function(clazz, filterType) {
			if (entity.status == CON_RECMD_STATUS.SHZ
					|| entity.status == CON_RECMD_STATUS.YTG
					|| entity.status == CON_RECMD_STATUS.YSC
					|| entity.status == CON_RECMD_STATUS.YZF) {
				return;
			}
			if(filterType==undefined)
				filterType = "";
			$rootScope.filterType =filterType;
			$scope.retClazz = clazz;
			AppUtil.openModal('selectRoom', 'selectRoom', $scope);
		};
	};

	// 新增
	$scope.showAddWin = function() {
		$("#add_dialog").modal("show");
		// 清空表单
		$("#createForm")[0].reset();
		
		//加载推荐人信息
		$("#createForm input[name='recRoomNo']").off().change(function(){
			var recNo = $("#createForm input[name='recRoomNo']").val();
			$http.get('common/loadCusInfo?roomNo='+recNo+"&type="+CON_BILL_TYPE.QYD).success(function(response) {
				var customer = response.data;
				if(customer){
					for (key in customer) {
						if (key && key.indexOf('$') == -1) {
							$("#createForm input[name=" + key + "]").val(customer[key]);
						}
					}	
				}else{
					$("#createForm input[name='recName']").val("");
					$("#createForm input[name='recPhone']").val("");
					$("#createForm input[name='recIdcard']").val("");
					$("#createForm input[name='recOffbuyDate']").val("");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
		
		//加载认购人信息
		$("#createForm input[name='offbuyRoomNo']").off().change(function(){
			var recNo = $("#createForm input[name='offbuyRoomNo']").val();
			$http.get('common/loadCusInfo?roomNo='+recNo+"&type="+CON_BILL_TYPE.YDD).success(function(response) {
				var customer = response.data;
				if(customer){
					for (key in customer) {
						if (key && key.indexOf('$') == -1) {
							$("#createForm input[name=" + key + "]").val(customer[key]);
						}
					}
				}else{
					$("#createForm input[name='offbuyName']").val("");
					$("#createForm input[name='offbuyPhone']").val("");
					$("#createForm input[name='offbuyIdcard']").val("");
					$("#createForm input[name='offbuyDate']").val("");
				}
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		});
		
		
		// 获取初始化数据
		$http.get('recommend/createInit').success(function(response) {
			$("#add_dialog input[name='rcNo']").val(response.data.rcNo.replace(/\"/g,""));
			$("#add_dialog input[name='created']").val(response.data.created.replace(/\"/g,""));
			$("#add_dialog input[name='createBy']").val(response.data.createBy.replace(/\"/g,""));
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});

		// 新增保存按钮事件
		$("#saveRecommend").off().click(function() {
				var flag = ValidF.valid({
					id : "#createForm",
					sel : ".ng-binding",
					msgDiv : "#reg_tip_box"
				})
				if (flag) {
					var entity = AppUtil.Params("#add_dialog .ng-binding", true);
					$http.post('recommend/createRecommend',entity).success(function(response) {
						if(response.code == 1){
							alertMsg("提示","新增成功",function() {
								LoadList();
								$("#add_dialog").modal("hide");
							});
						}else{
							alertMsg("提示", response.message);
						}}).error(function() {
							alertMsg("提示","系统出错,请稍后重试.");
						});
					}
			});

	};

	// 提交审核
	$scope.submitCheck = function() {
		if($scope.data){
			showconfirm("单据确定提交审核？", function() {
				$http.get('recommend/submitCheck?rcNo='+ $scope.data.rcNo).success(
						function(response) {
							if(response.code == 1){
								alertMsg("提示", "已成功提交审核");
								LoadList();
							}else{
								alertMsg("提示", response.message);
							}
						}).error(function(data) {
							alertMsg("提示", data.message);
						});
			}, function() {
				$("#showConfirm").modal("hide");
				return false;
			});
		}
	};

	// 作废
	$scope.toCancel = function() {
		if($scope.data){
			showconfirm("单据确定作废？", function() {
				var entity = {
					rcNo : $scope.data.rcNo
				};
				$http.post('recommend/cancelRecommend',entity).success(function(response) {
							if(response.code == 1){
								alertMsg("提示", "已成功作废");
								LoadList();
							}else{
								alertMsg("提示", response.message);
							}
				}).error(function() {
					alertMsg("提示", "系统出错,请稍后重试.");
				});
			}, function() {
				$("#showConfirm").modal("hide");
				return false;
			});
		}
	};

	// 删除
	$scope.toDelete = function() {
		if($scope.data){
			showconfirm("单据确定删除？", function() {
				var entity = {
					rcNo : $scope.data.rcNo
				};
				$http.post('recommend/deleteRecommend',entity).success(function(response) {
							if(response.code == 1){
								alertMsg("提示", "已成功删除");
								LoadList();
							}else{
								alertMsg("提示", response.message);
							}
				}).error(function() {
					alertMsg("提示", "系统出错,请稍后重试.");
				});
			}, function() {
				$("#showConfirm").modal("hide");
				return false;
			});
		}
	};

	// 列表页面审核流水按钮
	$scope.showCheck = function() {
		if($scope.data)
			getCheckList($scope.data.rcNo);
	};

	// 打印
	$scope.print = function() {
		if($scope.data)
				$scope.PrintData($scope.data.rcNo, '/print/recommend.html');
	}

	// 审核流水
	var getCheckList = function(rcNo) {
		$http.get('recommend/getCheckList?rcNo='+rcNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "该单据未提交，无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};

});

app.register.service('RecommendCreateSer', function($http, AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('recommend/listCreate', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};

})
