app.register.controller('RecommendCtrl', function($scope, $rootScope,
		RecommendSer, AppUtil, $http, $q) {
	//获取本地存储中的页码页数
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		RecommendSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
		});
	}
	
	//表格单击
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
		$scope.data = $scope.datas[$scope.selectIndex];
	}
	
	//加载下拉框数据
	$http.get("recommend/dicts").success(function(data){
		$scope.recmdStatus=data.data.recmdStatus;
	});
	
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	//双击跳转明细页面
	$scope.showDetail = function(entity) {
		$("#detail_modal form")[0].reset();
		$("#detail_modal").modal("show");
		$scope.detail = entity;
		//详情页面审核流水按钮事件
		$("#checkRecomend").off().click(function(){
			getCheckList($scope.detail.rcNo);
		});
    };
    
    //列表页面审核流水按钮
	$scope.showCheck = function(){
		if($scope.data)
			getCheckList($scope.data.rcNo);
	};
	
	//审核流水
	var getCheckList=function(rcNo){
		$http.get('recommend/getCheckList?rcNo='+rcNo).success(function(response) {
			if(response.data.length>0){
				$scope.comments=response.data;
				$("#show_check_modal").modal("show");
			}else{
				alertMsg("提示", "该单据未提交，无审核流水.");
			}
		}).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
		});
	};
	
	// 导出
	$scope.ExportData = function() {
		AppUtil.ExportData($scope.postData);
	};
});

app.register.service('RecommendSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('recommend/list', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

