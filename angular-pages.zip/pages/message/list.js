app.register.controller('MessageCtrl', function($scope, $rootScope,
		MessageSer, AppUtil, $http, $q,$location) {
	
	var LoadList = function() {
		MessageSer.list({}).success(function(response) {
			AppUtil.remove_loading();
			$scope.warnList = response.data.warnList;
			$scope.waitList = response.data.waitList;
			$scope.completeList = response.data.completeList;
		});
	}
	LoadList();
	
	var LoadWaitList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
			MessageSer.waitlist($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.waitList = response.data.waitList;
		});
	}
	
	var LoadWarnList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
			MessageSer.warnlist($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.warnList = response.data.warnList;
		
		});
	}
	
	var LoadCompleteList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
			MessageSer.completelist($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.completeList = response.data.completeList;
		
		});
	}
	
    //标记为已读
    $scope.markRead = function(type){
		var check_value=$("input:checkbox[ng-checked='"+type+"']:checked").map(function(index,elem) {
	            return $.parseJSON($(elem).val()).taskId;
	    }).get().join(',');
		
		if(!check_value){
			alertMsg("提示", "请选择一条记录");
		}else{
			showconfirm("是否确认将选中提醒标记为已读?",function(){
				AppUtil.Post("/message/markRead",{"taskIds":check_value},function(data){
					LoadList();
				});
			});
		}
    };
    
    //显示全部 待办
    $scope.showWaitAll = function(){
    	$scope.postData={"noLimit":true};
		LoadWaitList();
    }
    
    //显示全部 预警
    $scope.showWarnAll = function(){
    	$scope.postData={"noLimit":true};
		LoadWarnList();
    }
    
    //显示全部 已办
    $scope.showWCompleteAll = function(){
    	$scope.postData={"noLimit":true};
		LoadCompleteList();
    }
    
    //双击跳转
	$scope.showDetail = function(entity) {
		window.location.href = entity.linkUrl;
    };
    
    $scope.openUrl=function(url){
    	$location.path(url);
    }
    
    $scope.checked = function(event){
    	if(!$(event).attr("type")){
    		var input = $(event).parent().find("input[type='checkbox']:not(:disabled)");
        	var flag = input.attr("checked");
        	input.attr("checked",!flag);	
    	}
    	
    }
});

app.register.service('MessageSer', function($http,AppUtil) {
	//待办
	this.waitlist = function(postData) {
		AppUtil.loading();
		return $http.post('message/waitList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	//预警
	this.warnlist = function(postData) {
		AppUtil.loading();
		return $http.post('message/warnList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	//已办
	this.completelist = function(postData) {
		AppUtil.loading();
		return $http.post('message/completeList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	this.list = function(postData) {
		AppUtil.loading();
		return $http.post('message/list', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

