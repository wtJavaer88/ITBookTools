app.register.controller('DiscountCtrl', function($scope, $http, $rootScope,
		$route, AppUtil, $q, $routeParams) {

	$scope.SearchData = function() {
		$scope.postData = AppUtil.Params(".form_params");
		// 表单查询参数
		LoadList();
	};

	// 加载数据方法
	var LoadList = function() {
		$scope.checked = false;
		if ($scope.postData == undefined)
			$scope.postData = {};
		// 加载数据
		AppUtil.Post("/discount/list", $scope.postData, function(response) {
			$scope.dispros = response.data;
			$("#add").hide();
			$scope.model = null;
			$("#detail").show();
			$scope.mode = 'view';
			$scope.checked = false;
		});
	}
	LoadList();

	$scope.selectProject = function(model, target, index) {
		$scope.checked = true;
		$scope.model = model;
		$scope.mode = "view";
		$scope.selectedIdex = index;
		$scope.detailIdex = undefined;
		$("#detail").show();
		$("#add").hide();
		$scope.viewMode = true;
		if (!model.details) {
			$http.get("/discount/details/" + model.dispro_no).success(
					function(response) {
						if (response.code == 1)
							model.details = response.data;
					});
		}
	};

	$scope.toAddModel = function(model) {

		$("#addModal").modal("show");
		var dispro_no = $("#dispro_no");
		if (dispro_no.val() == '') {
			$http.get('/discount/nextNo').success(function(data) {
				if (data.code == 1)
					dispro_no.val(data.data)
				else {
					errorModal();
				}
			}).error(function() {
				errorModal();
			});
		}
	};
	$scope.saveModel = function() {
		var flag = ValidF.valid({
			id : "#modelForm"
		})
		if (!flag)
			return;
		var postData = AppUtil.Params("#modelForm .input_params");
		AppUtil.Post("/discount/create", postData, function(response) {
			$("#addModal").modal("hide");
			$("#modelForm")[0].reset();
			$scope.dispros.splice(0, 0, response.data);
			delete $scope.model;
			delete $scope.selectedIdex;
		});
	};
	var errorModal = function() {
		alertMsg("提示", "系统出错,请稍后重试.");
		$("#addModel").modal("hide");
	};

	$scope.toEditModel = function(model) {
		$("#add").show();
		$("#detail").hide();
		$scope.mode = 'edit';
		$scope.dispro_name = $scope.model.dispro_name;
		initDisproRole();
	};

	$scope.updateModel = function() {
		var flag = ValidF.valid({
			id : "#edit_form",
			msgDiv : "#edit_tip_box"
		});
		if (!flag)
			return;

		var postData = AppUtil.Params("#edit_form .input_params", true);
		
		
		// 添加顺序保存
		if ($scope.model.details) {
			var details = $scope.model.details;
			var arr = [];
			for (var i = 0, j = details.length; i < j; i++) {
				arr.push(details[i].detail_no);
			}
			postData.orders = arr;
		}
		postData.dispro_role=initDisproRole();
		AppUtil.Post("/discount/update/" + $scope.model.dispro_no, postData,
				function() {
					ValidF.alert("保存成功.");
					$scope.model.dispro_name = $scope.dispro_name;
				});
	};

	$scope.deleteModel = function() {
		// 获得数组索引
		showconfirm("是否确认删除?", function() {
			$http.get("/discount/delete/" + $scope.model.dispro_no).success(
					function(response) {
						if (response.code == 1) {
							$scope.dispros.splice($scope.selectedIdex, 1);
							$scope.mode = 'view';
							$scope.checked = false;
							delete $scope.model;
							delete $scope.selectedIdex;
						}
					});
		});
	};

	// 明细处理逻辑

	$scope.toAddDetail = function(model) {
		$("#addDetailModal").modal("show");
		var detail_no = $("#detail_no");
		if (detail_no.val() == '') {
			$http.get('/discount/nextDetailNo').success(function(data) {
				if (data.code == 1)
					detail_no.val(data.data)
				else {
					errorModal();
				}
			}).error(function() {
				errorModal();
			});
		}
	};

	// 折扣方案
	var CON_DIS_CALCTYPE = {
		"1001" : "打折",
		"1002" : "总价优惠",
		"1003" : "减点优惠",
		"1004" : "单价优惠"
	};
	$scope.saveDetail = function() {
		var calc_type = $("#calc_type").val();
		if (calc_type == '1001' || calc_type == '1003') {
			$("#discount_amount").removeAttr("require");
			$("#discount_rate").attr("require", "请输入折扣率.");
		}
		if (calc_type == '1002' || calc_type == '1004') {
			$("#discount_amount").attr("require", "请输入折扣金额.");
			$("#discount_rate").removeAttr("require");
		}

		var flag = ValidF.valid({
			id : "#detailForm",
			msgDiv : "#detail_msg"
		});
		if (!flag)
			return;
		var postData = AppUtil.Params("#detailForm .input_params");
		postData.dispro_no = $scope.model.dispro_no;
		AppUtil.Post("/discount/createDetail", postData, function() {
			$("#addDetailModal").modal("hide");
			$("#detailForm")[0].reset();
			postData.calc_type_name = CON_DIS_CALCTYPE[postData.calc_type];
			$scope.model.details.push( postData);
			initDisproRole();
		});
	};
	var initDisproRole = function() {

		var model = $scope.model;
		var details = $scope.model.details;
		var role = "";
		for (var i = 0, j = details.length; i < j; i++) {
			var detail = details[i];
			role += (i + 1)+"." + detail.calc_type_name + "("
					+ (detail.discount_rate == null ? '' : detail.discount_rate + '%')
					+ (detail.discount_amount == null ? '' : detail.discount_amount)
					+ ");"
		}
		
		$scope.model.dispro_role = role;
		$scope.model.dispro_desc = role;
		return role;
	};

	$scope.selectDetail = function(detail, target, index) {
		$scope.detailIdex = index;
		$scope.detail = detail;

	};

	$scope.deleteDetail = function() {
		showconfirm("是否确认删除?", function() {
			$http.get("/discount/deleteDetail/" + $scope.detail.detail_no)
					.success(function(response) {
						if (response.code == 1) {
							$scope.model.details.splice($scope.detailIdex, 1);
							$scope.detailIdex = undefined;
							initDisproRole();
						}
					});
		});

	};
	var swapItems = function(arr, index1, index2) {
		arr[index1] = arr.splice(index2, 1, arr[index1])[0];
		return arr;
	};
	$scope.changePos = function(top) {
		var cIndex;
		var details = $scope.model.details;
		var dLength = details.length;
		if (top)
			cIndex = $scope.detailIdex - 1;
		else
			cIndex = $scope.detailIdex + 1;
		if (cIndex < 0 || cIndex >= dLength)
			return;

		swapItems($scope.model.details, $scope.detailIdex, cIndex);
		$scope.detailIdex = cIndex;

	}

});
