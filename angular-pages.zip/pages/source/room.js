


app.register.controller('ProRoomCtrl', function($scope, $http, $rootScope,
		$route, PorRoomSer, AppUtil, $q,$routeParams,Upload,$compile) {
	
	//设置tab当前页
	$scope.pageIndex=1;
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	//查询数据
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		var params = AppUtil.Params(".form_params");
		$.extend($scope.postData,params);
		// 表单查询参数
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		$scope.postData.start= ($scope.postData.page-1<0?0:$scope.postData.page-1)*$scope.postData.size;
		// 加载数据
		AppUtil.Post("/room/list",$scope.postData,function(response){
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.rooms = response.data;
		})
	}
	
	//加载基础属性信息
	$http.get('/common/attrs').success(function(response) {
		$scope.attrs = response;
	});
	
	//加载楼栋信息
	$http.get("/room/builds").success(function(response){
		if(response.code==1)
			$scope.builds = response.data;
	});
	
	
	// 配置分页基本参数
	$scope.$watch('pagination.refresh',LoadList);
	
	//分页切换
	$scope.changePage = function(page){
		$scope.pageIndex=page;
		var obj = $("#page_"+page);
		$(".nav-tabs").find("li").removeClass("active");
		obj.addClass("active");
		switch(page){
		case 1:
		case 2:
			$("input[name='basic_area']").removeClass().addClass("unedit_input").attr("disabled",true);
			$("input[name='basic_price']").removeClass().addClass("unedit_input").attr("disabled",true);
			$("#pageDiv_1").show();
			$("#pageDiv_3").hide();
			break;
		case 3:
			$("#pageDiv_1").hide();
			$("#pageDiv_3").show();
			$("#roomSet2").hide();
			$("#roomSet1").show();
			break;
		case 4:
			$("#pageDiv_1").hide();
			$("#pageDiv_3").show();
			$("#roomSet2").show();
			$("#roomSet1").hide();
			break;
				
		}
	};
	
	
	//查询房间分组信息
	$scope.SearchGroups = function(){
		$scope.units = undefined;
		$scope.doors = undefined;
		$scope.datas =undefined;
		$scope.floors = undefined;
		var building_no   = $("#building_no").val();
		
		if(building_no=="")return;
		AppUtil.Post("/room/groups",{building_no:building_no},function(response){
			var units = response.data.units;
			var doors = [];
			for(var i=0,j=units.length;i<j;i++){
				doors.push.apply(doors,units[i].doors);
			}
			$scope.units = units;
			$scope.doors = doors;
			$scope.datas = response.data.rooms;
			$scope.floors = response.data.floors;
		});
	}
	//监听页面渲染完成
	$scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
		for(var i=0,j=$scope.datas.length;i<j;i++){
			room= $scope.datas[i];
			InputRoom(room);
			
		}
	});
	//拼接room信息
	var InputRoom = function(room){
		var td = $("#room_"+room.room_floor+room.unit_no+room.door_no);
		td.html(room.room_number);
		td.attr("status",room.room_status);
		td.attr("room_no",room.room_no);
		if(room.room_status=="1000"){
			td.css('background-color','#FFF');
		}else if(room.room_status=="1001"){
			td.css('background-color','green');
		}else{
			td.css('background-color','#999');
		}
		
		var td1 = $("#room1_"+room.room_floor+room.unit_no+room.door_no);
		td1.html(room.room_number+"-"+room.landscape_type_name+" "+room.orientation_type_name);
		td1.attr("status",room.room_status);
		td1.attr("room_no",room.room_no);
		td1.attr("room_number",room.room_number);
		
	};
	
	//page1 放盘
	$scope.putRoom=function(){
		var select  = "input[name='room_no']:checked";
		var rooms = [];
		$(select).each(function(){
			var _this = $(this);
			var room_status = _this.attr("status");
			if(room_status=='1000')
				rooms.push(_this.val());
			else
				_this.attr("checked",false);
		});
		if(rooms.length==0){
			alertMsg("提示","请至少选择一个未放盘的房间.")
			return;
		}
		showconfirm("是否确认放盘?",function(){
				AppUtil.Post("/room/putRooms/",rooms,function(response) {
					if(response.code==1){
						LoadList();
						$scope.check_all=false;
					}
				});
		});
		
	};
	
	//page1 收盘
	$scope.getRoom=function(){
		var rooms = [];
		var select  = "input[name='room_no']:checked";
		$(select).each(function(){
			var _this = $(this);
			var room_status = _this.attr("status");
			if(room_status=='1001')
				rooms.push(_this.val());
			else
				_this.attr("checked",false);
		});
		if(rooms.length==0){
			alertMsg("提示","请至少选择一个已放盘的房间.")
			return;
		}
		showconfirm("是否确认收回房间?",function(){
				AppUtil.Post("/room/getRooms/",rooms,function(response) {
					if(response.code==1){
						LoadList();
						$scope.check_all=false;
					}
				});
		});
	};
	
	var findRooms = function(clazz){
		var rooms = [];
		$(clazz).each(function(){
			var _this = $(this);
			var room_status = _this.attr("status");
			rooms.push(_this.attr("room_no"));
		});
		return rooms;
	}
	//page3 放盘
	$scope.putRooms=function(type,s){
		var select=".room_td[status='1000']";
		if(type=='col'){
			select+="[unit='"+s.unit_no+"'][door='"+s.door_no+"']";
		}else if(type=='row'){
			select+="[floor='"+s+"']";
		}
		var rooms = findRooms(select);
		if(rooms.length==0){
			return;
		}
		showconfirm("是否确认放盘?",function(){
				AppUtil.Post("/room/putRooms/",rooms,function(response) {
					if(response.code==1){
						$(select).each(function(){
							var _this = $(this);
							_this.attr("status",'1001')
							_this.css("background-color",'green');
						});
					}
				});
		});
	};
	
	//page3 收盘
	$scope.getRooms=function(type,s){
		
		var select=".room_td[status='1001']";
		if(type=='col'){
			select+="[unit='"+s.unit_no+"'][door='"+s.door_no+"']";
		}else if(type=='row'){
			select+="[floor='"+s+"']";
		}
		var rooms = [];
		var rooms = findRooms(select);
		if(rooms.length==0){
			return;
		}
		showconfirm("是否确认收回房间?",function(){
				AppUtil.Post("/room/getRooms/",rooms,function(response) {
					if(response.code==1){
						$(select).each(function(){
							var _this = $(this);
							_this.attr("status",'1000')
							_this.css("background-color",'#fff');
						});
					}
				});
		});
	};
	
	$scope.showAttrEdit =function(type,data){
		$scope.editType=type;
		$scope.editData = data;
		$("#attrModal").modal("show");
	};
	$scope.saveRoomAttr=function(){
		var flag  = ValidF.valid({sel:".attr_params",msgDiv:"#attr_msg"});
		if(flag==false)return;
		var type = $scope.editType;
		var data = $scope.editData;
		var select = ".room_td1[status='1000']";
		if(type=='col'){
			select+="[unit='"+data.unit_no+"'][door='"+data.door_no+"']";
		}else if(type=='row'){
			select+="[floor='"+data+"']";
		}
		var rooms =  findRooms(select);
		if(rooms.length==0)
			return;
		var params = AppUtil.Params(".attr_params");
		showconfirm("是否确认更改房间属性?",function(){
			AppUtil.Post("/room/updateAttr/",{rooms:rooms,params:params},function(response) {
				if(response.code==1){
					alertMsg("提示","属性修改成功.");
					var orientation_type = $("select[name='orientation_type']").find("option:selected").text();
					var landscape_type = $("select[name='landscape_type']").find("option:selected").text();
					$(select).each(function(){
						var _this=$(this);
						var room_number = _this.attr("room_number");
						_this.html(room_number+"-"+landscape_type+" "+orientation_type);
					});
					$("#attrModal").modal("hide");
				}
			});
	});
		
	};
	
	
	//编辑面积,价格
	var reg = /^\d{1,6}(\.\d{1,2})?$/;
	$scope.toEditArea=function(){
		$("input[name='basic_area']").removeClass().addClass("edit_input").attr("disabled",false);
	};
	$scope.toEditPrice=function(){
		$("input[name='basic_price']").removeClass().addClass("edit_input").attr("disabled",false);
		$("input[name='decor_price']").removeClass().addClass("edit_input").attr("disabled",false);
	};
	$scope.updateArea=function(room,event){
		var value = event.target.value;
		if(value==room.basic_area)return;
		//验证价格
		value = value.replace(",","");
		if(!reg.test(value)){
			event.target.value =room.basic_area==undefined?"":parseFloat(room.basic_area).toFixed(2);
			return;
		}
		//更新value
		AppUtil.Post("/room/updateArea",{room_no:room.room_no,basic_area:value,real_price:room.real_price},function(response){
			room.basic_area  = value;
			if(response.data.total_price!=undefined)
				room.total_price = response.data.total_price;
		});
	};
	$scope.updatePrice=function(room,event){
		
		var value = event.target.value;
		if(value==room.basic_price)return;
		//验证价格
		value = value.replace(",","");
		if(value==''||!reg.test(value)){
			event.target.value =room.basic_price==undefined?"":parseFloat(room.basic_price).toFixed(2);
			return;
		}
		//更新value
		AppUtil.Post("/room/updatePrice",{room_no:room.room_no,basic_price:value,decor_price:room.decor_price,basic_area:room.basic_area},function(response){
			room.basic_price  = value;
			if(response.data.real_price!=undefined)
				room.real_price = response.data.real_price;
			if(response.data.total_price!=undefined)
				room.total_price = response.data.total_price;
		});
	};
	$scope.updateDecPrice=function(room,event){
		
		var value = event.target.value;
		if(value==room.decor_price)return;
		//验证价格
		value = value.replace(",","");
		if(value==''||!reg.test(value)){
			event.target.value =room.decor_price==undefined?"":parseFloat(room.decor_price).toFixed(2);
			return;
		}
		//更新value
		AppUtil.Post("/room/updatePrice",{room_no:room.room_no,basic_price:room.basic_price,decor_price:value,basic_area:room.basic_area},function(response){
			room.decor_price  = value;
			if(response.data.real_price!=undefined)
				room.real_price = response.data.real_price;
			if(response.data.total_price!=undefined)
				room.total_price = response.data.total_price;
		});
	};
	
	$scope.openBuild=function(){
		$("#buildModal").modal("show");
		if($scope.areas==undefined){
			AppUtil.Post("/create/areaList",{},function(response){
				$scope.areas = response.data;
			});	
		}
	}
	//选中区域
	$scope.checkArea = function(area_no,event){
		var checked = event.target.checked;
		$("input[area_no='"+area_no+"']").attr("checked",checked);
	};
	
	//生成导入模版
	$scope.createImportModel = function(){
		var builds = [];
		$("input[name='builds']:checked").each(function(){
			builds.push($(this).val());
		});
		if(builds.length==0){
			alertMsg("提示","请至少选择一个楼栋.")
			return;
		}
		$("#buildModal").modal("hide");
		$("#exportForm").submit();
	};
	
	//打开上传对话框
	$scope.openUpload=function(type){
		$scope.uploadType=type;
		$("#file").click();
	};
	//导入数据
	$scope.importData=function(){
		if($scope.file==undefined){
			return;
		}
		 AppUtil.loading('正在导入,请稍后.')
		 Upload.upload({
             //服务端接收
             url: '/room/import',
             //上传的同时带的参数
             data: {'type': $scope.uploadType},
             //上传的文件
             file: $scope.file
         })/*.progress(function (evt) {
             //进度条
        	 var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
        	 console.log('progess:' + progressPercentage + '%' + evt.config.file.name)
         })*/.success(function (data, status, headers, config) {
             //上传成功
        	 if(data.code==1){
        		 LoadList();
        		 alertMsg("提示",data.message);
        	 }else{
        		 alertMsg("提示",data.message);
        		 AppUtil.remove_loading();
        	 }
         }).error(function (data, status, headers, config) {
        	 AppUtil.remove_loading();
        	 //上传失败
        	 if(data.message)
        		 alertMsg("提示",data.message);
        	 else
        		 alertMsg("提示",'上传文件出错..');
         });
		
	};
	
	//保存房间信息
	$scope.saveRoom=function(){
		 
		var flag  = ValidF.valid({sel:".room_params",msgDiv:"#create_room_msg"});
		if(flag==false)return;
		var params  = AppUtil.Params(".room_params",true);
		AppUtil.Post("/room/saveRoom",params,function(){
			alertMsg("提示","保存房间成功!");
			//设置中文状态名
			$scope.room.product_type_name=$("select[name='product_type']").find("option:selected").text();
			$scope.room.room_type_name=$("select[name='room_type']").find("option:selected").text();
			$scope.room.orientation_type_name=$("select[name='orientation_type']").find("option:selected").text();
			$scope.room.landscape_type_name=$("select[name='landscape_type']").find("option:selected").text();
			$scope.room.decor_type_name=$("select[name='decor_type']").find("option:selected").text();
		});	
		
	};
	//打开房间信息查看对话框
	$scope.showRoom=function(room){
		$scope.room = room;
		if(room.room_status=='1000'){
			$("#saveRoomBtn").show();
		}else
			$("#saveRoomBtn").hide();
		$("#editModal").modal("show");
	};
	//打开户型查看对话框
	$scope.openModel = function() {
		AppUtil.openModal('modelModal','selectModel',$scope);
	};
	
	//监听户型选择
	$scope.$on('model', function (event, args) {
		 $.extend($scope.room,args);
	});
	//监听标准单价,标准面积,和装修单价,自动生成实际单价和总价
	$scope.$watch('room.basic_price+room.basic_area+room.decor_price', function() {
		 	var room= $scope.room;
		 	if(room==undefined)
		 		return;
		    var basic_price = room.basic_price==undefined?0:room.basic_price;
		    var basic_area = room.basic_area==undefined?0:room.basic_area;
		    var decor_price = room.decor_price==undefined?0:room.decor_price;
		    room.real_price = parseFloat(basic_price)+parseFloat(decor_price);
		    room.total_price =  room.real_price*basic_area;
		    if(room.total_price ==0)
		    	room.total_price  = undefined;
		    if(room.real_price ==0)
		    	room.real_price  = undefined;
		   
	});
	 $scope.checked = function(event){
	    	var input = $(event).parent().find("input[type='checkbox']");
	    	var flag = input.attr("checked");
	    	input.attr("checked",!flag);
	    }
});

app.register.service('PorRoomSer', function($http,AppUtil) {
	this.list = function(postData) {
		AppUtil.loading();
		//设置查询开始下标
		postData.start= (postData.page-1<0?0:postData.page-1)*postData.size;
		return $http.post('room/list', postData).error(function() {
			AppUtil.remove_loading();
		});
	};
});

