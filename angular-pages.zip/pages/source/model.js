app.register.controller('PorModelCtrl', function($scope, $http, $rootScope,
		$route, PorModelSer, AppUtil, $q,$routeParams) {
	//获取本地存储中的页码页数
	$scope.pagination = {
			currentPage :1,
			itemsPerPage : 10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		var params = AppUtil.Params(".form_params");
		$.extend($scope.postData,params);
		// 表单查询参数
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		PorModelSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.datas = response.data;
			$scope.selectIndex= undefined;
		});
	}
	
	var LoadAttr=( function() {
		$http.get('/common/attrs').success(function(response) {
			$scope.attrs = response;
		});
	});
	LoadAttr();
	// 配置分页基本参数
	$scope.$watch('pagination.refresh',LoadList);
	
	
	
	$scope.openModal=function(){
		if($("#option").val()!='add'){
			$("#modelForm")[0].reset();
			ValidF.hideMsg();
			$scope.basic_price=undefined;
		    $scope.basic_area=undefined;
		    $scope.decor_price=undefined;
		}
		$("#detail .modal-title").html("新增户型信息");
		$("#option").val("add");
		$("#detail").modal("show");
		var model_no = $("#model_no");
		if(model_no.val()==''){
			$http.get('/model/nextNo').success(function(data) {
				if(data.code==1)
					model_no.val(data.data)
				else{
					PorModelSer.errorModal();
				}
			}).error(function() {
				PorModelSer.errorModal();
			});
		}
	};
	
	$scope.toEdit=function(){
		var model = $scope.datas[$scope.selectIndex];
		$("#detail .modal-title").html("编辑户型信息");
		$("#option").val("save");
		AppUtil.InitParams(model);
		    $scope.basic_price=model.basic_price;
		    $scope.basic_area=model.basic_area;
		    $scope.decor_price=model.decor_price;
		$("#detail").modal("show");
	};
	$scope.deleteModel=function(){
		var model = $scope.datas[$scope.selectIndex];
		showconfirm("是否确认删除房间:"+model.model_name+"?",function(){
			$http.get("/model/delete/"+model.model_no).success(function(response) {
				if(response.code==1)
					LoadList();
			});
		});
	};
	
	
	$scope.showDetail = function(c) {
		$scope.model = c;
		$("#view").modal("show");
	};
	$scope.setSelected=function($index){
		$scope.selectIndex=$index;
	}
	var addModel=function(){
		var flag  = ValidF.valid({id:"#modelForm"})
		if(!flag)return;
		var postData = AppUtil.Params(".input_params");
		AppUtil.Post("/model/create",postData,function(){
				$("#detail").modal("hide");
				$("#modelForm")[0].reset();
				LoadList();
		});
	};
	var updateModel=function(){
		var flag  = ValidF.valid({id:"#modelForm"})
		if(!flag)return;
		var postData = AppUtil.Params(".input_params",true);
		AppUtil.Post("/model/update/"+$("#model_no").val(),postData,function(){
			ValidF.alert("保存成功.");
			LoadList();
		});
	};
	$scope.submitModel=function(){
		switch($("#option").val()){
		case 'add':
			addModel();
			break;
		case 'save':
			updateModel();
			break;
		}
	};
	
	//监听标准单价,标准面积,和装修单价,自动生成实际单价和总价
	$scope.$watch('basic_price+basic_area+decor_price', function() {
		
		    var basic_price = $scope.basic_price==undefined?0:$scope.basic_price;
		    var basic_area = $scope.basic_area==undefined?0:$scope.basic_area;
		    var decor_price = $scope.decor_price==undefined?0:$scope.decor_price;
		    var real_price = parseFloat(basic_price)+parseFloat(decor_price);
		    var total_price =  real_price*basic_area;
		    if( total_price ==0)
		    	 total_price  = undefined;
		    if( real_price ==0)
		    	real_price  = undefined;
		    $scope.real_price=real_price;
		    $scope.total_price=total_price;
		   
	});
	
	$scope.$watch('decor_type', function() {
		var obj = document.getElementById("decor_type"); //定位id
		var index = obj.selectedIndex; // 选中索引
		var text = obj.options[index].text; // 选中文本
		if(text=='毛坯'||text==''){
			$scope.decor_price=0;
			$("#decor_price").attr("readonly","readonly")
		}else{
			$("#decor_price").removeAttr("readonly")
		}
	});
	
	
});

app.register.service('PorModelSer', function($http,AppUtil) {
	this.list = function(postData) {
		AppUtil.loading();
		//设置查询开始下标
		postData.start= (postData.page-1<0?0:postData.page-1)*postData.size;
		return $http.post('model/list', postData).error(function() {
			AppUtil.remove_loading();
		});
	};
});

