app.register.controller('CreateRoomCtrl', function($scope, $http, $rootScope,
		$route, AppUtil, $q,$routeParams,$location) {
	
	//初始布局页
	$scope.layoutPage = "page_1";
	//初始化区域列表
	AppUtil.Post("/create/areaList",{},function(response){
		$scope.areas = response.data;
	});	
	
	//数字转数组方法
	$scope.range = function(n) {
	    var arr =  new Array();
	    for(var i=1,j=n;i<=j;i++){
	    	arr.push(i);
	    }
	    return arr;
	}
	
	//初始化属性信息
	$http.get('/common/attrs').success(function(response) {
		$scope.attrs = response;
	});
	
	//打开添加区域对话框
	$scope.addArea = function(){
		$("#addAreaModal .modal-title").html("新增区域");
		$("#area_no").val("");
		$("#area_name").val("");
		$("#addAreaModal").modal("show");
	};
	//打开编辑区域对话框
	$scope.editArea = function(area){
		$scope.area = area;
		$("#addAreaModal .modal-title").html("编辑区域");
		$("#area_no").val(area.area_no);
		$("#area_name").val(area.area_name);
		$("#addAreaModal").modal("show");
	};
	//删除区域
	$scope.deleteArea = function(area,$index){
		showconfirm("是否确认删除区域:"+area.area_name+"?",function(){
			$http.get("/create/deleteArea/"+area.area_no).success(function(response) {
				if(response.code==1)
					$scope.areas.splice($index,1);
			});
		});
	};
	//添加或保存区域信息
	$scope.saveArea = function(){
		var flag  = ValidF.valid({sel:".area_params",msgDiv:"#add_area_msg"});
		if(!flag)return;
		var area_no = $("#area_no").val();
		var area_name = $("#area_name").val();
		//添加
		if(area_no==''){
			AppUtil.Post("/create/createArea",{'area_name':area_name},function(response){
				$("#addAreaModal").modal("hide");
				response.data.builds=[];
				$scope.areas.push(response.data);
			});	
		}else{
			//保存
			AppUtil.Post("/create/updateArea",{'area_name':area_name,'area_no':area_no},function(response){
				$("#addAreaModal").modal("hide");
				$scope.area.area_name= area_name;
			});	
		}
	};
	
	//打开添加楼栋对话框
	$scope.addBuild = function(area){
		$scope.area = area;
		$("#building_no").val("");
		$("#building_name").val("");
		$("#addBuildModal .modal-title").html("新增楼栋");
		$("#addBuildModal").modal("show");
	};
	//打开编辑楼栋对话框
	$scope.editBuild = function(area,build){
		build.area_no=area_no;
		$scope.area = area;
		$scope.build = build;
		$("#addBuildModal .modal-title").html("编辑楼栋");
		$("#building_no").val(build.building_no);
		$("#building_name").val(build.building_name);
		$("#building_type").val(build.building_type);
		$("#addBuildModal").modal("show");
	};
	//删除楼栋
	$scope.deleteBuild = function(area,build,$index){
		showconfirm("是否确认删除楼栋:"+build.building_name+"?",function(){
			$http.get("/create/deleteBuild/"+build.building_no).success(function(response) {
				if(response.code==1)
					area.builds.splice($index,1);
				else
					alertMsg("提示",response.message);
			});
		});
	};
	//保存楼栋信息
	$scope.saveBuild = function(){
		var flag  = ValidF.valid({sel:".build_params",msgDiv:"#add_build_msg"});
		if(!flag)return;
		var building_no = $("#building_no").val();
		var building_name = $("#building_name").val();
		var building_type = $("#building_type").val();
		
		if(building_no==''){
			//新增
			AppUtil.Post("/create/createBuild",{'building_name':building_name,area_no:$scope.area.area_no,'building_type':building_type},function(response){
				$("#addBuildModal").modal("hide");
				$scope.area.builds.push(response.data);
			});	
		}else{
			//编辑
			AppUtil.Post("/create/updateBuild",{'building_name':building_name,'building_no':building_no,'building_type':building_type},function(response){
				$("#addBuildModal").modal("hide");
				$scope.build.building_name= building_name;
				$scope.build.building_type= building_type;
			});	
		}
	};
	//打开新建房间对话框
	$scope.toCreateRoom=function(area,build){
		build.area_no=area.area_no;
		$scope.build = build;
		$("#CreateFrom")[0].reset();
		setPageSelected(1); 
		$("#page_1").addClass("active");
		$("#add_modal").modal({backdrop: 'static', keyboard: false});
		
	}
	
	//切换选项卡页
	var setPageSelected = function(page){
		$scope.page = page;
		var obj = $("#page_"+page);
		$(".step_list").find("li").removeClass("active");
		obj.addClass("active").removeClass("hide").nextAll("li").addClass("hide");
		$(".step_list").find(".tab-content").children("div").removeClass("active");
		$(".step_list").find(".tab-content").children("div[target_id='"+obj.attr("target_id")+"']").addClass("active");	
		$("#lastBtn").show();
		$("#nextBtn").show();
		$("#submitBtn").hide();
		if(page==1){
			$("#lastBtn").hide();
		}
		if(page>4){
			$("#nextBtn").hide();
			$("#submitBtn").show();
		}
	};
	//切换选项卡
	$scope.changePage=function(page){
		setPageSelected(page);
	};
	//下一页选项卡操作
	$scope.nextPage = function(){
		var page = $scope.page+1;
		switch($scope.page){
		case 1:
			//选择房间类型,跳转到指定页
			var check = $("input[name='optionsRadios']:checked").val();
			if(check=='1'){
				//生成多间
				page=2;
			}else{
				//生成多间
				$scope.room=undefined;
				page=6;
			}
			break;
		case 2:
			//检查楼层,和单元输入是否正确
			var flag  = ValidF.valid({sel:".page_2_form",msgDiv:"#page_2_msg"});
			if(!flag)return;
			break;
		case 3:
			////验证楼层名称以及户数
			var flag  = ValidF.valid({sel:".page_3_form",msgDiv:"#page_3_msg"});
			if(!flag)return;
			//封装数组参数
			var units_arr =  joinParams("input[name='units']");
			if($.unique(joinParams("input[name='units']")).length!=$scope.data.unit){
				ValidF.alertMsg("#page_3_msg","单元名称有重复项,请检查后重新输入.");
				return;
			}
			
			var numbers_arr = joinParams("input[name='numbers']");
			if(numbers_arr.length!=$scope.data.unit){
				ValidF.alertMsg("#page_3_msg","户名称有重复项,请检查后重新输入.")
				return;
			}
			var floors_arr = joinParams("input[name='floors']");
			if( $.unique(joinParams("input[name='floors']")).length!=$scope.data.floor){
				ValidF.alertMsg("#page_3_msg","楼层名称有重复项,请检查后重新输入.")
				return;
			}
			
			//处理单元和户关系
			var numbers =[];
			var units = [];
			for(var i=0,j=units_arr.length;i<j;i++){
				var obj = {};
				obj.name = units_arr[i];
				var number = parseInt(numbers_arr[i]);
				obj.count = number;
				units.push(obj);
				for(var i1=1;i1<=number;i1++){
					var obj1 = {};
					obj1.unit=units_arr[i];
					obj1.num=i1<10?"0"+i1:i1+"";
					numbers.push(obj1);
				}
			}
			var floors = [];
			for(var i=0,j=floors_arr.length;i<j;i++){
				var obj = {};
				obj.key= floors_arr[i];
				floors.push(obj);
			}
			
			$scope.data.units= units;
			$scope.data.numbers= numbers;
			$scope.data.floors= floors;
			break;
		case 4:
			//验证户型是否选择完毕
			var nonSize = $(".model_btn[model='']").size();
			var arrs = $(".model_btn[model!='']");
			if(nonSize>0||arrs.size()==0){
				//验证失败
				ValidF.alertMsg('#page_4_msg','还有未选择户型的房间,请选择完毕后进行下一步.')
				return;
			}
			var btns = [];
			var floors = $scope.data.floors;
			for(f in floors){
				floors[f].values=[];
			}
			arrs.each(function(){
				var model=  $.parseJSON($(this).attr("model"));
				model.name=model.floor+""+model.num;
				for(key in floors){
					var floor = floors[key];
					if(floor.key==model.floor)
						floor.values.push(model);
				}
			});
			break;
		}
		setPageSelected(page);
	};
	//上一页
	$scope.lastPage = function(){
		var page = $scope.page-1;
		if($scope.page==6)
			page=1;
		setPageSelected(page);
	};
	//封装input值为数组并去重
	var joinParams = function(clazz){
		var arr = new Array();
		$(clazz).each(function(){
			var _this = $(this);
			arr.push($(this).val());
		});
		return arr;
	};
	//修改户名,同步修改房间名称
	$scope.modifyRoom = function(num_value,data){
		if(num_value=='')return;
		var num  = data.num;
		var unit = data.unit;
		$(".room_input[num='"+num+"'][unit='"+unit+"']").each(function(){
			var _this = $(this);
			_this.val(_this.attr("floor")+""+num_value);
			_this.attr("num",num_value);
		});
		
	}
	//生成房间
	$scope.submitForm=function(){
		if($scope.page==6){
			//生成单间
			createRoom();
		}else{
			//批量生成房间
			batchCreateRoom();
		}
	};
	//生成单间房间
	var createRoom = function(){
		var flag  = ValidF.valid({sel:".room_params",msgDiv:"#create_room_msg"});
		if(!flag)return;
		var postData = AppUtil.Params(".room_params");
		postData.building_no = $scope.build.building_no;
		postData.area_no = $scope.build.area_no;
		AppUtil.Post("/create/addRoom",postData,function(response){
				if(response.code==1){
					$scope.room = undefined;
					alertMsg("提示", "添加房间成功！");
				}else{
					alertMsg("提示", response.message);
				}
					
				
		});
	};
	//批量生成房间
	var batchCreateRoom = function(){
		//验证每个单元名称是否重复
		var units = $scope.data.units;
		for(var i=0,j=units.length;i<j;i++){
			var max_size =0;
			var value_arr = [];
			var value ;
			var flag =false;
			$(".room_input[unit='"+units[i].name+"']").each(function(){
				max_size++;
				value = $(this).val();
				if(value==''){
					ValidF.alertMsg('#page_5_msg','房间名称不能为空.')
					this.focus();
					flag = true;
					return false;
				}
				value_arr.push(value);
			});
			if(flag)return;
			$.unique(value_arr);
			if(max_size>value_arr.length){
				ValidF.alertMsg('#page_5_msg',units[i].name+'单元房间名称有重复项,请重新输入.')
				return;
			}
		}
		var rooms = [];
		$(".room_input").each(function(){
			var _this = $(this);
			var value = _this.val();
			var model = $.parseJSON(_this.attr("model"))
			model.room_number=value;
			model.num=_this.attr("num");
			rooms.push(model);
		});
		var postData  = $scope.build;
		postData.rooms = rooms;
		
		showconfirm("是否确认生成房间?",function(){
			AppUtil.Post("/create/addRooms",postData,function(response){
				if(response.code==1){
					$("#add_modal").modal("hide");
					$location.path("/source/room");
				}else{
					alertMsg("提示", response.message);
				}
				
			});
		});
		
		
	};
	//监听选择户型,处理房间信息
	 $scope.$watch('model', function() {
		 if(!$scope.model)
			 return;
		 var model = $scope.model;
		 var btnSelectd = $scope.btnSelectd;
		 if(!btnSelectd||AppUtil.Length(btnSelectd)==0)
			 return;
		 if(btnSelectd.type=='all'){
			 //全部调整
			 setBtnData(".model_btn",model);
			 
		 }else if(btnSelectd.type=='row'){
			 //处理行
			 setBtnData(".model_btn[floor='"+btnSelectd.floor+"']",model);
		 }else if(btnSelectd.type=='col'){
			//处理列
			 setBtnData(".model_btn[num='"+btnSelectd.num+"'][unit='"+btnSelectd.unit+"']",model);
		 }else{
			 //处理单个
			 var btn = $("#model_btn_"+btnSelectd.floor+btnSelectd.num+btnSelectd.unit);
			 delete btnSelectd["index"]; 
			 delete btnSelectd["type"];  
			 btnSelectd.model_no = model.model_no;
			 btn.attr("model",JSON.stringify(btnSelectd));
			 btn.html(model.model_name);
		 }
	 });
	 //设置户型btn的值
	var setBtnData=function(clazz,model){
		 $(clazz).each(function(){
				var _this = $(this);
				var num = _this.attr("num");
				var floor = _this.attr("floor");
				var unit = _this.attr("unit");
				var model_no = model.model_no;
				var data = {num:num,floor:floor,unit:unit,model_no:model_no};
				_this.attr("model",JSON.stringify(data));
				_this.html(model.model_name);
		});
	};
	 
	//选择户型
	$scope.openModel = function(type,index,floor,num,unit){
		var btnSelectd = {};
		if(type!=undefined)
			btnSelectd.type=type;
		if(floor!=undefined)
			btnSelectd.floor=floor;
		if(num!=undefined)
			btnSelectd.num = num;
		if(unit!=undefined)
			btnSelectd.unit = unit;
		if(unit!=undefined)
			btnSelectd.index = index;
		$scope.btnSelectd=btnSelectd;
		$scope.model = undefined;
		$scope.modelIndex = undefined;
		$("#add_modal").modal("hide");
		$("#modelModal").modal("show");
		if($scope.models==undefined){
			//加载户型信息
			AppUtil.Post("/create/models",{},function(response){
				$scope.models = response.data;
			});
		}
	}
	//关闭户型选择对话框
	$scope.cancelModel=function(){
		$("#modelModal").modal("hide");
		$("#add_modal").modal({backdrop: 'static', keyboard: false});
	}
	//单机户型事件,确定index
	$scope.setModelIndex=function(index){
		$scope.modelIndex = index;
	}
	//确定选择户型,关闭对话框
	$scope.selectModel=function(){
		if($scope.modelIndex!=undefined){
			if($scope.room==undefined)
				$scope.room={};
			var model = $scope.models[$scope.modelIndex];
			$scope.model  = model;
			$.extend($scope.room,model);
		}
		$scope.cancelModel();
	}
	//监听标准单价,标准面积,和装修单价,自动生成实际单价和总价
	$scope.$watch('room.basic_price+room.basic_area+room.decor_price', function() {
		 	var room= $scope.room;
		 	if(room==undefined)
		 		return;
		    var basic_price = room.basic_price==undefined?0:room.basic_price;
		    var basic_area = room.basic_area==undefined?0:room.basic_area;
		    var decor_price = room.decor_price==undefined?0:room.decor_price;
		    room.real_price = parseFloat(basic_price)+parseFloat(decor_price);
		    room.total_price =  room.real_price*basic_area;
		    if(room.total_price ==0)
		    	room.total_price  = undefined;
		    if(room.real_price ==0)
		    	room.real_price  = undefined;
		   
	});
	 
});



