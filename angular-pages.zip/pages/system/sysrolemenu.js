app.register.controller('RolepermissionCtrl', function($scope, $rootScope,
		RolepermissionSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage :10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
//		// 筛选查询参数
//		var search_opt = AppUtil.GetSearchOpt();
//		if (search_opt.length > 0) {
//			$scope.postData.search_opt = search_opt;
//		}
		LoadList();
	};
	
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		RolepermissionSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.rolelist = response.data;
		});
	}
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	//加载下拉列表数据
	$http.get("sysMenu/treeData").success(function(data){
		var setting = {
				check: {
					enable: false
				} 
		};
		$scope.zNodes=data.data;
		$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);
		$("#menuSave").hide();
	});
	
	
	
	var setting = {
			check: {
				enable: true
			} 
	};
	
	/**
	 * 编辑角色菜单
	 */
	$scope.edit = function(c, $index) {
		$("#menuSave").show();
		$("#roleId").val(c.roleCode);
		$("#roleChoose").remove();
		$("#roleMsg").append("<span id='roleChoose' style='color:green;padding-left:5px'>(当前选择角色："+c.roleName+")</span>");
		$scope.selectIndex=$index;
		var checkResult;
		$.ajax({
			type : "POST",
			url : "roleMenu/listRoleMenu",
			dataType : "json",
			data : {"roleId":c.roleCode},
			success : function(data) {
				if(data.code=='1'){
					checkResult=data.data;
					
				}else{
					alertMsg("提示", "查询失败");
					return false;
				}
			}
		});
		//加载下拉列表数据
		$http.get("sysMenu/treeData").success(function(data){
			$scope.zNodes=data.data;
			checkMenu($scope.zNodes,checkResult)
			$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);
		});
	}
	
	
	/**
	 * 保存角色菜单
	 */
	$scope.save = function() {
		var roleId=$("#roleId").val();
		var zTree = $.fn.zTree.getZTreeObj("treeList");
		var checkCount = zTree.getCheckedNodes(true);
		var jsonArr=[];
		$.each(checkCount,function(i,o){
			var json_item={"menuId":o.id,"isParent":o.isParent}
			jsonArr.push(json_item);
		})
		var jsonStr=JSON.stringify(jsonArr); 
		$.ajax({
			type : "POST",
			url : "roleMenu/saveRoleMenu",
			dataType : "json",
			data : {"jsonStr":jsonStr,"roleId":roleId},
			success : function(data) {
				if(data.code=='1'){
					alertMsg("提示", "保存成功");
				}else{
					alertMsg("提示", "保存失败");
				}
			}
		});
		
	}
	
	
//	}
});

app.register.service('RolepermissionSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('roleMenu/pageList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})


/**
 * 选中菜单
 * @param totalMenu
 * @param roleMenu
 */
function checkMenu(totalMenu,roleMenu){
	$.each(totalMenu,function(i,o){
		if(o.menuLevel&&o.menuLevel==0){
			totalMenu.remove(o);
		}
	})
	$.each(totalMenu,function(i,o){
		$.each(roleMenu,function(m,obj){
			if(obj.menuId==o.id){
				o.checked=true;
			}
		})
		if(o.children){
			checkMenu(o.children,roleMenu);
		}
	})
	
}