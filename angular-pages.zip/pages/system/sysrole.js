app.register.controller('RoleCtrl', function($scope, $rootScope,
		RoleSer, AppUtil, $http, $q) {
	//获取本地存储中的页码页数
	$scope.pagination = {
			currentPage : 1,
			itemsPerPage : 10
	};
	
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		RoleSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.rolelist = response.data;
		});
	}

	
	//新增
	$scope.addEntity=function(){
		$("#myModal_detail").modal("show");
		$("#addEntity")[0].reset();
		$("#saveButton").off().click(function(){
			var flag = ValidF.valid({id :"#addEntity",sel : ".ng-binding",msgDiv : "#add_reg_tip_box"});
			if(flag){
				var entity = AppUtil.Params("#addEntity .ng-binding");
				$http.post('sysRole/addEntity',	entity).success(
					function(response) {
						if(response.code ==1){
							alertMsg("提示","新增成功", function() {
								LoadList();
								$("#myModal_detail").modal("hide");
							});
						}else{
							alertMsg("提示", response.message);
						}
				}).error(function() {
					alertMsg("提示","系统出错,请稍后重试.");
				});
			}
		});
	};
	
	//编辑
	$scope.edit=function(entity){
		$("#editRole_dialog").modal("show");
		$("#editEntity")[0].reset();
		for (key in entity) {
			if (key && key.indexOf('$') == -1) {
				$("#editEntity input[name=" + key + "]").val(
						entity[key]);
			}
			$("#editEntity textarea[name='tRemark']").val(
					entity["tRemark"]);
		}
		
		$("#editButton").off().click(function(){
			var flag = ValidF.valid({id :"#editEntity",sel : ".ng-binding",msgDiv : "#edit_reg_tip_box"});
			if(flag){
				var entity = AppUtil.Params("#editEntity .ng-binding");
				$http.post('sysRole/editEntity',	entity).success(
					function(response) {
						if(response.code ==1){
							alertMsg("提示","修改成功", function() {
								LoadList();
								$("#editRole_dialog").modal("hide");
							});
						}else{
							alertMsg("提示", response.message);
						}
				}).error(function() {
					alertMsg("提示","系统出错,请稍后重试.");
				});
			}
		});
	};
	
	
	//删除
	$scope.deleted=function(entity){
		showconfirm("确定删除该角色？", function() {
			var params = {roleId : entity.roleId};
			$http.post('sysRole/delEntity',params).success(function(response) {
				alertMsg("提示", "删除成功");
				LoadList();
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		}, function() {
			$("#showConfirm").modal("hide");
			return false;
		});
	}
	$scope.$watch('pagination.refresh', LoadList);
});

app.register.service('RoleSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('sysRole/pageList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

