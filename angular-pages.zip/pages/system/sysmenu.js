
app.register.controller('SysmenuCtrl', function($scope, $http, $rootScope,
		$route, AppUtil,$q) {
	
	//TODO 禁用
	location.href="/login.html";
	//初始化
	var setting={
			callback: {
				onMouseDown : function(event, treeId, treeNode) {
					if(treeNode!=null){
						$("#checkMenu").val(treeNode.id);
						$("#headDiv input[name='menuName']").val(treeNode.name); 
						$("#headDiv input[name='linkUrl']").val(treeNode.linkurl); 
						$("#headDiv input[name='sort']").val(treeNode.sort); 
						$("#headDiv input[name='id']").val(treeNode.id); 
						//加载右侧列表数据
						var postData = {
								parentId:treeNode.id
						}
						AppUtil.loading();
						//设置查询开始下标
						return $http.post('sysMenu/getMenuList', postData).success(function(response) {
							$scope.menulist = response.data;
							$scope.datasize=response.data.length;
							AppUtil.remove_loading();
						});
					}
					
				}
			}
			
	};
	//加载下拉列表数据
	$http.get("sysMenu/treeData").success(function(data){
		$scope.zNodes=data.data;
		console.log(data.data);
		$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);
	});
	
	
	//修改信息
	$scope.editEntity=function(){
		var checkId=$("#checkMenu").val();
		if(checkId!=''&&checkId!=null&&checkId!='null'){
			if($("#headDiv input[name='menuName']").val()==''){
				alert("菜单名称不能为空")
				return false;
			}
			if($("#headDiv input[name='sort']").val()==''){
				alert("排序不能为空")
				return false;
			}
			$.ajax({
				type : "GET",
				url : "sysMenu/editEntity",
				dataType : "json",
				data : {
					"menuName" : $("#headDiv input[name='menuName']").val(),
					"linkUrl" :$("#headDiv input[name='linkUrl']").val(),
					"sort" :$("#headDiv input[name='sort']").val(),
					"id" :$("#headDiv input[name='id']").val()
				},
				success : function(data) {
					alertMsg("提示", "修改成功");
					$http.get("sysMenu/treeData").success(function(data){
						$scope.zNodes=data.data;
						$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);
					});
				}
			});
		}else{
			alert("请选择一个菜单节点")
		}
	};
	
	
	//编辑页面
	$scope.edit=function(entity){
		var checkId=$("#checkMenu").val();
		
		$("#dialog input[name='menuName']").val(entity.menuName); 
		$("#dialog input[name='linkUrl']").val(entity.linkUrl); 
		$("#dialog input[name='sort']").val(entity.sort); 
		$("#dialog input[name='id']").val(entity.id); 
		$( "#dialog" ).dialog({
			modal: true,
			title:"修改",
			buttons: {
		        '保存': function() {
		        	if($("#dialog input[name='menuName']").val()==''){
		    			alert("菜单名称不能为空")
		    			return false;
		    		}
		    		if($("#dialog input[name='sort']").val()==''){
		    			alert("排序不能为空")
		    			return false;
		    		}
		        	$.ajax({
						type : "GET",
						url : "sysMenu/editEntity",
						dataType : "json",
						data : {
							"menuName" : $("#dialog input[name='menuName']").val(),
							"linkUrl" :$("#dialog input[name='linkUrl']").val(),
							"sort" :$("#dialog input[name='sort']").val(),
							"id" :$("#dialog input[name='id']").val()
						},
						success : function(data) {
							alertMsg("提示", "修改成功");
							var postData = {
									parentId:checkId
							}
							AppUtil.loading();
							//设置查询开始下标
							return $http.post('sysMenu/getMenuList', postData).success(function(response) {
								$scope.menulist = response.data;
								AppUtil.remove_loading();
							});
						}
					});
		            $(this).dialog('close');
		        },
		        '取消': function() {
		            $(this).dialog('close');
		        }
		    }
		})
	};
	
	
	//删除
	$scope.deleted=function(entity){
		 if(confirm(("警告","确定删除该菜单？"))){
			var checkId=$("#checkMenu").val();
	    	$.ajax({
				type : "GET",
				url : "sysMenu/delEntity",
				dataType : "json",
				data : {
					"id" :entity.id
				},
				success : function(data) {
					alertMsg("提示", "删除成功");
					var postData = {
							parentId:checkId
					}
					AppUtil.loading();
					//设置查询开始下标
					$http.get("sysMenu/treeData").success(function(data){
						$scope.zNodes=data.data;
						$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);
					});
					return $http.post('sysMenu/getMenuList', postData).success(function(response) {
						$scope.menulist = response.data;
						AppUtil.remove_loading();
					});
				}
			});
		 }
	}
	
	//新增
	$scope.addEntity=function(){
		var checkId=$("#checkMenu").val();
		$("#dialog input[name='menuName']").val('');
		$("#dialog input[name='linkUrl']").val('');
		$("#dialog input[name='sort']").val('');
		if(checkId==''||checkId==null||checkId=='null'){
			alert("请选择一个菜单节点");
			return false;
		}
		$( "#dialog" ).dialog({
			modal: true,
			title:"新增",
			buttons: {
		        '保存': function() {
		        	if($("#dialog input[name='menuName']").val()==''){
		    			alert("菜单名称不能为空")
		    			return false;
		    		}
		    		if($("#dialog input[name='sort']").val()==''){
		    			alert("排序不能为空")
		    			return false;
		    		}
		        	$.ajax({
						type : "POST",
						url : "sysMenu/addEntity",
						dataType : "json",
						data : {
							"menuName" : $("#dialog input[name='menuName']").val(),
							"linkUrl" :$("#dialog input[name='linkUrl']").val(),
							"sort" :$("#dialog input[name='sort']").val(),
							"parentId" :checkId
						},
						success : function(data) {
							alertMsg("提示", "新增成功");
							var postData = {
									parentId:checkId
							}
							AppUtil.loading();
							$http.get("sysMenu/treeData").success(function(data){
								$scope.zNodes=data.data;
								$.fn.zTree.init($("#treeList"), setting, $scope.zNodes);
							});
							//设置查询开始下标
							return $http.post('sysMenu/getMenuList', postData).success(function(response) {
								$scope.menulist = response.data;
								AppUtil.remove_loading();
							});
						}
					});
		            $(this).dialog('close');
		        },
		        '取消': function() {
		            $(this).dialog('close');
		        }
		    }
		})
	};

})
