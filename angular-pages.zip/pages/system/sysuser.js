app.register.controller('UserCtrl', function($scope, $rootScope,
		UserSer, AppUtil, $http, $q) {
	$scope.pagination = {
			currentPage :1,
			itemsPerPage : 10
	};
	$scope.SearchData = function() {
		$scope.postData={};
		// 点击查询按钮时,恢复页码为1
		$scope.pagination.currentPage = 1
		// 表单查询参数
		var params = AppUtil.Params(".form_params");
		// 当有查询参数时,重置页数
		if (AppUtil.Length(params) > 0) {
			$scope.postData.params = params;
		}
		LoadList();
	};
	// 加载数据方法
	var LoadList = function() {
		if ($scope.postData == undefined)
			$scope.postData = {};
		$scope.postData.page = $scope.pagination.currentPage;
		$scope.postData.size = $scope.pagination.itemsPerPage;
		// 加载数据
		UserSer.list($scope.postData).success(function(response) {
			AppUtil.remove_loading();
			$scope.pagination.totalItems = response.total;
			$scope.rolelist = response.data;
		});
	}
	// 配置分页监听
	$scope.$watch('pagination.refresh', LoadList);
	
	$http.get("entity/dicts").success(function(data){
		$scope.sexs=data.data.sexs;
		$scope.status=data.data.status;
		$scope.types=data.data.types;
	});
	
	
	// 新增
	$scope.addEntity = function() {
		$("#myModal_detail").modal("show");
		$("#addEntity")[0].reset();
		
		$("#saveButton").off().click(function(){
			var flag = ValidF.valid({id :"#addEntity",sel : ".ng-binding",msgDiv : "#add_reg_tip_box"});
			if(flag){
				var entity = AppUtil.Params("#addEntity .ng-binding");
				$http.post('entity/addEntity',	entity).success(
					function(response) {
						if(response.code ==1){
							alertMsg("提示","新增成功", function() {
								LoadList();
								$("#myModal_detail").modal("hide");
							});
						}else{
							alertMsg("提示", response.message);
						}
				}).error(function() {
					alertMsg("提示","系统出错,请稍后重试.");
				});
			}
		});
    };
    
	//编辑
    $scope.edit = function(entity) {
    	$("#edit_user").modal("show");
    	$("#editEntity")[0].reset();
		for (key in entity) {
			if (key && key.indexOf('$') == -1) {
				$("#editEntity input[name=" + key + "]").val(entity[key]);
				$("#editEntity select[name=" + key + "]").find("option[value='"+entity[key]+"']").attr("selected",true);
			}
		}
		
		$("#editButton").off().click(function(){
			var flag = ValidF.valid({id :"#editEntity",sel : ".ng-binding",msgDiv : "#edit_reg_tip_box"});
			if(flag){
				var entity = AppUtil.Params("#editEntity .ng-binding");
				$http.post('entity/editEntity',	entity).success(
					function(response) {
						if(response.code ==1){
							alertMsg("提示","修改成功", function() {
								LoadList();
								$("#edit_user").modal("hide");
							});
						}else{
							alertMsg("提示", response.message);
						}
				}).error(function() {
					alertMsg("提示","系统出错,请稍后重试.");
				});
			}
		});
	};
	
	//删除
	$scope.deleted=function(entity){
		showconfirm("确定删除该用户？", function() {
			var params = {userId : entity.userId};
			$http.post('entity/delEntity',params).success(function(response) {
				alertMsg("提示", "删除成功");
				LoadList();
			}).error(function() {
				alertMsg("提示", "系统出错,请稍后重试.");
			});
		}, function() {
			$("#showConfirm").modal("hide");
			return false;
		});
	}
	
	
	//重置密码
	$scope.pwd = function(entity) {
		$("#pwd_dialog").modal("show");
		$("#pwd_dialog input[name='password']").val('');
		
		$("#pwdButton").off().click(function(){
			if($("#pwd_dialog input[name='password']").val()==''){
    			alert("密码不能为空")
    			return false;
    		}
        	$.ajax({
				type : "POST",
				url : "entity/editPwd",
				dataType : "json",
				data : {
					"userId" : entity.userId,
					"password" :$("#pwd_dialog input[name='password']").val()
				},
				success : function(data) {
					alertMsg("提示", "密码已经被重置",function(){
						LoadList();
						$("#pwd_dialog").modal("hide");
					});
				}
			});
		});
    };
    
    //分配角色
	$scope.userrole= function(entity) {
		$("#role_dialog").modal("show");
		$http.get("entity/loadRoleList?userId="+entity.userId).success(function(data){
			var checkList=data.data.checkList;
			var uncheckList=data.data.uncheckList;
			$("#uncheckList").html("");
			$("#checkList").html("");
			$.each(checkList ,function(index, item){
				$("#checkList").append('<option value='+item.role_id+'>'+item.role_name+'</option>')
		    });
			
			$.each(uncheckList ,function(index, item){
				$("#uncheckList").append('<option value='+item.role_id+'>'+item.role_name+'</option>')
		    });
		});
		
		$("#addBtn").click(function(){ 
			$("#checkList").append($("#uncheckList").find("option:selected"));
			$("#uncheckList").find("option:selected").remove();
			
		});
		
		$("#delBtn").click(function(){ 
			$("#uncheckList").append($("#checkList").find("option:selected"));
			$("#checkList").find("option:selected").remove();
		});
		
		$("#roleButton").off().click(function(){
			var roleIds=[];
			$("#checkList").find("option").each(function(){
				roleIds.push($(this).val());
			});
			
			$.ajax({
				type : "POST",
				url : "entity/saveUserRole",
				dataType : "json",
				data : {
					"userId" : entity.userId,
					"roleIds" :roleIds.join(',')
				},
				success : function(data) {
					alertMsg("提示", "角色分配成功",function(){
						LoadList();
						$("#role_dialog").modal("hide");
					});
				}
			});
		})
    };
    
    
	
});


app.register.service('UserSer', function($http,AppUtil) {
	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		postData.start = (postData.page - 1 < 0 ? 0 : postData.page - 1)
				* postData.size;
		return $http.post('entity/pageList', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
})

