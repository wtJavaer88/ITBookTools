app.register.controller('BuildReportCtrl', function($scope, $rootScope,
		 AppUtil, $http, $q) {
	
	//加载楼栋下拉
	$http.get("build/dicts").success(function(data){
		$scope.buildings = data.data;
	});
	
	//按楼栋搜索
	$scope.SearchData = function() {
		var params = AppUtil.Params(".form_params");
		if($("select[name='buildingNo']").val() == ""){
			alertMsg("提示", "请选择楼栋");
			return false;
		}
		AppUtil.Post("/build/search", params, function(response){
			$scope.showTable(response.data);
		});	
	};
	
	//渲染表格
	$scope.showTable = function(data){
		var unitAndDoor = data.unitAndDoor;
		var rooms = data.rooms;
		var floors = data.floors;
		var projectName = $("select[name='projectNo']").find("option:selected").text(); 
		var buildingName = $("select[name='buildingNo']").find("option:selected").text(); 
		//创建标题
		$("#reportTitle").html(projectName + buildingName+"价格表");
		
		//创建表头
		var cols = 6;
		var table = $("#buidTable").html("");
		var th_unit = $("<tr></tr>");
		var th_door = $("<tr></tr>");
		var th_cols = $("<tr></tr>");
		var th_hb = $("<tr></tr>");
		for (var t = 0; t < unitAndDoor.length; t++) {
			var item = unitAndDoor[t];
			var doors = item.doorNo.split(",");
			//迭代每栋多少单元
			var td_unit = $("<th colspan='"+doors.length*cols+"'>"+item.unitNo+"</th>");
			th_unit.append(td_unit);
			
			for(var i=0;i<doors.length;i++){
				//每层多少户表头
				var td_door = $("<th colspan='"+cols+"'>"+doors[i]+"</th>");
				th_door.append(td_door);
				//合并单元格 没个户型的表头
				th_cols.append($("<th>单价(元/㎡)</th><th>总价(元)</th><th>单价(元/㎡)</th><th>总价(元)</th>"));
				th_hb.append($("<th rowspan='2' style='vertical-align:middle'>房号</th><th rowspan='2' style='vertical-align:middle'>面积(㎡)</th><th colspan='2'>销售价</th><th colspan='2'>折后价</th>"));
			}
		}
		table.append(th_unit).append(th_door).append(th_hb).append(th_cols);
		//创建房间
		createRoom(table,unitAndDoor,rooms,floors);
	}
    
	//迭代房间数据
	var createRoom = function(table, unitAndDoor, rooms, floors){
		for(var i=0; i<floors;i++){
			var trs = $("<tr floor="+(i+1)+"></tr>");
			for (var t = 0; t < unitAndDoor.length; t++) {
				var item = unitAndDoor[t];
				var doors = item.doorNo.split(",");
				
				for(var s=0;s<doors.length;s++){
					var flag = false;
					for(var g=0; g<rooms.length; g++){
						var room = rooms[g];
						if( (i+1) == room.roomFloor && item.unitNo == room.unitNo && doors[s] == room.doorNo){
							var bkclass = "";
							if(room.roomStatus == CON_ROOM_STATUS.WFP){
								bkclass = "bk_wfp";
							}else if(room.roomStatus == CON_ROOM_STATUS.WXS){
								bkclass = "bk_wxs";
							}else if(room.roomStatus == CON_ROOM_STATUS.YYD){
								bkclass = "bk_yyd";
							}else if(room.roomStatus == CON_ROOM_STATUS.YXS){
								bkclass = "bk_yxs";
							}
							trs.append($("<td class='"+bkclass+"'>"+room.roomNumber+"</td><td  class='"+bkclass+"'>"+parseFloat(room.basicArea).toFixed(2)+"</td><td  class='"+bkclass+"'>"+parseFloat(room.basicPrice).toFixed(2)+"</td><td  class='"+bkclass+"'>"+parseFloat(room.basicPrice*room.basicArea).toFixed(2)+"</td><td class='"+bkclass+"'>"+parseFloat(room.realPrice).toFixed(2)+"</td><td  class='"+bkclass+"'>"+parseFloat(room.totalPrice).toFixed(2)+"</td>"));
							flag = true;
						}
					}
					if(!flag){
						trs.append($("<td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td>"));
					}
				}
			}
			table.append(trs);
		}
	}
});


