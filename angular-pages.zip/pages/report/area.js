app.register.controller('AreaCtrl', function($scope, $rootScope,
		AreaSer, AppUtil, $http, $q,$location,$routeParams) {
	    $scope.postData = {};
	    
		$http.get("build/dicts").success(function(data){
			$scope.buildList=data.data;
		});
		
		
		$scope.SearchData = function() {
			$scope.postData={};
			// 表单查询参数
			var params = AppUtil.Params(".form_params");
			// 当有查询参数时,重置页数
			if (AppUtil.Length(params) > 0) {
				$scope.postData.params = params;
			}
			LoadData();
		};
		
		
		var LoadData = function() {
			$("#table").html('');
			// 加载数据
			AreaSer.list($scope.postData).success(function(response) {
				AppUtil.remove_loading();
				var data=response.data;
				$.each(data,function(i_data,o_data){
					var trRowspan=o_data.length;
					$.each(o_data,function(i,o){
						
							var cloneItem=$("#cloneTr").clone();
							for(itemKey in o){
								$(cloneItem).find("td[name='"+itemKey+"']").html(o[itemKey]);
							}
							if(i==0){
								if(o.building_no){
									$(cloneItem).find("td:eq(0)").attr("rowspan",trRowspan);
								}else{
									$(cloneItem).find("td:eq(0)").remove();
									$(cloneItem).find("td:eq(0)").attr("colspan",2);
									$(cloneItem).find("td:eq(0)").html("住宅销售合计");
								}
							}else{
								$(cloneItem).find("td:eq(0)").remove();
								if(i==o_data.length-1){
									$(cloneItem).find("td:eq(0)").html("小计");
								}
							}
							$(cloneItem).removeAttr("hidden");
							$("#table").append($(cloneItem));
						
					});
				});
			});
	    };
	    
	    LoadData();
});


app.register.service('AreaSer', function($http, AppUtil) {

	// 查询数据
	this.list = function(postData) {
		AppUtil.loading();
		return $http.post('area/getTotalResult', postData).error(function() {
			alertMsg("提示", "系统出错,请稍后重试.");
			AppUtil.remove_loading();
		});
	};
	
	
});