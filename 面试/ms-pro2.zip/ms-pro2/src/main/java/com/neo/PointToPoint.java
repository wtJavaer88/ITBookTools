package com.neo;

import java.io.IOException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

/**
 * @author 作者 ucs_fuqing
 * @date 创建时间：2017年8月11日 下午2:21:27
 * @version 1.0
 * @parameter
 * @since
 * @return
 */
public abstract class PointToPoint {
	protected Channel channel;
	protected Connection connection;
	protected String pointName;

	/**
	 * 获取一个队列的连接
	 * 
	 * @param pointName
	 * @throws IOException
	 */
	public PointToPoint(String pointName) throws IOException {
		this.pointName = pointName;
		ConnectionFactory cf = new ConnectionFactory();
		cf.setHost("192.168.0.106");
		cf.setUsername("sboot1");
		cf.setPassword("1988");
		connection = cf.newConnection();
		channel = connection.createChannel();
		// 申明一个队列，如果这个队列不存在，将会被创建
		System.out.println("Conoo");
		// channel.queueDeclare(pointName, false, false, false, null);
		// System.out.println("Chhh");
	}

	/**
	 * 
	 * @Title: close @Description:
	 *         其实在程序完成时一般会自动关闭连接，但是这里提供手动操作的入口， @param @throws IOException
	 *         设定文件 @return void 返回类型 @throws
	 */
	public void close() throws IOException {
		this.channel.close();
		this.connection.close();
	}
}