package com.neo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.SerializationUtils;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.ShutdownSignalException;

/**
 * @author 作者 ucs_fuqing
 * @date 创建时间：2017年8月11日 下午2:39:51
 * @version 1.0
 * @parameter
 * @since
 * @return
 */
public class QueueConsumer extends PointToPoint implements Runnable, Consumer {

	public QueueConsumer(String pointName) throws IOException {
		super(pointName);
		// TODO Auto-generated constructor stub
	}

	public void run() {
		try {
			// channel.basicQos(0, 1, false);
			channel.basicConsume(pointName, false, this);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void handleConsumeOk(String consumerTag) {
		// TODO Auto-generated method stub
		System.out.println("Consumer " + consumerTag + " registered");

	}

	public void handleCancelOk(String consumerTag) {
		// TODO Auto-generated method stub

	}

	public void handleCancel(String consumerTag) throws IOException {
		// TODO Auto-generated method stub

	}

	public void handleDelivery(String consumerTag, Envelope env, BasicProperties props, byte[] body)
			throws IOException {
		// TODO Auto-generated method stub
		Map map = (HashMap) SerializationUtils.deserialize(body);
		System.out.println("Message Number " + map.get("tagId") + " received. " + map);
		try {
			// 事实上,一旦消费者线程启动, 则会有大量的消息一次涌入. 这些消息状态马上从ready变成unacked
			// 如果中间线程异常退出(如认为关闭), 则会发给下一个消费者, 如果没有消费者处理则保持unacked状态
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		channel.basicAck(env.getDeliveryTag(), false);
	}

	public void handleShutdownSignal(String consumerTag, ShutdownSignalException sig) {
		// TODO Auto-generated method stub

	}

	public void handleRecoverOk(String consumerTag) {
		// TODO Auto-generated method stub

	}

}