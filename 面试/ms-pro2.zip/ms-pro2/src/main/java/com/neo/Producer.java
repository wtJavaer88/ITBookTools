package com.neo;

import java.io.IOException;
import java.io.Serializable;

import org.apache.commons.lang.SerializationUtils;

/**
 * @author 作者 ucs_fuqing
 * @date 创建时间：2017年8月11日 下午2:33:13
 * @version 1.0
 * @parameter
 * @since
 * @return
 */
public class Producer extends PointToPoint {

	public Producer(String pointName) throws IOException {
		super(pointName);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @Title: sendMessage @Description: 生产消息 @param @param
	 * Object @param @throws IOException 设定文件 @return void 返回类型 @throws
	 */
	public void sendMessage(Serializable Object) throws IOException {
		channel.basicPublish("", pointName, null, SerializationUtils.serialize(Object));
	}
}