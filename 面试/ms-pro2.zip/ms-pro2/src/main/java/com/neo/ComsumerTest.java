package com.neo;

import java.io.IOException;

public class ComsumerTest {
	public static void main(String[] args) throws IOException {
		QueueConsumer consumer = new QueueConsumer(MainTest.pointName);
		consumer.run();

	}
}
