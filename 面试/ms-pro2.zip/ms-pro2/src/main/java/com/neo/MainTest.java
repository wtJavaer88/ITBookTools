package com.neo;

import java.util.HashMap;

/**
 * @author 作者 ucs_fuqing
 * @date 创建时间：2017年8月11日 下午2:44:59
 * @version 1.0
 * @parameter
 * @since
 * @return
 */
public class MainTest {
	final static String pointName = "testq";

	public MainTest() throws Exception {

		Producer producer = new Producer(pointName);
		int i = 0;
		while (i < 60) {
			HashMap<String, Object> hm = new HashMap<String, Object>();
			hm.put("tagId", i);
			hm.put("url", "http://www.zhihu.com/a.do?x=" + i);

			producer.sendMessage(hm);
			// System.out.println("发送第" + i + "消息");
			i++;
			// Thread.sleep(1000);
		}
	}

	public static void main(String[] args) throws Exception {
		new MainTest();
	}
}