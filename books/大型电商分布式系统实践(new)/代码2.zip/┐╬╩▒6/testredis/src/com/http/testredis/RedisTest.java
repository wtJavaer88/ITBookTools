/**
 * 
 */
package com.http.testredis;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import redis.clients.jedis.Jedis;

/**
 * @Description: redis apiʹ�� 
 * @Author chenkangxian   
 * @Date 2014-4-6 ����07:10:21 
 * @Copyright: 2012 chenkangxian, All rights reserved.
 **/
public class RedisTest {


	public static void main(String[] args) {

		 Jedis  redis = new Jedis ("192.168.136.135",6379);//����redis
		 
         //Keys 
		 System.out.println("=============keys=============");
         Set<String> keys = redis.keys("name*");//ȡ����name��ʼ��key
         Iterator<String> it =keys.iterator() ;  
         while(it.hasNext()){  
             String key = it.next();  
             System.out.println(key);  
         } 
         System.out.println("=============keys=============");
         
         //String
         System.out.println("=============String=============");
         redis.set("name", "chenkangxian");//����key-value
         redis.set("id", "123456");  
         redis.set("address", "hangzhou"); 
         redis.setex("content", 5, "hello");//������Ч��Ϊ5��
         redis.mset("class","a","age","250"); //һ�����ö��key-value
         redis.append("content", " lucy");//���ַ���׷������
         String content = redis.get("content"); //����key��ȡvalue
         System.out.println(content);
         List<String> list = redis.mget("class","age");//һ��ȡ���key
         for(int i=0;i<list.size();i++){  
             System.out.println(list.get(i));  
         }
         System.out.println("=============String=============");
         
         //Hashsʹ��
         System.out.println("=============hash=============");
         redis.hset("url", "google", "www.google.cn");//��hash����ֵ  
         redis.hset("url", "taobao", "www.taobao.com");  
         redis.hset("url", "sina", "www.sina.com.cn");  
         
         Map<String,String> map = new HashMap<String,String>();  
         map.put("name", "chenkangxian");  
         map.put("sex", "man");  
         map.put("age", "100");  
         redis.hmset("userinfo", map);//��������ֵ
         
         String name = redis.hget("userinfo", "name");//ȡhash��ĳ��key��ֵ
         System.out.println(name);
         
         //ȡhash�Ķ��key��ֵ
         List<String> urllist = redis.hmget("url","google","taobao","sina");  
         for(int i=0;i<urllist.size();i++){  
             System.out.println(urllist.get(i));  
         }
         
         //ȡhash������key��ֵ
         Map<String,String> userinfo = redis.hgetAll("userinfo");  
         for(Map.Entry<String,String> entry: userinfo.entrySet()) {  
              System.out.print(entry.getKey() + ":" + entry.getValue() + "\t");  
         } 
         System.out.println("");
         System.out.println("=============hash=============");
         
         //list
         System.out.println("=============list=============");
         redis.lpush("charlist", "abc");//��list�ײ�����Ԫ�� 
         redis.lpush("charlist", "def");  
         redis.rpush("charlist", "hij");//��listβ������Ԫ��
         redis.rpush("charlist", "klm");
         List<String> charlist = redis.lrange("charlist", 0, 2);  
         for(int i=0;i<charlist.size();i++){  
             System.out.println(charlist.get(i));  
         }
         
         redis.lpop("charlist");//��list�ײ�ɾ��Ԫ��
         redis.rpop("charlist");//��listβ��ɾ��Ԫ��
         
         Long charlistSize = redis.llen("charlist");//���list�Ĵ�С
         System.out.println(charlistSize);  
         
         System.out.println("=============list=============");
         
         //set
         System.out.println("=============set=============");
		 redis.sadd("SetMem", "s1");//��Set����Ԫ��
		 redis.sadd("SetMem", "s2");  
		 redis.sadd("SetMem", "s3");  
		 redis.sadd("SetMem", "s4");  
		 redis.sadd("SetMem", "s5");
		 
		 redis.srem("SetMem", "s5");//��Set���Ƴ�Ԫ��
		 
		 Set<String> set = redis.smembers("SetMem");//ö�ٳ�set��Ԫ��  
         Iterator<String> setit = set.iterator() ;  
         while(setit.hasNext()){  
             String setvalue=setit.next();  
             System.out.println(setvalue);  
         }  
         System.out.println("=============set=============");
         
         //sorted set
         System.out.println("=============sort set=============");
		 redis.zadd("SortSetMem", 1, "5th");//����sort set,��ָ��Ȩ��
		 redis.zadd("SortSetMem", 2, "4th");
		 redis.zadd("SortSetMem", 3, "3th");
		 redis.zadd("SortSetMem", 4, "2th");
		 redis.zadd("SortSetMem", 5, "1th");
		 
		 //���ݷ�Χȡset
		 Set<String> sortset = redis.zrange("SortSetMem", 2, 4);
		     Iterator<String> sortsetit = sortset.iterator() ;  
		     while(sortsetit.hasNext()){  
		         String setvalue=sortsetit.next();  
		         System.out.println(setvalue);  
		     }  
		     
		   //���ݷ�Χ����ȡset
		 Set<String> revsortset = redis.zrevrange("SortSetMem", 1, 2);
		 Iterator<String> revsortsetit = revsortset.iterator() ;  
		 while(revsortsetit.hasNext()){  
		     String setvalue=revsortsetit.next();  
		     System.out.println(setvalue);  
		 }  
         System.out.println("=============sort=============");
         

	}

}
