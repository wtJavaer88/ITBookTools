package com.http.test;

public class SaySomething {
public static void saySomething(){
	System.out.println("hello");
}
}
