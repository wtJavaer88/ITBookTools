import com.http.test.SaySomething;


public class Test {

	public static void main(String[] args) {
		SaySomething.saySomething();
	}

}
