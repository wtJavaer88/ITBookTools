/**
 * 
 */
package com.http.validatefile;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @Description: �ж��ļ����� 
 * @Author chenkangxian   
 * @Date 2013-8-25 ����10:04:43 
 * @Copyright: 2012 chenkangxian, All rights reserved.
 **/
public final class FileTypeJudge {
		
	/**
	 * ������ת��Ϊ16����
	 */
	private static String bytes2hex(byte[] bytes) {
		StringBuilder hex = new StringBuilder();
		for (int i = 0; i < bytes.length; i++) {
			String temp = Integer.toHexString(bytes[i] & 0xFF);
			if (temp.length() == 1) {
				hex.append("0");
			}
			hex.append(temp.toLowerCase());
		}
		return hex.toString();
	}
   
	/**
	 * ��ȡ�ļ�ͷ
	 */
	private static String getFileHeader(String filePath) throws IOException {
		byte[] b = new byte[28];//������Ҫע�����,ÿ���ļ���magic word�ĳ��ȶ�����ͬ,�����Ҫʹ��startwith
		InputStream inputStream = null;
		inputStream = new FileInputStream(filePath);
		inputStream.read(b, 0, 28);
		inputStream.close();
				
		return bytes2hex(b);
	}
	
	/**
	 * �ж��ļ�����
	 */
	public static FileType getType(String filePath) throws IOException {
		
		String fileHead = getFileHeader(filePath);
		if (fileHead == null || fileHead.length() == 0) {
			return null;
		}
		fileHead = fileHead.toUpperCase();
		FileType[] fileTypes = FileType.values();
		for (FileType type : fileTypes) {
			if (fileHead.startsWith(type.getValue())) {
				return type;
			}
		}
		return null;
	}
	
	public static void main(String[] args) throws Exception{
		 System.out.println(FileTypeJudge.getType("D:\\Download\\doc.rar"));
	}
}

