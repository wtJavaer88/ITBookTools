/**
 * 
 */
package com.http.testcertificate;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

/**
 * @Description: ����֤���ʹ�� 
 * @Author chenkangxian   
 * @Date 2013-10-2 ����02:31:29 
 * @Copyright: 2012 chenkangxian, All rights reserved.
 **/
public class TestCertificate {

	public static void main(String[] args) throws Exception {
		
		//1.������Կ��
		String keyStorePath = "/home/longlong/ca_dir/client.p12";
		String password = "123456";
		KeyStore keystore = KeyStore.getInstance("pkcs12");
		FileInputStream keystoreFis = new FileInputStream(keyStorePath);
		keystore.load(keystoreFis, password.toCharArray());

		//2.���˽Կ
		String alias = "chenkangxian";
		PrivateKey privateKey = (PrivateKey)keystore.getKey(alias, password.toCharArray());
		System.out.println(privateKey.getAlgorithm());

		//3.��Կ�����֤��
		X509Certificate x509Certificate = (X509Certificate)
			keystore.getCertificate(alias);

		//4.��ù�Կ
		PublicKey publicKey = x509Certificate.getPublicKey();
		System.out.println(publicKey.getAlgorithm());
		
		
		//5.�ļ�����֤��,Ŀǰjava6ֻ֧��x509��ʽ��֤��
		String certPath = "/home/longlong/ca_dir/certs/client.cer";
		CertificateFactory certificateFactory = CertificateFactory.
												getInstance("X.509");
		FileInputStream certFis = new FileInputStream(certPath);
		X509Certificate certificate = (X509Certificate)certificateFactory
		 								.generateCertificate(certFis);
		System.out.println(certificate.getSigAlgName());
		

		//6.��������ǩ��
		Signature signature = Signature.getInstance
				(x509Certificate.getSigAlgName());
		//ʹ��֤��У������ǩ��,��ʵ���õ���֤���еĹ�Կ
		signature.initVerify(x509Certificate);

	}

}
