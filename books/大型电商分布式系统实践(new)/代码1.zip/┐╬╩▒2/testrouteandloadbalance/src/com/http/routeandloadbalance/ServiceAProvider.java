/**
 * 
 */
package com.http.routeandloadbalance;

import java.net.InetAddress;
import org.I0Itec.zkclient.ZkClient;

/**
 * @Description: service provider A ʵ�� 
 * @Author chenkangxian   
 * @Date 2013-7-29 ����7:21:54 
 * @Copyright: 2012 chenkangxian, All rights reserved.
 **/
public class ServiceAProvider {
	
	private String serviceName = "service-A";
	
	//��zookeeperע�����
	public void init() throws Exception{
		
		String serverList = "192.168.136.130:2181";
		String PATH = "/configcenter";//���ڵ�·��
		ZkClient zkClient = new ZkClient(serverList);
		
		boolean rootExists = zkClient.exists(PATH);
		
		if(!rootExists){
			zkClient.createPersistent(PATH);
		}
		
		boolean serviceExists = zkClient.exists(PATH + "/" + serviceName);
		
		if(!serviceExists){
			zkClient.createPersistent(PATH + "/" + serviceName);//��������ڵ�
		}
		
		//ע�ᵱǰ��������Ȩ��
		InetAddress addr = InetAddress.getLocalHost();
		String ip = addr.getHostAddress().toString();//��ñ���IP
		
		zkClient.createEphemeral(PATH + "/" + serviceName + "/" + ip);
	}
	
	//�ṩ����
	public void provide(){
		
	}

	public static void main(String[] args) throws Exception {
		ServiceAProvider a = new ServiceAProvider();
		a.init();
		
		Thread.sleep(1000 * 60 * 60 * 24);
	}

}
