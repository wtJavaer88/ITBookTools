/**
 * 
 */
package com.http.routeandloadbalance;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.I0Itec.zkclient.ZkClient;

/**
 * @Description: service provider A ʵ��  
 * @Author chenkangxian   
 * @Date 2013-7-29 ����7:22:14 
 * @Copyright: 2012 chenkangxian, All rights reserved.
 **/
public class ServiceBProvider {

	private String serviceName = "service-B";
	
	//��zookeeperע�����
	public void init() throws Exception{
		
		String serverList = "192.168.136.130:2181";
		String PATH = "/configcenter";//���ڵ�·��
		ZkClient zkClient = new ZkClient(serverList);
		
		boolean rootExists = zkClient.exists(PATH);
		
		if(!rootExists){
			zkClient.createPersistent(PATH);
		}
		
		boolean serviceExists = zkClient.exists(PATH + "/" + serviceName);
		
		if(!serviceExists){
			zkClient.createPersistent(PATH + "/" + serviceName);//��������ڵ�
		}
		
		//ע�ᵱǰ������,�����ڽڵ�����������Žڵ��Ȩ��
		InetAddress addr = InetAddress.getLocalHost();
		String ip = addr.getHostAddress().toString();//��ñ���IP
		
		//������ǰ�������ڵ�
		zkClient.createEphemeral(PATH + "/" + serviceName + "/" + ip);
		
	}
	
	//�ṩ����
	public void provide(){
		
	}
	

	public static void main(String[] args) throws Exception {
		
//		InetAddress addr = InetAddress.getLocalHost();
//		String ip = addr.getHostAddress().toString();//��ñ���IP
//		System.out.println(ip);
		
		
//		InetAddress addr = InetAddress.getLocalHost();
//		String hostname = addr.getHostName();
//		InetAddress[] addrs = InetAddress.getAllByName(hostname);
//		for(InetAddress add : addrs){
//			System.out.println(add.getHostAddress().toString());
//		}
		
//		ServiceBProvider b = new ServiceBProvider();
//		b.init();
//		
//		Thread.sleep(1000 * 60 * 60 * 24);
	}

}
