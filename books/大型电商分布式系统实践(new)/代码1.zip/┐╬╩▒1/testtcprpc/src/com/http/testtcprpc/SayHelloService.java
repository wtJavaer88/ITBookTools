/**
 * 
 */
package com.http.testtcprpc;

/**
 * @Description: say hello�Ľӿ�
 * @Author chenkangxian   
 * @Date 2013-6-20 ����6:51:09 
 * @Copyright: 2012 chenkangxian, All rights reserved.
 **/
public interface SayHelloService {

	/**
	 * �ʺõĽӿ�
	 * @param helloArg ����
	 * @return
	 */
	public String sayHello(String helloArg);
}
